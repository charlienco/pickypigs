export const p1_tag = [
  {
    index: 1,
    info: "Hello, we’re Picky Pigs  Limited (No. 8265628) (Picky Pigs , we, us). This Picky Pigs  Privacy Policy (Privacy Policy) is provided to ensure you understand your rights and obligations when you access and navigate our website located at Pickypigs.com (Website).",
  },

  {
    index: 2,
    info: "This policy sets out:",
    bullet_points: [
      "what is considered personal information",
      "what personal information we collect and hold",
      "how we collect, hold, use or disclose personal information",
      "the purposes for which we collect personal information",
      "what happens if we are not able to collect personal information",
      "how to seek access to and correct your personal information",
      "whether we disclose personal information outside Australia and",
      "how to contact us",
    ],
  },

  {
    index: 3,
    info: "Picky Pigs  respects the rights and privacy of all individuals and is committed to complying with the Privacy Act 1988 (Cth) (the Act) and the  New Zealand Privacy Principles and protecting the personal information we hold.",
  },

  {
    index: 4,
    info: "We may, from time to time, review and update this policy, including taking account of new or amended laws, new technology and/or changes to our operations. All personal information held by us will be governed by the most recently updated policy and we will give you notice of our revised policy by posting to our Website.",
  },
];

export const p3_tag = [
  {
    index: 1,
    info: "We collect the type of personal information required to assist with providing you with access to the Website and its associated functionality.",
  },

  {
    index: 2,
    info: "This may include personal information such as:",
    bullet_points: [
      "Personal or Company name",
      "mailing or street address",
      "email address",
      "telephone number",
      "age or birth date",
      "occupation",
      "details of what you have looked at or purchased from a venue",
      "any additional information relating to you that you provide to us directly through our website, by phone, email, surveys, or in person, or information you have provided indirectly through use of our Website or online presence through our representatives or otherwise",
    ],
  },
];

export const p4_tag = [
  {
    index: 1,
    info: "We collect your personal information directly from you unless it is unreasonable or impractical to do so. We do this in ways including:",
    bullet_points: [
      "when you register as a user of the Website",
      "via your access and use of our Website",
      "via someone else who has provided us with your information and",
      "during conversations between you and us via phone or email (if any)",
    ],
  },

  {
    index: 2,
    info: "We may also collect personal information from third parties including third party companies such as law enforcement agencies and other government entities, e-commerce platforms, data suppliers, advertisers, mailing lists and contractors and business partners.",
  },
  {
    index: 3,
    info: "We may also provide your information to third parties engaged by Picky Pigs to perform functions on its behalf, such as processing credit card information, as well as third parties authorised by you to receive information held by Picky Pigs .",
  },
  {
    index: 4,
    info: "We may collect and disclose personal information to third parties for the purposes described in this policy. These purposes include but are not limited to:",
    bullet_points: [
      "efficient communications between you and Picky Pigs ",
      "secure storage and management of your files to allow Picky Pigs to provide you proper access to the Website",
    ],
  },
  {
    index: 5,
    info: "The primary purpose for which we collect information about you is to enable us to perform our business activities and functions and to provide the best customer experience.",
  },
  {
    index: 6,
    info: "We generally collect personal information as part of providing you with access to Website, for the venue to contact you about your meal, informing you about them, complying with our contractual and other legal obligations, running promotions and other marketing activities, or administering our relationship with you by responding to your enquiries and providing you with information about Picky Pigs ’s activities that may be of interest to you.",
  },
  {
    index: 7,
    info: "We may use your personal information for those purposes, in developing, maintaining, or updating the system accessed by you through the Website or in any other way if we ask for your consent first.",
  },
  {
    index: 8,
    info: "Your personal information will not be shared, sold, rented, or disclosed other than as described in this Privacy Policy.",
  },
  {
    index: 9,
    info: "We may disclose your personal information to:",
    bullet_points: [
      "our employees, contractors, licensees or external service providers for the operation of our website or our business, fulfilling requests by you, including without limitation IT systems administrators or payment processors",
      "specific third parties authorised by you to receive information held by us (e.g. a venue that you have opted in to receive marketing information from",
      "the police, any relevant authority or enforcement body, or your Internet Service Provider or network administrator, for example, if we have reason to suspect that you have committed a breach of any of our terms and conditions, or have otherwise been engaged in any unlawful activity, and we reasonably believe that disclosure is necessary",
      "as required or permitted by any law (including the Privacy Act)",
    ],
  },
];

export const p5_tag = [
  {
    index: 1,
    info: "Where practical, you may choose not to identify yourself.",
  },

  {
    index: 2,
    info: "In some instances, if you do not provide us with required personal information described in this policy, we may not be able to provide you with access to the Website, either to the same standard as if you had provided the required personal information, or at all.",
  },
];

export const p6_tag = [
  {
    index: 1,
    info: "If you use our Website to make purchases or other financial transactions (such as payment of invoices through the Website for products or services you purchase from a third party user or venue), we may collect information about the purchase or transaction. This includes payment information, such as your credit card or debit card number, billing details and other account and contact information (Financial Information).",
  },

  {
    index: 2,
    info: "We will only collect Financial Information from you with your prior knowledge and consent. You can access and browse our Website without disclosing Financial Information.",
  },

  {
    index: 3,
    info: "We use your Financial Information solely to process payments for products or services you request or purchase through the use of our Website. We only use and retain your Financial Information to complete payments you initiate, any Financial Information that is collected is solely for the purpose of transaction approval and the transfer of funds.",
  },

  {
    index: 4,
    info: "We provide data encryption throughout the payment process and only share your Financial Information with your credit card provider, third party payment processor or financial institution to process payments. The Financial Information we collect from you is strictly confidential and held on secured servers in controlled facilities.",
  },

  {
    index: 5,
    info: "We do not retain your Financial Information after the transaction is complete, unless you check a box through which you ask us to save your Financial Information for future product purchases or payments. If you do check that box, we will retain your Financial Information until you contact us and ask that we remove it from our databases.",
  },

  {
    index: 6,
    info: "We may use third party agents to manage online payment processing. These agents are not permitted to store, retain, or use your Financial Information or other personally identifiable information, except for the sole purpose of payment processing on our behalf. Any third party agent used by us is not authorized to use your Financial Information in any way other than to process payments and is required to keep any Financial Information it uses or collects confidential.",
  },
];

export const p7_tag = [
  {
    index: 1,
    info: "We may send you direct marketing communications and information about services that we consider may be of interest to you. These communications may be sent in various forms, including mail, SMS or email, in accordance with applicable marketing laws, such as the Spam Act 2004 (Cth). If you indicate a preference for a method of communication, we will endeavour to use that method whenever practical to do so.",
  },

  {
    index: 2,
    info: "In addition, at any time, you may opt-out of receiving marketing communications from us by contacting us (details below) or by using the opt-out facilities provided (e.g. an unsubscribe link). We will then ensure that your name is removed from our mailing list. We do not provide your personal information to other organisations for the purposes of direct marketing unless expressly authorised by you.",
  },

  {
    index: 3,
    info: "Even if you do opt out of receiving marketing communications from us, you agree that we may still send you information relevant to the supply of any services arranged by us or goods or services purchased by you through our Website.",
  },

  {
    index: 4,
    info: "If you receive communications from us that you believe have been sent to you other than in accordance with this policy, or in breach of any law, please contact us using the details provided below.",
  },
];

export const p8_tag = [
  {
    index: 1,
    info: "Our Website is hosted by third party service providers.",
  },

  {
    index: 2,
    info: "In order for Picky Pigs to allow you access to the Website, we at times may allow access to personal information to third party providers.",
  },

  {
    index: 3,
    info: "We make no representations or warranties in relation to the privacy practices of any third party service providers and we are not responsible for the privacy policies or the content of any third party service provider.",
  },
];

export const p9_tag = [
  {
    index: 1,
    info: "We will not disclose your personal information to any person or entity outside New Zealand, Australia or the UK. If this needs to change, we will inform you prior to any overseas disclosure and will provide the relevant details.",
  },

  {
    index: 2,
    info: "If we are required to disclose personal information to other overseas persons or entities, we will take reasonable steps to ensure that the overseas recipients of your personal information do not breach the privacy obligations relating to your personal information.",
  },
];

export const p10_tag = [
  {
    index: 1,
    info: "You may request access to any personal information we hold about you at any time by contacting us at sasha@pickypigs.com",
  },

  {
    index: 2,
    info: "Where we hold information that you are entitled to access, we will try to provide you with suitable means of accessing it (for example, by mailing or emailing it to you). We will not charge for simply making a request and will not charge for making any corrections to your personal information. If you make an access request, we will ask you to verify your identity. There may be instances where we cannot grant you access to the personal information we hold. For example, we may need to refuse access if granting access would interfere with the privacy of others, or if it would result in a breach of confidentiality. If that happens, we will give you written reasons for any refusal.",
  },

  {
    index: 3,
    info: "If you believe that personal information we hold about you is incorrect, incomplete or inaccurate, then you may request us to amend it. We will consider if the information requires amendment. If we do not agree that there are grounds for amendment, then we will add a note to the personal information stating that you disagree with it.",
  },

  {
    index: 4,
    info: "We request that you keep your information as current as possible so that we may continue to improve our service to you.",
  },
];

export const p11_tag = [
  {
    index: 1,
    info: "We will take all reasonable steps to protect the personal information that we hold from misuse, loss, or unauthorised access, including by means of firewalls, password access, secure servers and encryption of credit card transactions.",
  },

  {
    index: 2,
    info: "If you suspect any misuse or loss of, or unauthorised access to, your personal information, please let us know immediately.",
  },

  {
    index: 3,
    info: "If we suspect any misuse or loss of, or unauthorised access to, your personal information we may inform you of that suspicion and take immediate steps to limit any further access to, or distribution of, your personal information. If we determine that the breach is likely to result in serious harm to you and we are unable to prevent the likely risk of serious harm with remedial action, we will take action in accordance with the Privacy Act 1988 (Cth).",
  },

  {
    index: 4,
    info: "If we receive unsolicited personal information that we are not permitted to collect under this privacy policy, or within the confines of the law, we will destroy or de-identify the unsolicited personal information as soon as practicable if it is lawful and reasonable to do so. We will destroy or de-identify your personal information if we no longer require it to deliver our services as soon as practicable if it is lawful and reasonable to do so.",
  },
];

export const p12_tag = [
  {
    index: 1,
    info: "When you use our Website, Picky Pigs or our service providers may obtain information using technologies such as cookies, tags, web beacons, and navigational data collection (log files, server logs, and clickstream data) to better understand your user experience. For example, Picky Pigs or our service providers may collect information like the date, time and duration of visits and which webpages are accessed.",
  },

  {
    index: 2,
    info: "When you access our Website, we may send a “cookie” (which is a small summary file containing a unique ID number) to your computer or mobile device. This enables us to recognise your computer or device and greet you each time you visit our Website, without bothering you with a request to register or log-in. It also helps us keep track of products or services you view, so that we can send you news about those products or services.",
  },

  {
    index: 3,
    info: "We also use cookies to measure traffic patterns, to determine which areas of our websites have been visited, and to measure transaction patterns in the aggregate. We use this to research our users’ habits so that we can improve our online services. If you do not wish to receive cookies, you can set your browser so that your computer does not accept them.",
  },

  {
    index: 4,
    info: "We may also log IP addresses (the electronic addresses of computers connected to the internet) to analyse trends, administer the website, track user movements, and gather broad demographic information.",
  },
  {
    index: 5,
    info: "This information is generally not linked to your identity, except where it is accessed via links in Picky Pigs emails or where you have identified yourself. We may also collect anonymous data (which is not personal information) relating to your activity on our website (including IP addresses) via cookies. We generally use this information to report statistics, analyse trends, administer our services, diagnose problems and target and improve the quality of our services. To the extent this information does not constitute personal information because it does not identify you or anyone else, the New Zealand Privacy Principles do not apply and we may use this information for any purpose and by any means whatsoever.",
  },
];

export const p13_tag = [
  {
    index: 1,
    info: "If you believe your privacy has been breached by us, have any questions or concerns about our Privacy Policy please, contact us using the email sasha@pickypigs.com and provide details of the incident so that we can investigate it.",
  },

  {
    index: 2,
    info: "We are genuinely committed to the rules, ethos and intent detailed in this Privacy Policy and we aim to ensure that your requests or complaints are treated confidentially. Our representative will contact you within a reasonable time after receipt of your complaint to discuss your concerns and outline options regarding how they may be resolved. We will aim to ensure that your complaint is resolved in a timely and appropriate manner.",
  },

  {
    index: 3,
    info: "If you are not satisfied with the outcome of our investigation, then you may request that an independent person (usually the Commonwealth Privacy Officer) investigate your complaint.",
  },
];
