export const p1_tag = [
  {
    index: 1,
    info: "Hello, we’re Picky Pigs Limited (No. 8265628) (Picky Pigs, we, us). These Picky Pigs Website Terms of Use (Terms) are here to ensure you understand your rights and obligations when you access and navigate and use our website located at Pickypigs.com (Website) and use our Services (as defined below).",
  },

  {
    index: 2,
    info: "Any reference in these Terms to “you” or “your” or “Customer” means any person accessing, viewing, or using the Website and/or Services.",
  },

  {
    index: 3,
    info: "Picky Pigs provides to Customers an interactive mobile menu (Menu) containing food, beverage, and merchandise products (Products) from third party restaurants and venues (Venues). By scanning the QR code or tapping the NFC chip located at participating Venues or by visiting the links located on a Venue’s website, You will be directed to our Website and can view photos of and information about the Products and may purchase the Products (Order) from the Menu by entering your nominated payment method on the Website which is processed in accordance with clause 3 (Services).",
  },

  {
    index: 4,
    info: "By accessing, navigating and using the Services and/ or Website or otherwise dealing with Picky Pigs, you agree to be bound by these Terms and the Picky Pigs Privacy Policy located at https://www.pickypigs.com/privacy-policy. If you do not agree to these Terms, then you must cease using the Services or the Website.",
  },

  {
    index: 5,
    info: "Picky Pigs may amend these Terms at any time at its sole discretion. By continuing to use the Website and/ or Services, you will be deemed to have accepted any revised terms from the date that they are published on the Website.",
  },

  {
    index: 6,
    info: "Picky Pigs reserves its rights to investigate and take appropriate legal action for any Illegal and/or unauthorised use of the Services, the Website or breach of these Terms.",
  },
];
export const p2_tag = [
  {
    index: 1,
    info: "Picky Pigs grants you a non-exclusive, non-transferable licence to access, use and navigate the Services and Website subject to you complying with these Terms.",
  },

  {
    index: 2,
    info: "To use the Services, you acknowledge and agree that you may need to provide Picky Pigs with information that could personally identify you and you acknowledge that Picky Pigs may collect your location. You acknowledge and agree that all information collected will be dealt with in accordance with our Privacy Policy.",
  },

  {
    index: 3,
    info: "You acknowledge and agree that Picky Pigs may send electronic messages to your contact telephone number or email address. You agree that by using the Services you consent to Picky Pigs sending you electronic messages. We will only send you messages related to your Order and, if you opt in, we may send you direct marketing communications and information about services that we consider may be of interest to you. You can opt out of receiving direct marketing communications and information at any time.",
  },

  {
    index: 4,
    info: "You agree that placing an Order using the Services is subject to you making full payment for the Products in accordance with clause 3.",
  },

  {
    index: 5,
    info: "If you purchase Products that are alcoholic beverages, contain alcohol or by law require you to be over the age of 18 years for consumption, you warrant that you are over the age of 18 years.",
  },

  {
    index: 6,
    info: "You agree that it is the responsibility of the Venue to comply with all laws in relation to the service of alcohol including responsible service of alcohol, ensuring the Venue holds a valid alcohol licence and ensuring that the Customer is over the age of 18 years before serving the Customer alcohol.",
  },

  {
    index: 7,
    info: "You acknowledge that Picky Pigs #does not guarantee that Products will be delivered or available for pick-up within a certain time frame or that the Products are of a certain quality.",
  },

  {
    index: 8,
    info: "You acknowledge that Picky Pigs does not guarantee that any of the information displayed on its Website including all information, photos, ingredients, explanations of a Product or the Menu of the Venue are accurate and Picky Pigs  is not liable for any errors in representation.",
  },

  {
    index: 9,
    info: "You acknowledge that Picky Pigs acts only as an intermediary between the Customer and the Venue and is not liable if the Venue does not stock or make the Products available or refuses to accept your Order.",
  },
];

export const p3_tag = [
  {
    index: 1,
    info: "You agree that you will pay for all Products that you Order from a Venue in accordance with these payment terms and that you will pay the purchase price as displayed on the Website.",
  },

  {
    index: 2,
    info: "Picky Pigs warrants that it has the right to collect payments for Products that you Order using our Services on behalf of Venues. When you pay the purchase price using our Services, you discharge your obligations to pay the Venue directly for the Products that you Order.",
  },

  {
    index: 3,
    info: "You acknowledge and agree that all purchase prices specified, and payments collected will be inclusive of all applicable taxes where required by law.",
  },

  {
    index: 4,
    info: "You acknowledge that Picky Pigs will not place your Order with the Venue until you have made full payment of the Product through or Website.",
  },

  {
    index: 5,
    info: "You acknowledge that the purchase price or availability of the Product as displayed on the Services and Website may differ from time to time to the purchase price of the Product advertised at the Venue.",
  },

  {
    index: 6,
    info: "You acknowledge that Picky Pigs uses third party payment processors including but not limited to Stripe, Braintree, Square, Paypal, Hyperwallet, Apple Pay and Google Pay (Payment Processors). You agree that you will pay in addition to the purchase price of the Product, any additional fees charged by the Payment Processors.",
  },

  {
    index: 7,
    info: "The processing of payments or credit cards are subject to the terms, conditions and privacy policies of your credit card issuer and the Payment Processors in addition to these Terms. The terms and conditions and privacy policies for the Payment Processors can be accessed at their websites. Picky Pigs is not responsible for any errors by the Payment Processor or credit card issuer.",
  },

  {
    index: 8,
    info: "You warrant that you are the authorised user of any payment method that you use in connection with the Services and the Website and you acknowledge the Picky Pigs is not liable for any unauthorised use of any payment method.",
  },

  {
    index: 9,
    info: "You agree that if you submit an Order, Picky Pigs delivers your Order to the Venue when your payment has been authorised. Subject to clause 7.4 and the Venue’s refund policy, you are not entitled to change or cancel your Order once it has been placed and you will not be entitled to a refund.",
  },
  {
    index: 10,
    info: "You agree that Venues have the sole discretion to reject or refuse your Order at any time. If your Order is rejected or cancelled by the Venue, you will receive a refund in accordance with the Venue’s refund policy.",
  },
];

export const p4_tag = [
  {
    index: "a",
    info: "Venue Promotional Codes cannot be redeemed for cash, can only be used on one transaction, must be used before the expiry date.",
  },

  {
    index: "b",
    info: "Picky Pigs and the Venue reserves the right to cancel, withhold use, suspend or modify the terms of Venue Promotional Codes and any discount or benefit associated with it at any time.",
  },
];

export const p5_tag = [
  {
    index: 1,
    info: "Picky Pigs makes all reasonable endeavours to ensure that the information about Menus and Products available on the Website are accurate and correct, although we do not warrant that it is accurate, adequate or complete.",
  },

  {
    index: 2,
    info: "You acknowledge and accept that the Website content may include incorrect information, technical inaccuracies and typographical errors. You acknowledge and accept that the Services and the Website will, from time to time, change without notice to you and that the content of the Website may not necessarily be accurate or up to date at the time you view it.",
  },

  {
    index: 3,
    info: "You are responsible to contact us directly to ensure that any material or information on the Website that you seek to rely on is accurate and current. Picky Pigs disclaims all liability for any direct or indirect loss or damage arising from your use or reliance on the Services or Website to the full extent permitted by law.",
  },

  {
    index: 4,
    info: "You agree not to attempt to change, add to, remove, deface, hack or otherwise interfere with the Services or the Website or any material or content displayed on the Services or the Website unless expressly permitted by us or these Terms.",
  },

  {
    index: 5,
    info: "You warrant that you will not hide, deface, alter or delete any copyright symbol, trademark or other proprietary rights notice.",
  },

  {
    index: 6,
    info: "We do not guarantee that your access to the Services and/or the Website will be uninterrupted or that the Services and/or the Website is free from viruses or any other malware which may damage any device or data as a result of access to the Services or Website.",
  },

  {
    index: 7,
    info: "You agree that Picky Pigs may conduct maintenance of the Services or Website at any time and that this maintenance may interrupt your access to the Services or Website.",
  },

  {
    index: 8,
    info: "We reserve our rights to suspend or terminate your access to the Service or Website at our sole discretion where we hold a reasonable apprehension that you have or may breach these Terms. If we suspect you are or may be in breach of these Terms, we will endeavour to notify you of that breach and ways in which you can remedy it.",
  },
];

export const p6_tag = [
  {
    index: 1,
    info: "All material displayed on the Service and the Website, including but not limited to all information, photographs, graphics, illustrations, artwork, names, logos, trademarks, copy writing and design features (Picky Pigs Intellectual Property) we acknowledge we have the right to use or are our property and are protected by copyright, trademark and other intellectual property laws. You may not use the Picky Pigs Intellectual Property for any commercial purpose without our express prior written consent.",
  },

  {
    index: 2,
    info: "You agree not to copy, imitate, reproduce, reverse engineer, sell, reproduce, retransmit, distribute, disseminate, sell, publish, broadcast or circulate any Picky Pigs Intellectual Property for any commercial purpose to any third party in whole or in part without our express prior written consent.",
  },

  {
    index: 3,
    info: "You acknowledge that if you do copy, imitate, reproduce, reverse engineer, sell, reproduce, retransmit, distribute, disseminate, sell, publish, broadcast or circulate any Picky Pigs Intellectual Property, we will suffer loss and damage and you agree to indemnify us for any such loss and damage.",
  },

  {
    index: 4,
    info: "We do not grant any licence or right in or assign all or part of the rights of the Picky Pigs Intellectual Property to you.",
  },

  {
    index: 5,
    info: "The Website may contain links to other websites operated, controlled or produced by third parties including Venues. Picky Pigs does not control, endorse, sponsor or approve of any third party website or its content and does not provide any warranty or take on any responsibility whatsoever in relation to your access and use of third party websites. We advise you to check their privacy policy and terms and conditions before using their services.",
  },

  {
    index: 6,
    info: "You warrant that you will not infringe the Intellectual Property Rights of Picky Pigs or any third party relating to your use of the Services or the Website.",
  },
];

export const p7_1_tag = [
  { index: "(c)", info: "consumption of alcohol by minors" },
  {
    index: "(d)",
    info: "your consumption of Products that may result in allergic reactions; or",
  },
  {
    index: "(e)",
    info: "any representation of the ingredients contained in Products.",
  },
];

export const p7_tag = [
  {
    index: 2,
    info: "You agree that your use of the Services and the Website are at your own risk and you accept and agree that you will not seek to hold us accountable for any loss or damage that you or any third party may suffer as a result of your use of the Services and/or the Website, and that you will indemnify us for any such loss and damage we suffer as a result of claims brought against us by any party as a result of your use of the Services and/or the Website.",
  },

  {
    index: 3,
    info: "Notwithstanding the above, to the maximum extent as permitted by law, you agree that Picky Pigs’s aggregate liability shall not exceed the total purchase price of your Order.",
  },

  {
    index: 4,
    info: "Services supplied to you by Picky Pigs come with guarantees that cannot be excluded under the New Zealand Consumer Law. Nothing in these Terms purports to modify or exclude the conditions, warranties, guarantees and undertakings, and other legal rights, under the New Zealand Consumer Law and other laws which cannot be modified or excluded.",
  },

  {
    index: 5,
    info: "Where any law implies a warranty into this agreement which may not be lawfully excluded then to the extent allowed by law (Warranty), any liability imposed upon Picky Pigs relating to a breach of Warranty will at its option be limited to a refund of the price of the Order.",
  },
];
