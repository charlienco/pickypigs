import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Link, useHistory, useParams } from "react-router-dom";
import SingleDiscDetalDescComp from "../../components/SingleDiscDetalDescComp/SingleDiscDetalDescComp";
import SingleDiscIngredientTableComp from "../../components/SingleDiscIngredientTableComp/SingleDiscIngredientTableComp";
import RestaurentDiscAllergiesInfoModal from "../../components/RestaurentDiscAllergiesInfoModal/RestaurentDiscAllergiesInfoModal";
import RestaurentDiscCaloriesInfoModal from "../../components/RestaurentDiscCaloriesInfoModal/RestaurentDiscCaloriesInfoModal";
import "./RestaurantSingleDiscInfoPage.scss";
import RestaurantCookingMethodModal from "../../components/RestaurantCookingMethodModal/RestaurantCookingMethodModal";
import { getSelectedDiscInfoData } from "../../redux/actions/dishAction";
import WebRestaurantSingleDiscInfoPageSkeleton from "../../components/WebSkeleton/WebRestaurantSingleDiscInfoPageSkeleton/WebRestaurantSingleDiscInfoPageSkeleton";

const RestaurantSingleDiscInfoPage = () => {
  const params = useParams();
  const dishInfoId = params.dishId;
  const dispatch = useDispatch();
  const history = useHistory();

  useEffect(() => {
    dispatch(getSelectedDiscInfoData(dishInfoId, history));
    // eslint-disable-next-line
  }, [dispatch, dishInfoId]);

  let selectedDiscInfo_data = useSelector((state) => {
    return state.dishes.selectedDiscInfo_Data;
  });

  let myLoading = useSelector((state) => {
    return state.dishes.isDishLoading;
  });

  return (
    <>
      {/* {JSON.stringify(selectedDiscInfo_data)} */}
      {/* <React.Fragment>
                {myLoading&&myLoading?
                    <CustomLoadingComp/>
                :
                    null
                }
            </React.Fragment> */}
      <section className="rsdiscinfo-section">
        <div className="container">
          <React.Fragment>
            {myLoading && myLoading ? (
              <React.Fragment>
                <WebRestaurantSingleDiscInfoPageSkeleton />
              </React.Fragment>
            ) : (
              <React.Fragment>
                {/*Breadcrumb Start*/}
                <div className="breadcrumb-wrapper">
                  <nav aria-label="breadcrumb">
                    <ol className="breadcrumb">
                      <li className="breadcrumb-item text-capitalize">
                        <Link to="/">Home</Link>
                      </li>
                      <li className="breadcrumb-item text-capitalize">
                        <Link to="/allrestaurant">Restaurants</Link>
                      </li>
                      <li
                        className="breadcrumb-item text-capitalize"
                        aria-current="page"
                      >
                        <Link
                          to={
                            "/restaurant/" +
                            (selectedDiscInfo_data &&
                            selectedDiscInfo_data.restaurantId
                              ? selectedDiscInfo_data.restaurantId
                              : "")
                          }
                        >
                          {selectedDiscInfo_data &&
                          selectedDiscInfo_data.restaurantName
                            ? selectedDiscInfo_data.restaurantName
                            : "Unknown"}
                        </Link>
                      </li>
                      <li
                        className="breadcrumb-item active text-capitalize"
                        aria-current="page"
                      >
                        {selectedDiscInfo_data && selectedDiscInfo_data.name
                          ? selectedDiscInfo_data.name
                          : "Unknown"}
                      </li>
                    </ol>
                  </nav>
                </div>
                {/*Breadcrumb Ends*/}
                <div className="row mt-4 pt-2 mb-4">
                  <div className="col-sm-12 col-md-5 rsdiscinfo-leftcontent">
                    <SingleDiscDetalDescComp
                      itemimage={
                        selectedDiscInfo_data && selectedDiscInfo_data.image
                          ? selectedDiscInfo_data.image
                          : ""
                      }
                      name={
                        selectedDiscInfo_data && selectedDiscInfo_data.name
                          ? selectedDiscInfo_data.name
                          : "Name Not Available"
                      }
                      price={
                        selectedDiscInfo_data && selectedDiscInfo_data.price
                          ? selectedDiscInfo_data.price
                          : "Price Not Available"
                      }
                      priceunit={
                        selectedDiscInfo_data && selectedDiscInfo_data.priceUnit
                          ? selectedDiscInfo_data.priceUnit
                          : "$"
                      }
                      description={
                        selectedDiscInfo_data &&
                        selectedDiscInfo_data.description
                          ? selectedDiscInfo_data.description
                          : "Dish Description Not Available"
                      }
                      allergydetail={
                        selectedDiscInfo_data &&
                        selectedDiscInfo_data.allergensDetail
                          ? selectedDiscInfo_data.allergensDetail
                          : []
                      }
                      diateryDetail={
                        selectedDiscInfo_data &&
                        selectedDiscInfo_data.dietariesDetail
                          ? selectedDiscInfo_data.dietariesDetail
                          : []
                      }
                      lifestyleDetail={
                        selectedDiscInfo_data &&
                        selectedDiscInfo_data.lifestylesDetail
                          ? selectedDiscInfo_data.lifestylesDetail
                          : []
                      }
                      cookingDetail={
                        selectedDiscInfo_data &&
                        selectedDiscInfo_data.cooking_methods
                          ? selectedDiscInfo_data.cooking_methods
                          : []
                      }
                      dish_new_tag={
                        selectedDiscInfo_data && selectedDiscInfo_data.new
                          ? selectedDiscInfo_data.new
                          : false
                      }
                    />
                  </div>
                  <div className="col-sm-12 col-md-7 rsdiscinfo-rightcontent">
                    <SingleDiscIngredientTableComp
                      ingredient={
                        selectedDiscInfo_data &&
                        selectedDiscInfo_data.ingredientSection &&
                        selectedDiscInfo_data.ingredientSection.dish_ingredients
                          ? selectedDiscInfo_data.ingredientSection
                              .dish_ingredients
                          : []
                      }
                    />
                  </div>
                </div>
                <div className="row">
                  <div className="col-sm-12 col-md-12 col-lg-4 col-xl-4">
                    <RestaurantCookingMethodModal
                      cookingdata={
                        selectedDiscInfo_data &&
                        selectedDiscInfo_data.cooking_methods
                          ? selectedDiscInfo_data.cooking_methods
                          : []
                      }
                    />
                  </div>
                  <div className="col-sm-12 col-md-12 col-lg-4 col-xl-4">
                    <RestaurentDiscAllergiesInfoModal
                      allergydata={
                        selectedDiscInfo_data &&
                        selectedDiscInfo_data.allergensDetail
                          ? selectedDiscInfo_data.allergensDetail
                          : []
                      }
                    />
                  </div>
                  <div className="col-sm-12 col-md-12 col-lg-4 col-xl-4">
                    <RestaurentDiscCaloriesInfoModal
                      caloriesandmacrosdetail={
                        selectedDiscInfo_data &&
                        selectedDiscInfo_data.caloriesandmacrosDetail
                          ? selectedDiscInfo_data.caloriesandmacrosDetail
                          : {}
                      }
                    />
                  </div>
                </div>
              </React.Fragment>
            )}
          </React.Fragment>
        </div>
        <br></br>
        <br></br>
      </section>
    </>
  );
};

export default RestaurantSingleDiscInfoPage;
