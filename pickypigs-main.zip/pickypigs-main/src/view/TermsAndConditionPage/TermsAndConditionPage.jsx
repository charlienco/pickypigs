import React from "react";
import pattern_img from "../../assets/images/Pattern.png";
import OurVisionComponent from "../../components/OurVisionComponent/OurVisionComponent";
import "./TermsAndConditionPage.scss";
import {
  p1_tag,
  p2_tag,
  p3_tag,
  p4_tag,
  p5_tag,
  p6_tag,
  p7_tag,
  p7_1_tag,
} from "../../shared/termsAndCondition";

function TermsAndConditionPage() {
  return (
    <div className="terms_page_container">
      <br />
      <br />
      <br />
      <br />
      <br />
      <br />
      {/* Terms Page Content Start */}
      <section className="terms-section">
        <div className="container">
          <h1 className="header-txt text-center brandon-Bold text-uppercase">
            Picky Pigs – Terms and conditions
          </h1>

          <div className="terms-wrapper mt-5 mb-5">
            <div className="row">
              <div className="col-sm-12">
                <p className="f-15 font-weight-bold">
                  {" "}
                  <span className="mr-2">1.</span> INTRODUCTION
                </p>
                <hr />

                {p1_tag &&
                  p1_tag.map((item) => (
                    <p className="txt-lightgray f-15 mt-4 d-flex">
                      <span className="mr-2">1.{item.index}. </span>
                      {item.info}
                    </p>
                  ))}

                <p className="f-15 font-weight-bold">
                  <span className="mr-2">2.</span>Using our Services and Website
                </p>
                <hr />

                {p2_tag &&
                  p2_tag.map((item) => (
                    <p className="txt-lightgray f-15 mt-4 d-flex">
                      <span className="mr-2">2.{item.index}. </span>
                      {item.info}
                    </p>
                  ))}

                <p className="f-15 font-weight-bold">
                  <span className="mr-2">3.</span> Our payment terms
                </p>
                <hr />

                {p3_tag &&
                  p3_tag.map((item) => (
                    <p className="txt-lightgray f-15 mt-4 d-flex">
                      <span className="mr-2">3.{item.index}. </span>
                      {item.info}
                    </p>
                  ))}

                <p className="txt-lightgray f-15 mt-4 d-flex">
                  <span className="mr-2">3.11. </span>
                  <span>
                    Picky Pigs utilises Hyperwallet payment services to deliver
                    payments to you. Such payment services are subject to the
                    <a href="/#">
                       Hyperwallet Terms of Service and the  Hyperwallet Privacy
                      Policy
                    </a>
                    .
                  </span>
                </p>

                <p className="f-15 font-weight-bold">
                  <span className="mr-2">4.</span> Use of promotional codes
                </p>
                <hr />
                <p className="txt-lightgray f-15 mt-4 d-flex">
                  <span className="mr-2">4.1. </span>A Venue may offer
                  promotional codes that may provide you with discounts, bonus
                  offers or other incentives for you to use our Services (Venue
                  Promotional Codes). We agree to allow you to use valid Venue
                  Promotional Codes subject to any terms and conditions imposed
                  by the Venue and the following conditions:
                </p>

                {p4_tag &&
                  p4_tag.map((item) => (
                    <p className="txt-lightgray f-15 mt-2 d-flex pl-4 ml-1">
                      <span className="mr-2">({item.index}) </span>
                      {item.info}
                    </p>
                  ))}

                <p className="f-15 font-weight-bold">
                  <span className="mr-2">5.</span> Our content and access
                </p>
                <hr />
                {p5_tag &&
                  p5_tag.map((item) => (
                    <p className="txt-lightgray f-15 mt-4 d-flex">
                      <span className="mr-2">5.{item.index}. </span>
                      {item.info}
                    </p>
                  ))}

                <p className="f-15 font-weight-bold">
                  <span className="mr-2">6.</span> Intellectual Property
                </p>
                <hr />
                {p6_tag &&
                  p6_tag.map((item) => (
                    <p className="txt-lightgray f-15 mt-4 d-flex">
                      <span className="mr-2">6.{item.index}. </span>
                      {item.info}
                    </p>
                  ))}

                <p className="f-15 font-weight-bold">
                  <span className="mr-2">7.</span> Limitation of Liability
                </p>
                <hr />
                <p className="txt-lightgray f-15 mt-4 d-flex">
                  <span className="mr-2">7.1. </span>Picky Pigs disclaims all
                  liability for any loss or damage of any kind arising out of or
                  in connection with the Services and the Website content and
                  your use or performance of the Website and Services to a
                  maximum extent permitted by law including without limitation
                  and liability relating to:
                </p>

                {p7_1_tag &&
                  p7_1_tag.map((item) => (
                    <p className="txt-lightgray f-15 mt-2 d-flex pl-4 ml-1">
                      <span className="mr-2 ">{item.index} </span>
                      {item.info}
                    </p>
                  ))}

                {p7_tag &&
                  p7_tag.map((item) => (
                    <p className="txt-lightgray f-15 mt-4 d-flex">
                      <span className="mr-2">7.{item.index}. </span>
                      {item.info}
                    </p>
                  ))}

                <p className="f-15 font-weight-bold">
                  <span className="mr-2">8.</span> Indemnification
                </p>
                <hr />
                <p className="txt-lightgray f-15 mt-4 d-flex">
                  To the fullest extent of the law, you agree to indemnify us
                  from and against any and all liabilities, costs, demands,
                  causes of action, damages and expenses (including legal fees)
                  arising out of or in any way related to your breach of any of
                  the provisions of these Terms and/or your use of the Services
                  and Website.
                </p>

                <p className="f-15 font-weight-bold">
                  <span className="mr-2">9.</span> Severability
                </p>
                <hr />
                <p className="txt-lightgray f-15 mt-4 d-flex">
                  If any provision of these Terms is found to be unenforceable
                  or invalid under any applicable law, such unenforceability or
                  invalidity shall not render these Terms unenforceable or
                  invalid as a whole, and such provisions shall be deleted
                  without affecting the remaining provisions herein.
                </p>

                <p className="f-15 font-weight-bold">
                  <span className="mr-2">10.</span> Assignment
                </p>
                <hr />
                <p className="txt-lightgray f-15 mt-4 d-flex">
                  We are permitted to assign, transfer, and subcontract our
                  rights and/or obligations under these Terms without any
                  notification or consent to you. You are not permitted to
                  assign, transfer, or subcontract any of your rights and/or
                  obligations under these Terms.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
      {/* Terms Page Content Start */}

      <section>
        <div className="container">
          <div className="row">
            <div className="col-sm-12">
              <div className="patternimg-wrapper">
                <img
                  src={pattern_img}
                  className="img-fluid"
                  loading="lazy"
                  alt="img"
                />
              </div>
            </div>
          </div>
        </div>
      </section>
      <section>
        <OurVisionComponent />
      </section>
    </div>
  );
}

export default TermsAndConditionPage;
