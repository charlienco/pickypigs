import React from "react";

import pattern_img from "../../assets/images/Pattern.png";
import OurVisionComponent from "../../components/OurVisionComponent/OurVisionComponent";
import "./PrivacyPolicy.scss";
import {
  p1_tag,
  p3_tag,
  p4_tag,
  p5_tag,
  p6_tag,
  p7_tag,
  p8_tag,
  p9_tag,
  p10_tag,
  p11_tag,
  p12_tag,
  p13_tag,
} from "../../shared/privacyPolicy";

const PrivacyPolicy = () => {
  return (
    <div className="terms_page_container">
      <br />
      <br />
      <br />
      <br />
      <br />
      <br />
      {/* Terms Page Content Start */}
      <section className="terms-section">
        <div className="container">
          <h1 className="header-txt text-center brandon-Bold text-uppercase">
            Picky Pigs Privacy Policy
          </h1>
          {/* <p className="f-15 text-center">
                            Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam
                            <br /> nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam
                        </p> */}

          <div className="terms-wrapper mt-5 mb-5">
            <div className="row">
              <div className="col-sm-12">
                <p className="f-15 font-weight-bold">
                  <span className="mr-2">1.</span> INTRODUCTION
                </p>
                <hr />
                {p1_tag &&
                  p1_tag.map((item) => (
                    <>
                      <p className="txt-lightgray f-15 mt-4  mb-2 d-flex">
                        <span className="mr-3">1.{item.index}. </span>
                        {item.info}
                      </p>
                      {item.bullet_points && (
                        <ul className="pl-3 pl-5 ml-2">
                          {item.bullet_points &&
                            item.bullet_points.map((data, index) => {
                              return (
                                <React.Fragment key={index}>
                                  <li className="txt-lightgray f-15">
                                    <p className="mb-2">{data}</p>
                                  </li>
                                </React.Fragment>
                              );
                            })}
                        </ul>
                      )}
                    </>
                  ))}

                <p className="f-15 font-weight-bold">
                  <span className="mr-2">2.</span>WHAT IS PERSONAL INFORMATION?{" "}
                </p>
                <hr />

                <p className="txt-lightgray f-15 mt-4 d-flex">
                  When used in this policy, the className="mr-2" term “personal
                  information” has the meaning given to it in the Act. In
                  general terms, it is any information that can be used to
                  personally identify you. This may include (but is not limited
                  to) your name, age, gender, postcode and contact details
                  (including phone numbers and email addresses) and possibly
                  financial information, including your credit card or direct
                  debit account information. If the information we collect
                  personally identifies you, or you are reasonably identifiable
                  from it, the information will be considered personal
                  information.
                </p>

                <p className="f-15 font-weight-bold">
                  <span className="mr-2">3.</span> WHAT PERSONAL INFORMATION
                  DOES PICKY PIGS COLLECT AND HOLD
                </p>
                <hr />
                {p3_tag &&
                  p3_tag.map((item) => (
                    <>
                      <p className="txt-lightgray f-15 mt-4  mb-2 d-flex">
                        <span className="mr-3">3.{item.index}. </span>
                        {item.info}
                      </p>
                      {item.bullet_points && (
                        <ul className="pl-3 pl-5 ml-2">
                          {item.bullet_points &&
                            item.bullet_points.map((data, index) => {
                              return (
                                <React.Fragment key={index}>
                                  <li className="txt-lightgray f-15">
                                    <p className="mb-2">{data}</p>
                                  </li>
                                </React.Fragment>
                              );
                            })}
                        </ul>
                      )}
                    </>
                  ))}

                <p className="f-15 font-weight-bold">
                  <span className="mr-2">4.</span> HOW AND WHY DOES PICKY PIGS
                  COLLECT PERSONAL INFORMATION?
                </p>
                <hr />
                {p4_tag &&
                  p4_tag.map((item) => (
                    <>
                      <p className="txt-lightgray f-15 mt-4  mb-2 d-flex">
                        <span className="mr-3">4.{item.index}. </span>
                        {item.info}
                      </p>
                      {item.bullet_points && (
                        <ul className="pl-3 pl-5 ml-2">
                          {item.bullet_points &&
                            item.bullet_points.map((data, index) => {
                              return (
                                <React.Fragment key={index}>
                                  <li className="txt-lightgray f-15">
                                    <p className="mb-2">{data}</p>
                                  </li>
                                </React.Fragment>
                              );
                            })}
                        </ul>
                      )}
                    </>
                  ))}

                <p className="f-15 font-weight-bold">
                  <span className="mr-2">5. </span> WHAT HAPPENS IF WE CAN’T
                  COLLECT YOUR PERSONAL INFORMATION?
                </p>
                <hr />

                {p5_tag &&
                  p5_tag.map((item) => (
                    <p className="txt-lightgray f-15 mt-4 d-flex">
                      <span className="mr-3">5.{item.index}. </span>
                      {item.info}
                    </p>
                  ))}
                <p className="f-15 font-weight-bold">
                  <span className="mr-2">6. </span> USE OF FINANCIAL INFORMATION
                </p>
                <hr />

                {p6_tag &&
                  p6_tag.map((item) => (
                    <p className="txt-lightgray f-15 mt-4 d-flex">
                      <span className="mr-3">6.{item.index}. </span>
                      {item.info}
                    </p>
                  ))}

                <p className="f-15 font-weight-bold">
                  <span className="mr-2">7. </span> DIRECT MARKETING MATERIALS
                </p>
                <hr />
                {p7_tag &&
                  p7_tag.map((item) => (
                    <p className="txt-lightgray f-15 mt-4 d-flex">
                      <span className="mr-3">7.{item.index}. </span>
                      {item.info}
                    </p>
                  ))}

                <p className="f-15 font-weight-bold">
                  <span className="mr-2">8. </span> THIRD PARTY HOSTING
                </p>
                <hr />

                {p8_tag &&
                  p8_tag.map((item) => (
                    <p className="txt-lightgray f-15 mt-4 d-flex">
                      <span className="mr-3">8.{item.index}. </span>
                      {item.info}
                    </p>
                  ))}

                <p className="f-15 font-weight-bold">
                  <span className="mr-2">9. </span> WILL YOUR INFORMATION BE
                  DISCLOSED OVERSEAS?
                </p>
                <hr />

                {p9_tag &&
                  p9_tag.map((item) => (
                    <p className="txt-lightgray f-15 mt-4 d-flex">
                      <span className="mr-3">9.{item.index}. </span>
                      {item.info}
                    </p>
                  ))}

                <p className="f-15 font-weight-bold">
                  <span className="mr-2">10. </span> HOW CAN YOU ACCESS AND
                  CORRECT YOUR PERSONAL INFORMATION
                </p>
                <hr />

                {p10_tag &&
                  p10_tag.map((item) => (
                    <p className="txt-lightgray f-15 mt-4 d-flex">
                      <span className="mr-3">10.{item.index}. </span>
                      {item.info}
                    </p>
                  ))}

                <p className="f-15 font-weight-bold">
                  <span className="mr-2">11. </span> HOW WILL PICKY PIGS MAKE
                  SURE YOUR PERSONAL INFORMATION IS SECURE?
                </p>
                <hr />

                {p11_tag &&
                  p11_tag.map((item) => (
                    <p className="txt-lightgray f-15 mt-4 d-flex">
                      <span className="mr-3">11.{item.index}. </span>
                      {item.info}
                    </p>
                  ))}

                <p className="f-15 font-weight-bold">
                  <span className="mr-2">12. </span> DOES PICKY PIGS USE
                  “COOKIES”
                </p>
                <hr />

                {p12_tag &&
                  p12_tag.map((item) => (
                    <p className="txt-lightgray f-15 mt-4 d-flex">
                      <span className="mr-3">12.{item.index}. </span>
                      {item.info}
                    </p>
                  ))}

                <p className="f-15 font-weight-bold">
                  <span className="mr-2">13. </span> HOW WILL PICKY PIGS MAKE
                  SURE YOUR PERSONAL INFORMATION IS SECURE?
                </p>
                <hr />

                {p13_tag &&
                  p13_tag.map((item) => (
                    <p className="txt-lightgray f-15 mt-4 d-flex">
                      <span className="mr-3">13.{item.index}. </span>
                      {item.info}
                    </p>
                  ))}

                <p className="f-15 font-weight-bold">
                  <span className="mr-2">14. </span> WHO CAN YOU CONTACT ABOUT
                  YOUR PERSONAL INFORMATION?
                </p>
                <hr />

                <p className="txt-lightgray f-15 mt-4 d-flex">
                  <span className="mr-2">14.1. </span>
                  To contact Picky Pigs about your personal information,
                  concerns or complaints, email at
                  <a className="ml-1" href="mailto:sasha@pickypigs.com">
                    sasha@pickypigs.com
                  </a>
                  .
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
      {/* Terms Page Content Start */}

      <section>
        <div className="container">
          <div className="row">
            <div className="col-sm-12">
              <div className="patternimg-wrapper">
                <img
                  src={pattern_img}
                  className="img-fluid"
                  loading="lazy"
                  alt="img"
                />
              </div>
            </div>
          </div>
        </div>
      </section>
      <section>
        <OurVisionComponent />
      </section>
    </div>
  );
};

export default PrivacyPolicy;
