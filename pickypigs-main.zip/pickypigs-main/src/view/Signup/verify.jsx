import axios from 'axios';
import React, { useEffect } from 'react'
import { Link } from 'react-router-dom';
import { HOST_URL } from '../../shared/constant';

function Verify(props) {
    useEffect(() => {
        axios.post(`${HOST_URL}/auth/verification`, { token: props.match.params.token }).then((res) => {
            if (res.data.isVerified) {
                alert("You are verified")
            }
        }).catch(err => console.log('err =>', err))
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])
    return (
        <div>
            <h1>Verification !</h1>
            <Link to="/">Go to Home page.</Link>
        </div>
    )
}

export default Verify
