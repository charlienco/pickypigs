import React from "react";
import who_img from "../../assets/images/who/who-img.jpg";
import founder_img from "../../assets/images/who/Sasha.png";
import ourmission_img1 from "../../assets/images/who/ourmission-icon1.svg";
import ourmission_img2 from "../../assets/images/who/ourmission-icon2.svg";
import ourmission_img3 from "../../assets/images/who/ourmission-icon3.svg";
import ourmission_img4 from "../../assets/images/who/ourmission-icon4.svg";
import pattern_img from "../../assets/images/Pattern.png";
import OurVisionComponent from "../../components/OurVisionComponent/OurVisionComponent";

import "./TheWhoPage.scss";

function TheWhoPage({ filterIcon = "false" }) {
  return (
    <div className="the_who_page_container">
      <br />
      <br />
      <br />
      <br />
      <br />
      <br />
      <div
        className="gradient-bg"
        style={{
          height: "100vh",
          position: "absolute",
          top: 0,
          right: 0,
          width: "100%",
        }}
      ></div>
      {/* Who section 1 start */}
      <section className="who-section">
        <div className="container">
          <h1 className="text-center text-uppercase header-txt brandon-Medium position-relative">
            the who
          </h1>
          <p className="text-center f-15 position-relative">
            Just a little bit about the team behind Picky Pigs
          </p>
          <div className="row">
            <div className="col-sm-12">
              <div className="who-we-are-wrapper mt-4">
                <div className="who-we-are-img">
                  <img
                    src={who_img}
                    className="img-fluid"
                    loading="lazy"
                    alt="img"
                  />
                </div>
                <div className="who-we-are-info">
                  <h6 className="brandon-Medium fw-600 text-uppercase">
                    Who we are
                  </h6>

                  <p className="f-15 mb-2">
                    We are a team of Picky Pigs with over 18 years’ experience
                    in hospitality and 10 years’ experience in UX/UI design and
                    website/application development. We love to eat great food,
                    enjoy being surrounded by wonderful people and find any
                    excuse to dine out in restaurants and bars.
                  </p>
                  <p className="f-15 mb-2">
                    We believe that, no matter what your requirements or
                    preferences, you should never have to feel like a ‘fussy
                    feeder’ when you dine out. Our mission is to bridge the gap
                    between diners and restaurants, and between friends and
                    social networks, by helping them find a restaurant that
                    meets their every need. A fuss free food experience.
                  </p>
                  {/* <p className="f-15 mb-0">
                    With the application, you can embrace your inner Picky Pig.
                    We know we have, enhancing your entire dining out
                    experience, from searching, ordering to indulging.
                  </p> */}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      {/* Who section 1 end */}

      <br />
      <br />

      {/* Who section 2 start */}
      <section className="ourfounder-section mt-2">
        <div className="container">
          <div className="ourfounder-wrapper">
            <div className="row">
              <div className="col-sm-12 col-md-12 col-lg-6 col-xl-5 ourfounder-subleft pr-xl-0">
                <div className="ourfounder-user">
                  <div className="founder-img mb-3">
                    <img
                      src={founder_img}
                      className="img-fluid"
                      loading="lazy"
                      alt="img"
                    />
                  </div>
                  <h5 className="user-name text-center borndon-Medium fw-600">
                    Sasha Miljus
                  </h5>
                  {/* <p className="user-founder text-center f-15 mb-2">Founder</p> */}
                </div>
              </div>
              <div className="col-sm-12 col-md-12 col-lg-6 col-xl-7 ourfounder-subright">
                <div className="ourfounder-intro">
                  <h6 className="brandon-Medium fw-600 text-uppercase">
                    Our Founder
                  </h6>

                  <p className="f-15 mb-2">
                    Having worked in hospitality from a young age, Sasha Miljus
                    has seen the evolution of dietary trends, the rising profile
                    of allergens and the legal changes that have followed.
                  </p>
                  <p className="f-15 mb-2">
                    Early in her career, she worked for a restaurant group where
                    the worst happened. A lack of communication and clarity led
                    to a young girl dying from an allergic reaction. Picky Pigs
                    was born out of a desire to ensure nothing like that happens
                    again.
                  </p>
                  <p className="f-15 mb-2">
                    Sasha truly cares about giving people control and choice
                    over what they do or don’t put into their body. She follows
                    a plant-based, lactose-free and low gluten diet and wants to
                    have confidence in that experience. Eating out has sometimes
                    been a challenge, but she’s never given up on being a Picky
                    Pig.
                  </p>
                  <p className="f-15 mb-2">
                    By creating Picky Pigs, Sasha aims to support and protect
                    diners and restaurants alike for a safe and enjoyable dining
                    out experience.
                  </p>
                  {/* <p className="f-15 mb-0">
                    She wants the control and choice over what she does or
                    doesn't want to put into her body and wants to have
                    confidence in that experience. Picky Pigs means that every
                    guest can have that experience too.
                  </p> */}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      {/* Who section 2 end */}

      <br />
      <br />
      <br />
      <br />

      {/* Who section 3 start */}
      <section className="mission-section">
        <div className="container">
          <div className="ourmission-wrapper">
            <div className="container ourmission-container">
              <h1 className="text-center text-uppercase header-txt brandon-Medium fw-600 mb-5 pb-2">
                Our mission
              </h1>

              <div className="row">
                <div className="col-sm-12 col-md-6 col-lg-6 col-xl-6 ourmission-subwrapper">
                  <div className="ourmission-block text-center">
                    <div className="ourmission-icon light-blue-bg mb-3">
                      <img
                        src={ourmission_img1}
                        className="img-fluid"
                        loading="lazy"
                        alt="img"
                      />
                    </div>
                    <p className="f-15 ourmission-intro">
                      To make fuss free food more easily accessible, regardless
                      of dietary needs and preferences.
                    </p>
                  </div>
                </div>
                <div className="col-sm-12 col-md-6 col-lg-6 col-xl-6 ourmission-subwrapper">
                  <div className="ourmission-block text-center">
                    <div className="ourmission-icon light-green-bg mb-3">
                      <img
                        src={ourmission_img2}
                        className="img-fluid"
                        loading="lazy"
                        alt="img"
                      />
                    </div>
                    <p className="f-15 ourmission-intro">
                      To encourage and support transparency and build trust.
                    </p>
                  </div>
                </div>
                <div className="col-sm-12 col-md-6 col-lg-6 col-xl-6 ourmission-subwrapper">
                  <div className="ourmission-block text-center">
                    <div className="ourmission-icon light-morepich-bg mb-3">
                      <img
                        src={ourmission_img3}
                        className="img-fluid"
                        loading="lazy"
                        alt="img"
                      />
                    </div>
                    <p className="f-15 ourmission-intro">
                      To eliminate as much human error as possible.
                    </p>
                  </div>
                </div>
                <div className="col-sm-12 col-md-6 col-lg-6 col-xl-6 ourmission-subwrapper">
                  <div className="ourmission-block text-center">
                    <div className="ourmission-icon light-pink-bg mb-3">
                      <img
                        src={ourmission_img4}
                        className="img-fluid"
                        loading="lazy"
                        alt="img"
                      />
                    </div>
                    <p className="f-15 ourmission-intro">
                      To enhance the entire dining out experience from beginning
                      to end.
                    </p>
                  </div>
                </div>
              </div>

              <br />
              <br />
              <br />
              <br />

              <div className="row">
                <div className="col-sm-12">
                  <h6 className="brandon-Medium fw-600 text-uppercase text-center">
                    What we stand for
                  </h6>
                  <p className="f-15 text-center mb-2">
                    We believe everyone should be able to enjoy the experience
                    of dining out, without feeling like a ‘fussy feeder’. And we
                    want restaurants to feel they have the support and tools to
                    lead the way in meeting and even exceeding expectations.
                  </p>
                  <p className="f-15 text-center mb-0">
                    At Picky Pigs, we believe that the detail matters. We want
                    to raise the bar in both the customer journey and the
                    industry standard. With fuss free food from every angle,
                    nothing needs to be an issue with Picky Pigs.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      {/* Who section 3 end */}

      <section>
        <div className="container">
          <div className="row">
            <div className="col-sm-12">
              <div className="patternimg-wrapper">
                <img
                  src={pattern_img}
                  className="img-fluid"
                  loading="lazy"
                  alt="img"
                />
              </div>
            </div>
          </div>
        </div>
      </section>
      <section>
        <OurVisionComponent />
      </section>
    </div>
  );
}

export default TheWhoPage;
