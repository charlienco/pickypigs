import React from "react";
import pattern_img from "../../assets/images/Pattern.png";
import down_arrow from "../../assets/images/who/down-arrow.svg";
import search_grey from "../../assets/images/who/search_grey.svg";
import OurVisionComponent from "../../components/OurVisionComponent/OurVisionComponent";

import "./TheFaqPage.scss";

function TheFaqPage() {
  return (
    <div className="the_faq_page_container">
      <br />
      <br />
      <br />
      <br />
      <br />
      <br />
      <div
        className="gradient-bg"
        style={{
          height: "100vh",
          position: "absolute",
          top: 0,
          right: 0,
          width: "100%",
        }}
      ></div>
      {/* Faq Page content start */}
      <section className="faq-section position-relative">
        <div className="container">
          <h1 className="header-txt text-center brandon-Bold text-uppercase">
            FAQ
          </h1>
          <p className="f-15 text-center">
            Frequently asked questions on how we work and how to add your restaurant.
            <br />
            No question is a silly question, the more you ask the more we know how to improve our service but equally find answers and solutions, so please if you can see you question here, email us at support@pickypigs.com.
          </p>

          <div className="row mt-4 mb-5">
            <div className="col-sm-12 mb-3">
              <div className="searchfaq-input position-relative ml-auto mr-auto">
                <input
                  placeholder="Search FAQ"
                  type="text"
                  className="input-search form-control"
                />
                <div className="search-icon">
                  <img
                    src={search_grey}
                    className="img-fluid"
                    loading="lazy"
                    alt="img"
                  />
                </div>
              </div>
            </div>
          </div>

          <div className="row">
            <div className="col-sm-12">
              <div
                className="accordion faq-accordion-wrapper"
                id="accordionExample"
              >
                <div className="card mb-2 faq-accordion">
                  <div className="card-header faq-heading" id="headingOne">
                    <h2 className="mb-0 w-100">
                      <button
                        className="btn btn-link btn-block text-dark text-decoration-none faq-btn text-left pl-0 pr-0 d-flex justify-content-between align-items-center position-relative"
                        type="button"
                        data-toggle="collapse"
                        data-target="#collapseOne"
                        aria-expanded="true"
                        aria-controls="collapseOne"
                      >
                        <p className="mb-0 f-15 faq-label">
                          Question 1  - What is the best order to add my restaurant?
                        </p>
                        <div className="faq-arrow arrow-down">
                          <img
                            width="14"
                            src={down_arrow}
                            className="img-fluid"
                            loading="lazy"
                            alt="img"
                          />
                        </div>
                      </button>
                    </h2>
                  </div>
                  <div
                    id="collapseOne"
                    className="collapse show"
                    aria-labelledby="headingOne"
                    data-parent="#accordionExample"
                  >
                    <div className="card-body pb-5 pl-0 pr-0">
                      <p className="txt-lightgray f-15 mt-4  mb-2 d-flex">
                        <span className="mr-3">1.1. </span>
                        The best was to add your venue is by starting with making sure you have all the information you need for the settings, this will help you set your restaurant up as quickly as possible. You will need: contact info, address, opening times, booking, website and social information, your logo and cover picture, finally images of your venue and food. Remember, you get to choose these images over the guests, so can represent you business how you see it best.
                      </p>
                      <p className="txt-lightgray f-15 mt-4  mb-2 d-flex">
                        <span className="mr-3">1.2. </span>
                        Then the best order to go from here is:
                      </p>
                      <ul className="pl-3 pl-5 ml-2">
                        <li className="txt-lightgray f-15">
                          <p className="mb-2">First set up your menus, you can break your menus down into different times of day, maybe even different offerings within your business, be it set menu, bar nibbles or desserts. </p>
                        </li>
                        <li className="txt-lightgray f-15">
                          <p className="mb-2">Next you’ll want to set up the categories that assign to each menu, this is to help you divide your menu to be a close as possible to your venues menu. This could be starter, main, dessert or maybe even salads, on bread or grill. NOTE: You’ll need to create 2 of one category if it’s the same for different menus and make sure you can identify which menu it assigns to. </p>
                        </li>
                        <li className="txt-lightgray f-15">
                          <p className="mb-2">Sub – Category is the next set up, this isn’t a required section and may not be needed. However this gives an extra layer of division in your menu should your restaurant need it. For example, you might divide you menu into small plates, mains and desserts, then wish to further divide by adding steamed, fried and raw or even meat, fish and veg.</p>
                        </li>
                        <li className="txt-lightgray f-15">
                          <p className="mb-2">Once you have created the menu and categories, you can then go on to adding your dishes. For each dish you will need a picture, title, price, description, ingredients breakdown, all its allergies, dietaries and preferences, cooking method and for even more detail you can add calories and macros. The dish will need to be assigned to its relevant menu and categories.</p>
                        </li>
                        <li className="txt-lightgray f-15">
                          <p className="mb-2">Then keep adding. You can duplicate dishes if you have similar items on your menu.</p>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
                <div className="card mb-2 faq-accordion">
                  <div className="card-header faq-heading" id="headingTwo">
                    <h2 className="mb-0 w-100">
                      <button
                        className="btn btn-link btn-block text-dark text-decoration-none faq-btn text-left pl-0 pr-0 d-flex justify-content-between align-items-center position-relative collapsed"
                        type="button"
                        data-toggle="collapse"
                        data-target="#collapseTwo"
                        aria-expanded="false"
                        aria-controls="collapseTwo"
                      >
                        <p className="mb-0 f-15 faq-label">
                          Question 2  - When creating a menu, what does “Style of menu” mean?
                        </p>
                        <div className="faq-arrow arrow-down">
                          <img
                            width="14"
                            src={down_arrow}
                            className="img-fluid"
                            loading="lazy"
                            alt="img"
                          />
                        </div>
                      </button>
                    </h2>
                  </div>
                  <div
                    id="collapseTwo"
                    className="collapse"
                    aria-labelledby="headingTwo"
                    data-parent="#accordionExample"
                  >
                    <div className="card-body pb-5 pl-0 pr-0">
                      <p className="txt-lightgray f-15 mt-4  mb-2 d-flex">
                        <span className="mr-3">2.1. </span>
                        This is a multiple choice selection and will allow the user to search for a restaurant or menu based on the occasion, be it nibbles, breakfast, dinner or set menu. Make sure to select all the relevant ones so you come up in the most amount of searches.
                      </p>
                    </div>
                  </div>
                </div>
                <div className="card mb-2 faq-accordion">
                  <div className="card-header faq-heading" id="headingThree">
                    <h2 className="mb-0 w-100">
                      <button
                        className="btn btn-link btn-block text-dark text-decoration-none faq-btn text-left pl-0 pr-0 d-flex justify-content-between align-items-center position-relative collapsed"
                        type="button"
                        data-toggle="collapse"
                        data-target="#collapseThree"
                        aria-expanded="false"
                        aria-controls="collapseThree"
                      >
                        <p className="mb-0 f-15 faq-label">
                          Question 3  - When adding the settings, what does “What extra features does your restaurant” mean?
                        </p>
                        <div className="faq-arrow arrow-down">
                          <img
                            width="14"
                            src={down_arrow}
                            className="img-fluid"
                            loading="lazy"
                            alt="img"
                          />
                        </div>
                      </button>
                    </h2>
                  </div>
                  <div
                    id="collapseThree"
                    className="collapse"
                    aria-labelledby="headingThree"
                    data-parent="#accordionExample"
                  >
                    <div className="card-body pb-5 pl-0 pr-0">
                      <p className="txt-lightgray f-15 mt-4  mb-2 d-flex">
                        <span className="mr-3">3.1. </span>
                        This will allow you to add restaurants features that aren’t listed in the multiple selection above but that you might wish to showcase about your venue. This could be that you do a quiz night, or have a games room.
                      </p>
                    </div>
                  </div>
                </div>
                <div className="card mb-2 faq-accordion">
                  <div className="card-header faq-heading" id="headingThree">
                    <h2 className="mb-0 w-100">
                      <button
                        className="btn btn-link btn-block text-dark text-decoration-none faq-btn text-left pl-0 pr-0 d-flex justify-content-between align-items-center position-relative collapsed"
                        type="button"
                        data-toggle="collapse"
                        data-target="#collapseFour"
                        aria-expanded="false"
                        aria-controls="collapseFour"
                      >
                        <p className="mb-0 f-15 faq-label">
                          Question 4  - When adding a dish, what does “customisable” mean at the bottom of the page?
                        </p>
                        <div className="faq-arrow arrow-down">
                          <img
                            width="14"
                            src={down_arrow}
                            className="img-fluid"
                            loading="lazy"
                            alt="img"
                          />
                        </div>
                      </button>
                    </h2>
                  </div>
                  <div
                    id="collapseFour"
                    className="collapse"
                    aria-labelledby="headingThree"
                    data-parent="#accordionExample"
                  >
                    <div className="card-body pb-5 pl-0 pr-0">
                      <p className="txt-lightgray f-15 mt-4  mb-2 d-flex">
                        <span className="mr-3">4.1. </span>
                        When customisable is selected at the bottom of the page, this will show on the front end to the diner that they’re able to amend elements of the dish. When you add each individual ingredient, of course this allows you to show each element that you can amend or not, however if you want to add another layer of communication and transparency you can tick this option and it will show up on the front end. If for example you are adding a soup or stew, and nothing is customisable, then do not select it and it wont show.
                      </p>
                    </div>
                  </div>
                </div>
                
                <div className="card mb-2 faq-accordion">
                  <div className="card-header faq-heading" id="headingThree">
                    <h2 className="mb-0 w-100">
                      <button
                        className="btn btn-link btn-block text-dark text-decoration-none faq-btn text-left pl-0 pr-0 d-flex justify-content-between align-items-center position-relative collapsed"
                        type="button" data-toggle="collapse" data-target="#collapseSix" aria-expanded="false"
                        aria-controls="collapseSix">
                        <p className="mb-0 f-15 faq-label">
                          Question 5 - How big does my logo image have to be to fit in the box?
                        </p>
                        <div className="faq-arrow arrow-down">
                          <img width="14" src={down_arrow} className="img-fluid" loading="lazy" alt="img" />
                        </div>
                      </button>
                    </h2>
                  </div>
                  <div id="collapseSix" className="collapse" aria-labelledby="headingThree" data-parent="#accordionExample">
                    <div className="card-body pb-5 pl-0 pr-0">
                      <p className="txt-lightgray f-15 mt-4  mb-2 d-flex">
                        <span className="mr-3">5.1. </span>
                        You will need to use a clear image that is height: 120px, weight: 120px.
                      </p>
                    </div>
                  </div>
                </div>
                <div className="card mb-2 faq-accordion">
                  <div className="card-header faq-heading" id="headingThree">
                    <h2 className="mb-0 w-100">
                      <button
                        className="btn btn-link btn-block text-dark text-decoration-none faq-btn text-left pl-0 pr-0 d-flex justify-content-between align-items-center position-relative collapsed"
                        type="button" data-toggle="collapse" data-target="#collapseSeven" aria-expanded="false"
                        aria-controls="collapseSeven">
                        <p className="mb-0 f-15 faq-label">
                          Question 6 - How big does my cover image have to be to fit in the box?
                        </p>
                        <div className="faq-arrow arrow-down">
                          <img width="14" src={down_arrow} className="img-fluid" loading="lazy" alt="img" />
                        </div>
                      </button>
                    </h2>
                  </div>
                  <div id="collapseSeven" className="collapse" aria-labelledby="headingThree" data-parent="#accordionExample">
                    <div className="card-body pb-5 pl-0 pr-0">
                      <p className="txt-lightgray f-15 mt-4  mb-2 d-flex">
                        <span className="mr-3">6.1. </span>
                        You will need to use a clear image that is height: 300px, weight: 1660px.
                      </p>
                    </div>
                  </div>
                </div>
                <div className="card mb-2 faq-accordion">
                  <div className="card-header faq-heading" id="headingThree">
                    <h2 className="mb-0 w-100">
                      <button
                        className="btn btn-link btn-block text-dark text-decoration-none faq-btn text-left pl-0 pr-0 d-flex justify-content-between align-items-center position-relative collapsed"
                        type="button" data-toggle="collapse" data-target="#collapseEight" aria-expanded="false"
                        aria-controls="collapseEight">
                        <p className="mb-0 f-15 faq-label">
                          Question 7 - How do I add a set menu?
                        </p>
                        <div className="faq-arrow arrow-down">
                          <img width="14" src={down_arrow} className="img-fluid" loading="lazy" alt="img" />
                        </div>
                      </button>
                    </h2>
                  </div>
                  <div id="collapseEight" className="collapse" aria-labelledby="headingThree" data-parent="#accordionExample">
                    <div className="card-body pb-5 pl-0 pr-0">
                      <p className="txt-lightgray f-15 mt-4  mb-2 d-flex">
                        <span className="mr-3">7.1. </span>
                        You can add a menu like you normally would with what the deal is and the times its available, eg: 2
                        courses $45/ 3 course $60 (5-7pm). From there in the category, you might wish to add choose 1 or choose
                        2, eg: Starters (Choose 1), mains (choose 2).
                      </p>
                      <p className="txt-lightgray f-15 mt-4  mb-2 d-flex">
                        <span className="mr-3">7.2. </span>
                        When adding a dish for the set menu you can choose not to add a price, or even add the additional charge
                        if there is one.
                      </p>
                      <p className="txt-lightgray f-15 mt-4  mb-2 d-flex">
                        <span className="mr-3">7.3. </span>
                        In the description you make also choose to add the terms of the set menu once again, or if there is an
                        addition charge on that particular choice.
                      </p>
                    </div>
                  </div>
                </div>
                <div className="card mb-2 faq-accordion">
                  <div className="card-header faq-heading" id="headingThree">
                    <h2 className="mb-0 w-100">
                      <button
                        className="btn btn-link btn-block text-dark text-decoration-none faq-btn text-left pl-0 pr-0 d-flex justify-content-between align-items-center position-relative collapsed"
                        type="button" data-toggle="collapse" data-target="#collapseNine" aria-expanded="false"
                        aria-controls="collapseNine">
                        <p className="mb-0 f-15 faq-label">
                          Question 8 - How do I add a tasting menu?
                        </p>
                        <div className="faq-arrow arrow-down">
                          <img width="14" src={down_arrow} className="img-fluid" loading="lazy" alt="img" />
                        </div>
                      </button>
                    </h2>
                  </div>
                  <div id="collapseNine" className="collapse" aria-labelledby="headingThree" data-parent="#accordionExample">
                    <div className="card-body pb-5 pl-0 pr-0">
                      <p className="txt-lightgray f-15 mt-4  mb-2 d-flex">
                        <span className="mr-3">8.1. </span>
                        A tasting menu is easier to add, similar to the set menu, you call the menu the name of the tasting menu
                        and may wish to add the available time into the title so that its available on the front end. Eg: Lets
                        Eat Menu (6-9pm), for the category, this will add another title so you could have a one liner to explain
                        what the “lets eat menu” is all about, eg: Our faves for you. Then simply create one dish that will
                        include the price and the description of the menu and anything to note. When adding the title of the
                        dish, this again might be more description or added details, eg: 6 – 10 of our best dishes, or let us
                        look after you.
                      </p>
                    </div>
                  </div>
                </div>
                <div className="card mb-2 faq-accordion">
                  <div className="card-header faq-heading" id="headingThree">
                    <h2 className="mb-0 w-100">
                      <button
                        className="btn btn-link btn-block text-dark text-decoration-none faq-btn text-left pl-0 pr-0 d-flex justify-content-between align-items-center position-relative collapsed"
                        type="button" data-toggle="collapse" data-target="#collapseTen" aria-expanded="false"
                        aria-controls="collapseTen">
                        <p className="mb-0 f-15 faq-label">
                          Question 9 - I can’t log in and my email address is correct?
                        </p>
                        <div className="faq-arrow arrow-down">
                          <img width="14" src={down_arrow} className="img-fluid" loading="lazy" alt="img" />
                        </div>
                      </button>
                    </h2>
                  </div>
                  <div id="collapseTen" className="collapse" aria-labelledby="headingThree" data-parent="#accordionExample">
                    <div className="card-body pb-5 pl-0 pr-0">
                      <p className="txt-lightgray f-15 mt-4  mb-2 d-flex">
                        <span className="mr-3">9.1. </span>
                        The email address is case sensitive so make sure there a no capital letters in your user name and try
                        again.
                      </p>
                    </div>
                  </div>
                </div>
                <div className="card mb-2 faq-accordion">
                  <div className="card-header faq-heading" id="headingThree">
                    <h2 className="mb-0 w-100">
                      <button
                        className="btn btn-link btn-block text-dark text-decoration-none faq-btn text-left pl-0 pr-0 d-flex justify-content-between align-items-center position-relative collapsed"
                        type="button" data-toggle="collapse" data-target="#collapseEleven" aria-expanded="false"
                        aria-controls="collapseEleven">
                        <p className="mb-0 f-15 faq-label">
                          Question 10 - What do the red and green dots mean on the corner of the menu?
                        </p>
                        <div className="faq-arrow arrow-down">
                          <img width="14" src={down_arrow} className="img-fluid" loading="lazy" alt="img" />
                        </div>
                      </button>
                    </h2>
                  </div>
                  <div id="collapseEleven" className="collapse" aria-labelledby="headingThree" data-parent="#accordionExample">
                    <div className="card-body pb-5 pl-0 pr-0">
                      <p className="txt-lightgray f-15 mt-4  mb-2 d-flex">
                        <span className="mr-3">10.1. </span>
                        Green simply means that the restaurant is open and that the dish is currently available. Red means that
                        its closed or that particular menu/dish isn’t available at that time.
                      </p>
                    </div>
                  </div>
                </div>
                <div className="card mb-2 faq-accordion">
                  <div className="card-header faq-heading" id="headingThree">
                    <h2 className="mb-0 w-100">
                      <button
                        className="btn btn-link btn-block text-dark text-decoration-none faq-btn text-left pl-0 pr-0 d-flex justify-content-between align-items-center position-relative collapsed"
                        type="button" data-toggle="collapse" data-target="#collapseTwelve" aria-expanded="false"
                        aria-controls="collapseTwelve">
                        <p className="mb-0 f-15 faq-label">
                          Question 11 - What does “Pigged out” mean?
                        </p>
                        <div className="faq-arrow arrow-down">
                          <img width="14" src={down_arrow} className="img-fluid" loading="lazy" alt="img" />
                        </div>
                      </button>
                    </h2>
                  </div>
                  <div id="collapseTwelve" className="collapse" aria-labelledby="headingThree" data-parent="#accordionExample">
                    <div className="card-body pb-5 pl-0 pr-0">
                      <p className="txt-lightgray f-15 mt-4  mb-2 d-flex">
                        <span className="mr-3">11.1. </span>
                        Pigged out means that the dish has sold out for the day.
                      </p>
                    </div>
                  </div>
                </div>
                <div className="card mb-2 faq-accordion">
                  <div className="card-header faq-heading" id="headingThree">
                    <h2 className="mb-0 w-100">
                      <button
                        className="btn btn-link btn-block text-dark text-decoration-none faq-btn text-left pl-0 pr-0 d-flex justify-content-between align-items-center position-relative collapsed"
                        type="button" data-toggle="collapse" data-target="#collapseThirteen" aria-expanded="false"
                        aria-controls="collapseThirteen">
                        <p className="mb-0 f-15 faq-label">
                          Question 12 - I have multiple allergies and requirements, is there a limit to how many I can add?
                        </p>
                        <div className="faq-arrow arrow-down">
                          <img width="14" src={down_arrow} className="img-fluid" loading="lazy" alt="img" />
                        </div>
                      </button>
                    </h2>
                  </div>
                  <div id="collapseThirteen" className="collapse" aria-labelledby="headingThree" data-parent="#accordionExample">
                    <div className="card-body pb-5 pl-0 pr-0">
                      <p className="txt-lightgray f-15 mt-4  mb-2 d-flex">
                        <span className="mr-3">12.1. </span>
                        No! That’s the beauty of Picky Pigs, you can add as many filters as you require. Something to note is
                        that the more you add, of course this might minimise and limit your choices, so choice relatively wisely
                        which filters are the most important for you. Equally, make sure to select that you are happy to see
                        something that can be available for your requirement. Eg: Vegan, vegan available.
                      </p>
                    </div>
                  </div>
                </div>
                <div className="card mb-2 faq-accordion">
                  <div className="card-header faq-heading" id="headingThree">
                    <h2 className="mb-0 w-100">
                      <button
                        className="btn btn-link btn-block text-dark text-decoration-none faq-btn text-left pl-0 pr-0 d-flex justify-content-between align-items-center position-relative collapsed"
                        type="button" data-toggle="collapse" data-target="#collapseFourteen" aria-expanded="false"
                        aria-controls="collapseFourteen">
                        <p className="mb-0 f-15 faq-label">
                          Question 13 - Can I save multiple users on one log in?
                        </p>
                        <div className="faq-arrow arrow-down">
                          <img width="14" src={down_arrow} className="img-fluid" loading="lazy" alt="img" />
                        </div>
                      </button>
                    </h2>
                  </div>
                  <div id="collapseFourteen" className="collapse" aria-labelledby="headingThree" data-parent="#accordionExample">
                    <div className="card-body pb-5 pl-0 pr-0">
                      <p className="txt-lightgray f-15 mt-4  mb-2 d-flex">
                        <span className="mr-3">13.1. </span>
                        Sadly not, this isn’t a function of the website yet, however this feature will be coming in the near
                        future, if this is for your child or for a friend of family member, we would suggest that if they can
                        they set up their own user and save their own preferences, this can then be saved on their browser and
                        will always go back to their needs when they log in.
                      </p>
                      <p className="txt-lightgray f-15 mt-4  mb-2 d-flex">
                        <span className="mr-3">13.2. </span>
                        If it is for a child and they’re unable to create their own log in, it depends if you also have
                        requirements, however, we would suggest save which even one of you needs it most or have the most amount
                        of requirements and then you can just clear the search whilst logged in and select to allergies and
                        filters needed, this wont reset the saved preferences for the profile, but will allow you to search for
                        both guests.
                      </p>
                    </div>
                  </div>
                </div>
                <div className="card mb-2 faq-accordion">
                  <div className="card-header faq-heading" id="headingThree">
                    <h2 className="mb-0 w-100">
                      <button
                        className="btn btn-link btn-block text-dark text-decoration-none faq-btn text-left pl-0 pr-0 d-flex justify-content-between align-items-center position-relative collapsed"
                        type="button" data-toggle="collapse" data-target="#collapseFifteen" aria-expanded="false"
                        aria-controls="collapseFifteen">
                        <p className="mb-0 f-15 faq-label">
                          Question 14 - I’m trying to add my preferences and it won’t let me?
                        </p>
                        <div className="faq-arrow arrow-down">
                          <img width="14" src={down_arrow} className="img-fluid" loading="lazy" alt="img" />
                        </div>
                      </button>
                    </h2>
                  </div>
                  <div id="collapseFifteen" className="collapse" aria-labelledby="headingThree" data-parent="#accordionExample">
                    <div className="card-body pb-5 pl-0 pr-0">
                      <p className="txt-lightgray f-15 mt-4  mb-2 d-flex">
                        <span className="mr-3">14.1. </span>
                        Before trying to add them make sure you select edit in the right hand corner of that particular
                        selection otherwise it isn’t open for editing, and always remember to press save.
                      </p>
                    </div>
                  </div>
                </div>
                <div className="card mb-2 faq-accordion">
                  <div className="card-header faq-heading" id="headingThree">
                    <h2 className="mb-0 w-100">
                      <button
                        className="btn btn-link btn-block text-dark text-decoration-none faq-btn text-left pl-0 pr-0 d-flex justify-content-between align-items-center position-relative collapsed"
                        type="button" data-toggle="collapse" data-target="#collapseSixteen" aria-expanded="false"
                        aria-controls="collapseSixteen">
                        <p className="mb-0 f-15 faq-label">
                          Question 15 - I’m adding all the details into the settings but it isn’t showing on the front end?
                        </p>
                        <div className="faq-arrow arrow-down">
                          <img width="14" src={down_arrow} className="img-fluid" loading="lazy" alt="img" />
                        </div>
                      </button>
                    </h2>
                  </div>
                  <div id="collapseSixteen" className="collapse" aria-labelledby="headingThree" data-parent="#accordionExample">
                    <div className="card-body pb-5 pl-0 pr-0">
                      <p className="txt-lightgray f-15 mt-4  mb-2 d-flex">
                        <span className="mr-3">15.1. </span>
                        Make sure in every layer of the settings that you press edit, add and save, otherwise it wont add the
                        information and it wont display on the front end. When adding links to the social or website, you must
                        press “add”, this feature is there as you might have multiple that you would like to add. Always
                        remember to press SAVE.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      {/* Faq Page content end */}

      <section>
        <div className="container">
          <div className="row">
            <div className="col-sm-12">
              <div className="patternimg-wrapper">
                <img
                  src={pattern_img}
                  className="img-fluid"
                  loading="lazy"
                  alt="img"
                />
              </div>
            </div>
          </div>
        </div>
      </section>
      <section>
        <OurVisionComponent />
      </section>
    </div>
  );
}

export default TheFaqPage;
