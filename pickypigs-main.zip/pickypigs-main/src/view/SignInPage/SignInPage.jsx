import React, { useState } from "react";
import axios from "axios";
import {
  FACEBOOK_APP_ID,
  GOOGLE_CLIENT_ID,
  HOST_URL,
} from "../../shared/constant";
import { Field, Form, Formik } from "formik";
import * as Yup from "yup";
import { Link, useHistory } from "react-router-dom";
import GoogleLogin from "react-google-login";
import useAppState from "../../context/useAppState";
import showpassword from "../../assets/images/eye_icon.svg";
import closeicon from "../../assets/images/close.svg";
import "./SignInPage.scss";
import { useDispatch, useSelector } from "react-redux";
import {
  facebookLogin,
  getLogin,
  googleLogin,
  showForgotPasswordPopup,
} from "../../redux/actions/generalActions";
import SocialButton from "../../components/SocialButton";
import CustomLoadingComp from "../../components/CustomLoadingComp/CustomLoadingComp";

// const passwordRegExp = RegExp(/^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})/);
const passwordRegExp = RegExp(
  // eslint-disable-next-line
  /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})/
);

const validationSchemaForLogin = Yup.object().shape({
  email: Yup.string()
    .email("Email must be a valid email")
    .required("Email Required"),
  password: Yup.string()
    .label("Password")
    .required("Password Required")
    .min(8, "Seems a bit short(Min 8 characters)...")
    .max(24, "Please try a shorter password(Max 24 characters)...).")
    .matches(
      passwordRegExp,
      "Password should Have 1 Uppercase,1 Lowercase,1 digit,1 special characte"
    ),
});

const SignInPage = (props) => {
  const dispatch = useDispatch();
  const history = useHistory();
  const { setLogin } = useAppState("useGlobal");
  const [type, setType] = useState("password");

  const handleSocialLogin = (user) => {
    if (user._provider === "facebook") {
      let obj = {
        email: user._profile.email,
        facebookId: user._profile.id,
        name: user._profile.name,
        // token: user._token.accessToken,
      };
      dispatch(facebookLogin(obj, history, "signIn"));
    }
    if (user._provider === "google") {
      // console.log(user);
      let obj = {
        email: user._profile.email,
        googleId: user._profile.id,
        name: user._profile.name,
        // token: user._token.accessToken,
      };
      dispatch(googleLogin(obj, history, "signIn"));
    }
  };

  const handleSocialLoginFailure = (err) => {
    console.error(err);
  };

  const googleResponse = (response) => {
    axios
      .post(`${HOST_URL}/auth/google`, response.profileObj)
      .then((res) => {
        console.log('google res =>',res);
        setLogin(res.data.token);
        console.log(res.data.token);
        props.onHide();
      })
      .catch((err) => console.log("err => ", err.response));
  };

  //   const facebookResponse = async (response) => {
  //     axios
  //       .post(`${HOST_URL}/auth/facebook`, response)
  //       .then((res) => {
  //         setLogin(res.data.token);
  //         props.onHide();
  //       })
  //       .catch((err) => console.log("err => ", err.response));
  //   };

  const handlePassword = () => {
    let ele = document.getElementById("password");
    if (type === "password") {
      ele.classList.add("show");
      setType("text");
    } else {
      ele.classList.remove("show");
      setType("password");
    }
  };

  const handleLoginForm = (input, { setStatus, resetForm }) => {
    let obj = {
      email: input.email,
      password: input.password,
    };

    dispatch(getLogin(obj, history));
  };

  let loading = useSelector((state) => {
    return state.general.isLoading;
  });

  return (
    <div className="row">
      <div className="col-sm-12 col-md-6 col-lg-6 col-xl-6 signup-left">
        <div className="hello-msg">
          <h1 className="text-uppercase text-white brandon-Bold">
            Hello
            <br />
            Newbie
          </h1>
        </div>
      </div>
      <div className="col-sm-12 col-md-6 col-lg-6 col-xl-6 signup-right">
        <div className="row">
          <div className="col-sm-12">
            <button
              className="btn modalclose-icon"
              onClick={() => {
                props.onHide();
              }}
            >
              <img
                src={closeicon}
                alt="close_icon"
                className="img-fluid"
                loading="lazy"
              />
            </button>
          </div>
        </div>
        <div className="row">
          <div className="col-sm-12 mb-3">
            <h3 className="brandon-Bold">Sign in</h3>
            <p className="f-15">
              <span className="pr-2">Don't have an account?</span>

              <button
                className="pink-txt brandon-Medium trans_button"
                onClick={() => {
                  props.gotoSignup();
                }}
              >
                Sign Up
              </button>
            </p>
          </div>
        </div>
        <Formik
          initialValues={{ email: "", password: "" }}
          validationSchema={validationSchemaForLogin}
          onSubmit={handleLoginForm}
        >
          {({
            values,
            errors,
            touched,
            handleChange,
            handleBlur,
            isSubmitting,
            /* and other goodies */
          }) => (
            <Form>
              <div className="row">
                <div className="col-sm-12">
                  <div className="form-group">
                    <Field
                      name="email"
                      placeholder="Email"
                      className="form-control signup-input"
                    />
                    {touched.email && errors.email && (
                      <div className="error pink-txt f-11">{errors.email}</div>
                    )}
                  </div>
                  <div className="form-group position-relative">
                    <Field
                      type={type}
                      name="password"
                      placeholder="Password"
                      className="form-control signup-input"
                    />
                    <div
                      className="showpassword-block"
                      id="password"
                      onClick={() => handlePassword()}
                    >
                      <img
                        src={showpassword}
                        className="img-fluid"
                        alt="showpassword"
                        loading="lazy"
                      />
                    </div>
                    <div className="error pink-txt f-11">
                      {touched.password && errors.password && errors.password}
                    </div>
                  </div>
                  <div className="forgot-block mt-3 mb-3">
                    <button
                      type="button"
                      className="forgot-link trans_button"
                      onClick={() => {
                        props.openForgotPass();
                        dispatch(showForgotPasswordPopup(true));
                      }}
                    >
                      <span>Forgot Password</span>
                    </button>
                  </div>
                  <div className="form-group">
                    <button
                      className="pinkline-btn signup-btn btn mt-4 w-100 text-uppercase border-radius-25"
                      type="submit"
                    >
                      Sign in
                    </button>
                  </div>
                </div>
              </div>
            </Form>
          )}
        </Formik>
        <React.Fragment>
          {loading ? <CustomLoadingComp /> : null}
        </React.Fragment>

        <React.Fragment>
          <div className="row">
            <div className="col-sm-12">
              <div className="form-group mt-2 pt-2">
                <div className="border-separate"></div>
              </div>
              <div className="or-txt f-15">
                <span>or</span>
              </div>
            </div>
          </div>

          <div className="row">
            <div className="col-sm-12 pl-xl-4 pr-xl-4">
              <div className="socail-login d-flex justify-content-between align-items-center mt-3 pl-5 pr-5">
                {/* <GoogleLo  */}

                <SocialButton
                  style={{ backgroundColor: "transparent", border: "none" }}
                  provider={"facebook"}
                  appId={FACEBOOK_APP_ID}
                  onLoginSuccess={handleSocialLogin}
                  onLoginFailure={handleSocialLoginFailure}
                >
                  <div className="btnFacebook socail-btn"></div>
                </SocialButton>
                <SocialButton
                  style={{ backgroundColor: "transparent", border: "none" }}
                  provider={"google"}
                  appId={GOOGLE_CLIENT_ID}
                  onLoginSuccess={handleSocialLogin}
                  onLoginFailure={handleSocialLoginFailure}
                >
                  <div className="btnGoogle socail-btn"></div>
                </SocialButton>
              </div>
              <div className="terms-block text-center mt-4 txt-lightgray">
                <p>
                  By proceeding you agree to the
                  <br />
                  <Link to="/terms" className="pink-txt pr-1 brandon-Medium" onClick={() => props.onHide()}>
                    Terms
                  </Link>
                  and
                  <Link to="/privacy" className="pink-txt pl-1 brandon-Medium" onClick={() => props.onHide()}>
                    Privacy Policy
                  </Link>
                </p>
              </div>
              {/* <Modal show={popup} onHide={handlePopup} className="signup-modal">
                                <Modal.Body className="p-0">
                                            <p>Signup successfully !</p>
                                </Modal.Body>
                            </Modal> */}
            </div>
          </div>
        </React.Fragment>
      </div>
    </div>
  );
};

export default SignInPage;
