import React from "react";

import pattern_img from "../../assets/images/Pattern.png";
import OurVisionComponent from "../../components/OurVisionComponent/OurVisionComponent";
import video_img from "../../assets/images/how/video-img.png";
import how_img_1 from "../../assets/images/how/work-img1.jpg";

import Res_List_07 from "../../assets/images/xd-image/Restaurant_list_07.png";
import Res_Dish_05 from "../../assets/images/xd-image/restaurant_dish_05.png";
import play_icon from "../../assets/images/how/play-button.svg";
import "./HowItWorksPage.scss";
import SecondOverlapedCardComp from "../../components/SecondOverlapedCardComp/SecondOverlapedCardComp";
import FirstOverlapedCardComp from "../../components/FirstOverlapedCardComp/FirstOverlapedCardComp";
import WhyWeMadePickyPigComp from "../../components/WhyWeMadePickyPigComp/WhyWeMadePickyPigComp";
import HowPageAllegyDescComp from "../../components/HowPageAllegyDescComp/HowPageAllegyDescComp";
import ReactPlayer from "react-player/lazy";

const detail_1 =
  "Simply enter your search preferences using the drop-down menus and Picky Pigs will find you a selection of restaurants and dishes that meet your needs. It will also find your location to show you the closest restaurants to you. You can search by allergy requirements, dietary preferences, lifestyle choices or even restaurant features. So whether you have an allergy, choose to eat a plant-based diet, are pregnant, want to take your dog, or are just thinking more consciously about what you eat, Picky Pigs is your ultimate dining out tool.";
const detail_2 =
  "Once you have added your preferences youre then able to see all the suitable restaurants. Here you can see all their information, links to their website, bookings and social accounts. You can also see their full menus and if theyre available of not.";
const detail_3 = [
  "You’ll see a full breakdown of each dish – its ingredients, allergens, calories and macros – giving you more control and greater choice. With more detail you are able to see which elements can be removed and pre-select your perfect dish before arriving at the restaurant. ",

  "Picky Pigs allows you to enjoy the entire dining out experience, from choosing your perfect place, to ordering and indulging in your perfect dish. There’s no need to feel like a ‘fussy feeder’ when you arrive at the restaurant. Just relax, enjoy the experience, and rediscover your love for dining out. And all fuss free. ",
];

function HowItWorksPage() {
  return (
    <div className="how_it_works_container">
      <br />
      <br />
      <br />
      <br />
      <br />
      <br />
      <div
        className="gradient-bg"
        style={{
          height: "100vh",
          position: "absolute",
          top: 0,
          right: 0,
          width: "100%",
        }}
      ></div>
      {/* How section 1 start */}
      <section className="how-section position-relative">
        <div className="container">
          <div className="row">
            <div className="col-sm-12 mb-2">
              <h1 className="text-center text-uppercase header-txt brandon-Medium position-relative">
                HOW IT WORKS
              </h1>

              <p className="text-center f-15">
                This is your ultimate food finding application for FUSS FREE
                FOOD. Search for the best place for you to dine based
                <br className="d-none d-xl-block" />
                on all of your needs, add and remove filters to create a
                personalised digital menu and even send your own order to
                <br className="d-none d-xl-block" />
                the kitchen to ensure you feel safe and in control.
              </p>
            </div>
          </div>
        </div>
      </section>
      {/* Who section 1 end */}
      <section className="howvideo-section">
        <div className="container">
          <div className="row">
            <div className="col-sm-12">
              <div className="howvideo-wrapper">
                <ReactPlayer
                  light={video_img}
                  playIcon={
                    <div className="videoplay-bg d-flex align-items-center justify-content-center">
                      <img
                        src={play_icon}
                        className="img-fluid play_icon"
                        alt="icon"
                        loading="lazy"
                      />
                    </div>
                  }
                  className="w-100 h-100"
                  controls
                  url="https://test-videos.co.uk/vids/bigbuckbunny/mp4/h264/360/Big_Buck_Bunny_360_10s_1MB.mp4"
                />
              </div>
            </div>
          </div>
        </div>
      </section>
      <br />
      <br />
      <br />
      <br />
      <section>
        <div className="container">
          <FirstOverlapedCardComp img={how_img_1} detail={detail_1} />
          <SecondOverlapedCardComp img={Res_List_07} detail={detail_2} />
          <FirstOverlapedCardComp img={Res_Dish_05} detail={detail_3} />
        </div>
      </section>

      <WhyWeMadePickyPigComp />
      <HowPageAllegyDescComp />

      <section>
        <div className="container">
          <div className="row">
            <div className="col-sm-12">
              <div className="patternimg-wrapper">
                <img
                  src={pattern_img}
                  className="img-fluid"
                  loading="lazy"
                  alt="img"
                />
              </div>
            </div>
          </div>
        </div>
      </section>
      <OurVisionComponent />
    </div>
  );
}

export default HowItWorksPage;
