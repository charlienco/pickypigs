import React, { useState, useEffect } from "react";
import Slider from "react-slick";
// import DishBlock from '../../components/DishBlock/DishBlock';
import FilterList from "../../components/FilterList/FilterList";
import "./DishtListPage.scss";
// import restaurant_P1 from "../../assets/images/restaurant/r1.png"
// import restaurant_P2 from "../../assets/images/restaurant/r2.png"
// import restaurant_P3 from "../../assets/images/restaurant/r3.png"
// import restaurant_P4 from "../../assets/images/restaurant/r4.png"
// import restaurant_P5 from "../../assets/images/restaurant/r5.png"
// import restaurant_P6 from "../../assets/images/restaurant/r6.png"
// import restaurant_P7 from "../../assets/images/restaurant/r7.png"
// import restaurant_P8 from "../../assets/images/restaurant/r8.png"
import Scroll from "react-scroll";
import { useDispatch, useSelector } from "react-redux";
import { Link as MyLink } from "react-router-dom";
import {
  getBreakfastMenuDishList,
  getFourBreakfastMenuDishList,
  getFavouriteDishListData,
  getFourFavouriteDishListData,
  getWhatsNewDishList,
  getLunchMenuDishList,
  getFourLunchMenuDishList,
  getDinnerMenuDishList,
  getFourDinnerMenuDishList,
  getDessertMenuDishList,
  getFourDessertMenuDishList,
  getBuffetMenuDishList,
  getFourBuffetMenuDishList,
  getDrinksMenuDishList,
  getFourDrinksMenuDishList,
  getNibbleMenuDishList,
  getFourNibbleMenuDishList,
  getSetmenuMenuDishList,
  getSubscribedDishListData,
  getFourWhatsNewDishList,
  getFourSetmenuMenuDishList,
} from "../../redux/actions/dishListPageAction";
import DiscDescriptionComp from "../../components/DiscDescriptionComp/DiscDescriptionComp";
import DishListCommonComp from "../../components/DishListCommonComp/DishListCommonComp";
import { DEFAULT_LAT, DEFAULT_LNG } from "../../shared/constant";
import WebDiscDescriptionCompSkeleton from "../../components/WebSkeleton/WebDiscDescriptionCompSkeleton/WebDiscDescriptionCompSkeleton";
import WebMenuSideBarSkeleton from "../../components/WebSkeleton/WebMenuSideBarSkeleton/WebMenuSideBarSkeleton";

const Link = Scroll.Link;
const Element = Scroll.Element;

const DishtListPage = () => {
  const dispatch = useDispatch();
  let [visible, setVisible] = useState(5);
  let [visible2, setVisible2] = useState(5);
  let [visible3, setVisible3] = useState(5);
  let [visible4, setVisible4] = useState(5);
  let [visible5, setVisible5] = useState(5);
  let [visible6, setVisible6] = useState(5);
  let [visible7, setVisible7] = useState(5);
  let [visible8, setVisible8] = useState(5);
  let [visible9, setVisible9] = useState(5);
  let [visible10, setVisible10] = useState(5);

  var settings = {
    arrows: true,
    centerMode: true,
    centerPadding: "0px",
    slidesToShow: 3.975,
    slidesToScroll: 1,
    responsive: [
      {
        breakpoint: 768,
        settings: {
          arrows: false,
          centerMode: true,
          centerPadding: "40px",
          slidesToShow: 3,
        },
      },
      {
        breakpoint: 480,
        settings: {
          arrows: false,
          centerMode: true,
          centerPadding: "40px",
          slidesToShow: 1,
        },
      },
    ],
  };
  // const next = (slider) => {
  //     console.log('slider pres=> ',slider);

  //    slider.slickNext();
  // }
  // const previous=(slider)=> {
  //     slider.slickPrev();
  //     console.log('slider next=> ', slider);

  // }
  // useEffect(() => {

  //     window.addEventListener('scroll', () => {
  //             let ele = document.getElementById("restdiv")
  //             if (window.scrollY !== 0) {
  //             ele.classList.add("rest_div")
  //             } else {
  //                 ele.classList.remove("rest_div")
  //             }
  //         });
  // }, [])
  const myCordinates = useSelector((state) => {
    return state.googledata;
  });
  let { overalLocation = { lat: DEFAULT_LAT, lng: DEFAULT_LNG } } =
    myCordinates;

  useEffect(() => {
    if (overalLocation && overalLocation.lat && overalLocation.lng) {
      dispatch(
        getSubscribedDishListData({
          userCoordinates: [
            overalLocation && overalLocation.lat
              ? overalLocation.lat
              : DEFAULT_LAT,
            overalLocation && overalLocation.lng
              ? overalLocation.lng
              : DEFAULT_LNG,
          ],
        })
      );
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [overalLocation]);

  useEffect(() => {
    if (overalLocation && overalLocation.lat && overalLocation.lng) {
      dispatch(
        getFavouriteDishListData({
          userCoordinates: [
            overalLocation && overalLocation.lat
              ? overalLocation.lat
              : DEFAULT_LAT,
            overalLocation && overalLocation.lng
              ? overalLocation.lng
              : DEFAULT_LNG,
          ],
          search: "",
          option: "favorite",
          styleOfmenu: "",
          start: 0,
          length: 5,
        })
      );
      setVisible(5);
    }
  }, [dispatch, overalLocation]);

  useEffect(() => {
    if (overalLocation && overalLocation.lat && overalLocation.lng) {
      dispatch(
        getWhatsNewDishList({
          userCoordinates: [
            overalLocation && overalLocation.lat
              ? overalLocation.lat
              : DEFAULT_LAT,
            overalLocation && overalLocation.lng
              ? overalLocation.lng
              : DEFAULT_LNG,
          ],
          search: "",
          option: "new",
          styleOfmenu: "",
          start: 0,
          length: 5,
        })
      );
      setVisible2(5);
    }
  }, [dispatch, overalLocation]);

  useEffect(() => {
    if (overalLocation && overalLocation.lat && overalLocation.lng) {
      dispatch(
        getBreakfastMenuDishList({
          userCoordinates: [
            overalLocation && overalLocation.lat
              ? overalLocation.lat
              : DEFAULT_LAT,
            overalLocation && overalLocation.lng
              ? overalLocation.lng
              : DEFAULT_LNG,
          ],
          search: "",
          option: "",
          styleOfmenu: "breakfast",
          start: 0,
          length: 5,
        })
      );
      setVisible3(5);
    }
  }, [dispatch, overalLocation]);

  useEffect(() => {
    if (overalLocation && overalLocation.lat && overalLocation.lng) {
      if (visible3 > 5) {
        dispatch(
          getFourBreakfastMenuDishList({
            userCoordinates: [
              overalLocation && overalLocation.lat
                ? overalLocation.lat
                : DEFAULT_LAT,
              overalLocation && overalLocation.lng
                ? overalLocation.lng
                : DEFAULT_LNG,
            ],
            search: "",
            option: "",
            styleOfmenu: "breakfast",
            start: visible3 - 3,
            length: 3,
          })
        );
      }
    }
  }, [dispatch, overalLocation, visible3]);

  useEffect(() => {
    if (overalLocation && overalLocation.lat && overalLocation.lng) {
      dispatch(
        getLunchMenuDishList({
          userCoordinates: [
            overalLocation && overalLocation.lat
              ? overalLocation.lat
              : DEFAULT_LAT,
            overalLocation && overalLocation.lng
              ? overalLocation.lng
              : DEFAULT_LNG,
          ],
          search: "",
          option: "",
          styleOfmenu: "lunch",
          start: 0,
          length: 5,
        })
      );
      setVisible4(5);
    }
  }, [dispatch, overalLocation]);
  useEffect(() => {
    if (overalLocation && overalLocation.lat && overalLocation.lng) {
      if (visible4 > 5) {
        dispatch(
          getFourLunchMenuDishList({
            userCoordinates: [
              overalLocation && overalLocation.lat
                ? overalLocation.lat
                : DEFAULT_LAT,
              overalLocation && overalLocation.lng
                ? overalLocation.lng
                : DEFAULT_LNG,
            ],
            search: "",
            option: "",
            styleOfmenu: "lunch",
            start: visible4 - 3,
            length: 3,
          })
        );
      }
    }
  }, [dispatch, overalLocation, visible4]);

  useEffect(() => {
    if (overalLocation && overalLocation.lat && overalLocation.lng) {
      dispatch(
        getDinnerMenuDishList({
          userCoordinates: [
            overalLocation && overalLocation.lat
              ? overalLocation.lat
              : DEFAULT_LAT,
            overalLocation && overalLocation.lng
              ? overalLocation.lng
              : DEFAULT_LNG,
          ],
          search: "",
          option: "",
          styleOfmenu: "dinner",
          start: 0,
          length: 5,
        })
      );
      setVisible5(5);
    }
  }, [dispatch, overalLocation]);
  useEffect(() => {
    if (overalLocation && overalLocation.lat && overalLocation.lng) {
      if (visible5 > 5) {
        dispatch(
          getFourDinnerMenuDishList({
            userCoordinates: [
              overalLocation && overalLocation.lat
                ? overalLocation.lat
                : DEFAULT_LAT,
              overalLocation && overalLocation.lng
                ? overalLocation.lng
                : DEFAULT_LNG,
            ],
            search: "",
            option: "",
            styleOfmenu: "dinner",
            start: visible5 - 3,
            length: 3,
          })
        );
      }
    }
  }, [dispatch, visible5, overalLocation]);

  useEffect(() => {
    if (overalLocation && overalLocation.lat && overalLocation.lng) {
      dispatch(
        getDessertMenuDishList({
          userCoordinates: [
            overalLocation && overalLocation.lat
              ? overalLocation.lat
              : DEFAULT_LAT,
            overalLocation && overalLocation.lng
              ? overalLocation.lng
              : DEFAULT_LNG,
          ],
          search: "",
          option: "",
          styleOfmenu: "dessert",
          start: 0,
          length: 5,
        })
      );
      setVisible6(5);
    }
  }, [dispatch, overalLocation]);
  useEffect(() => {
    if (overalLocation && overalLocation.lat && overalLocation.lng) {
      if (visible6 > 5) {
        dispatch(
          getFourDessertMenuDishList({
            userCoordinates: [
              overalLocation && overalLocation.lat
                ? overalLocation.lat
                : DEFAULT_LAT,
              overalLocation && overalLocation.lng
                ? overalLocation.lng
                : DEFAULT_LNG,
            ],
            search: "",
            option: "",
            styleOfmenu: "dessert",
            start: visible6 - 3,
            length: 3,
          })
        );
      }
    }
  }, [dispatch, visible6, overalLocation]);

  useEffect(() => {
    if (overalLocation && overalLocation.lat && overalLocation.lng) {
      dispatch(
        getBuffetMenuDishList({
          userCoordinates: [
            overalLocation && overalLocation.lat
              ? overalLocation.lat
              : DEFAULT_LAT,
            overalLocation && overalLocation.lng
              ? overalLocation.lng
              : DEFAULT_LNG,
          ],
          search: "",
          option: "",
          styleOfmenu: "buffet",
          start: 0,
          length: 5,
        })
      );
      setVisible7(5);
    }
  }, [dispatch, overalLocation]);
  useEffect(() => {
    if (overalLocation && overalLocation.lat && overalLocation.lng) {
      if (visible7 > 5) {
        dispatch(
          getFourBuffetMenuDishList({
            userCoordinates: [
              overalLocation && overalLocation.lat
                ? overalLocation.lat
                : DEFAULT_LAT,
              overalLocation && overalLocation.lng
                ? overalLocation.lng
                : DEFAULT_LNG,
            ],
            search: "",
            option: "",
            styleOfmenu: "buffet",
            start: visible7 - 3,
            length: 3,
          })
        );
      }
    }
  }, [dispatch, visible7, overalLocation]);

  useEffect(() => {
    if (overalLocation && overalLocation.lat && overalLocation.lng) {
      dispatch(
        getDrinksMenuDishList({
          userCoordinates: [
            overalLocation && overalLocation.lat
              ? overalLocation.lat
              : DEFAULT_LAT,
            overalLocation && overalLocation.lng
              ? overalLocation.lng
              : DEFAULT_LNG,
          ],
          search: "",
          option: "",
          styleOfmenu: "drinks",
          start: 0,
          length: 5,
        })
      );
      setVisible8(5);
    }
  }, [dispatch, overalLocation]);
  useEffect(() => {
    if (overalLocation && overalLocation.lat && overalLocation.lng) {
      if (visible8 > 5) {
        dispatch(
          getFourDrinksMenuDishList({
            userCoordinates: [
              overalLocation && overalLocation.lat
                ? overalLocation.lat
                : DEFAULT_LAT,
              overalLocation && overalLocation.lng
                ? overalLocation.lng
                : DEFAULT_LNG,
            ],
            search: "",
            option: "",
            styleOfmenu: "drinks",
            start: visible8 - 3,
            length: 3,
          })
        );
      }
    }
  }, [dispatch, visible8, overalLocation]);

  useEffect(() => {
    if (overalLocation && overalLocation.lat && overalLocation.lng) {
      dispatch(
        getNibbleMenuDishList({
          userCoordinates: [
            overalLocation && overalLocation.lat
              ? overalLocation.lat
              : DEFAULT_LAT,
            overalLocation && overalLocation.lng
              ? overalLocation.lng
              : DEFAULT_LNG,
          ],
          search: "",
          option: "",
          styleOfmenu: "nibble",
          start: 0,
          length: 5,
        })
      );
      setVisible9(5);
    }
  }, [dispatch, overalLocation]);
  useEffect(() => {
    if (overalLocation && overalLocation.lat && overalLocation.lng) {
      if (visible9 > 5) {
        dispatch(
          getFourNibbleMenuDishList({
            userCoordinates: [
              overalLocation && overalLocation.lat
                ? overalLocation.lat
                : DEFAULT_LAT,
              overalLocation && overalLocation.lng
                ? overalLocation.lng
                : DEFAULT_LNG,
            ],
            search: "",
            option: "",
            styleOfmenu: "nibble",
            start: visible9 - 3,
            length: 3,
          })
        );
      }
    }
  }, [dispatch, visible9, overalLocation]);

  useEffect(() => {
    if (overalLocation && overalLocation.lat && overalLocation.lng) {
      dispatch(
        getSetmenuMenuDishList({
          userCoordinates: [
            overalLocation && overalLocation.lat
              ? overalLocation.lat
              : DEFAULT_LAT,
            overalLocation && overalLocation.lng
              ? overalLocation.lng
              : DEFAULT_LNG,
          ],
          search: "",
          option: "",
          styleOfmenu: "setmenu",
          start: 0,
          length: 5,
        })
      );
      setVisible10(5);
    }
  }, [dispatch, overalLocation]);
  useEffect(() => {
    if (overalLocation && overalLocation.lat && overalLocation.lng) {
      if (visible10 > 5) {
        dispatch(
          getFourSetmenuMenuDishList({
            userCoordinates: [
              overalLocation && overalLocation.lat
                ? overalLocation.lat
                : DEFAULT_LAT,
              overalLocation && overalLocation.lng
                ? overalLocation.lng
                : DEFAULT_LNG,
            ],
            search: "",
            option: "",
            styleOfmenu: "setmenu",
            start: visible10 - 3,
            length: 3,
          })
        );
      }
    }
  }, [dispatch, visible10, overalLocation]);

  let dishRelated_Data = useSelector((state) => {
    return state.dishList;
  });
  let {
    isLoading,
    subscribedDishDetail_Data = {},

    favouriteDishDetail_Data,
    fourMoreFavouriteDishLoading,
    fourFavouriteDishListData,
    whatsNewDish_List,
    fourMoreWhatsNewDishLoading,
    fourWhatsNewDishListData,
    breakfastMenuDish_List,
    fourMoreBreakfastDishLoading,
    fourBreakfastDishListData,
    lunchMenuDish_List,
    fourMoreLunchMenuDishLoading,
    fourLunchMenuDishListData,
    dinnerMenuDish_List,
    fourMoreDinnerMenuDishLoading,
    fourDinnerMenuDishListData,
    dessertMenuDish_List,
    fourMoreDessertMenuDishLoading,
    fourDessertMenuDishListData,
    buffetMenuDish_List,
    fourMoreBuffetMenuDishLoading,
    fourBuffetMenuDishListData,
    drinksMenuDish_List,
    fourMoreDrinksMenuDishLoading,
    fourDrinksMenuDishListData,
    nibbleMenuDish_List,
    fourMoreNibbleMenuDishLoading,
    fourNibbleMenuDishListData,
    setmenuMenuDish_List,
    fourMoreSetmenuMenuDishLoading,
    fourSetmenuMenuDishListData,
  } = dishRelated_Data;

  return (
    <>
      {/* {isLoading?
                    <React.Fragment>
                        <CustomLoadingComp/>
                    </React.Fragment>
            :
                null
            } */}
      <section className="fr-section rl-section">
        <div className="container">
          <div className="row">
            <div className="col-sm-12">
              <div className="fr-wrapper fr-rl-wrapper">
                <FilterList showautosuggestion={false} />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* restaurantlist-slider section 2 start content */}
      <section className="dishtListPage-slider">
        <div className="container">
          <div className="row">
            <div className="col-sm-12">
              <div className="rl-list-slider">
                {isLoading ? (
                  <Slider {...settings}>
                    {[1, 2, 3, 4].map((index) => {
                      return (
                        <React.Fragment key={index}>
                          <div className="col-sm-12 ">
                            <WebDiscDescriptionCompSkeleton />
                          </div>
                        </React.Fragment>
                      );
                    })}
                  </Slider>
                ) : (
                  <React.Fragment>
                    {subscribedDishDetail_Data &&
                    subscribedDishDetail_Data.data &&
                    subscribedDishDetail_Data.data.length > 0 ? (
                      <React.Fragment>
                        {subscribedDishDetail_Data &&
                        subscribedDishDetail_Data.data &&
                        subscribedDishDetail_Data.data.length <= 3 ? (
                          <React.Fragment>
                            {subscribedDishDetail_Data &&
                              subscribedDishDetail_Data.data &&
                              subscribedDishDetail_Data.data.map(
                                (data, index) => {
                                  return (
                                    <React.Fragment key={index}>
                                      <div className="col-sm-3">
                                        <MyLink
                                          to={
                                            "/restaurant_dish_info/" + data._id
                                          }
                                          style={{
                                            textDecoration: "none",
                                            color: "initial",
                                          }}
                                        >
                                          <DiscDescriptionComp
                                            dish_name={
                                              data.name ? data.name : ""
                                            }
                                            dish_image={
                                              data.image ? data.image : ""
                                            }
                                            dish_priceunit={
                                              data.priceUnit
                                                ? data.priceUnit
                                                : ""
                                            }
                                            dish_price={
                                              data.price ? data.price : "-"
                                            }
                                            dish_description={
                                              data.description
                                                ? data.description
                                                : ""
                                            }
                                            dish_menu={
                                              data.menuList ? data.menuList : []
                                            }
                                            dish_allergy={
                                              data.allergenList
                                                ? data.allergenList
                                                : []
                                            }
                                            dish_new_tag={
                                              data.new ? data.new : false
                                            }
                                            dish_available_tag={
                                              data.available
                                                ? data.available
                                                : false
                                            }
                                          />
                                        </MyLink>
                                      </div>
                                    </React.Fragment>
                                  );
                                }
                              )}
                          </React.Fragment>
                        ) : (
                          <React.Fragment>
                            <Slider {...settings}>
                              {subscribedDishDetail_Data &&
                                subscribedDishDetail_Data.data &&
                                subscribedDishDetail_Data.data.map(
                                  (data, index) => {
                                    return (
                                      <React.Fragment key={index}>
                                        <div className="col-sm-12">
                                          <MyLink
                                            to={
                                              "/restaurant_dish_info/" +
                                              data._id
                                            }
                                            style={{
                                              textDecoration: "none",
                                              color: "initial",
                                            }}
                                          >
                                            <DiscDescriptionComp
                                              dish_name={
                                                data.name ? data.name : ""
                                              }
                                              dish_image={
                                                data.image ? data.image : ""
                                              }
                                              dish_priceunit={
                                                data.priceUnit
                                                  ? data.priceUnit
                                                  : ""
                                              }
                                              dish_price={
                                                data.price ? data.price : "-"
                                              }
                                              dish_description={
                                                data.description
                                                  ? data.description
                                                  : ""
                                              }
                                              dish_menu={
                                                data.menuList
                                                  ? data.menuList
                                                  : []
                                              }
                                              dish_allergy={
                                                data.allergenList
                                                  ? data.allergenList
                                                  : []
                                              }
                                              dish_new_tag={
                                                data.new ? data.new : false
                                              }
                                              dish_available_tag={
                                                data.available
                                                  ? data.available
                                                  : false
                                              }
                                            />
                                          </MyLink>
                                        </div>
                                      </React.Fragment>
                                    );
                                  }
                                )}
                            </Slider>
                          </React.Fragment>
                        )}
                      </React.Fragment>
                    ) : (
                      <p>No Restaurants Available</p>
                    )}
                  </React.Fragment>
                )}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* restaurantlist-tab content Start */}
      <section className="dishtListPage-tabfilter">
        <div className="container position-relative">
          <div className="row">
            <div className="col-md-3 tab-filter">
              <ul style={{ position: "sticky", top: 50 }}>
                {isLoading ? (
                  <WebMenuSideBarSkeleton />
                ) : (
                  <React.Fragment>
                    {favouriteDishDetail_Data &&
                    favouriteDishDetail_Data.totalRecords &&
                    favouriteDishDetail_Data.totalRecords > 0 ? (
                      <React.Fragment>
                        <li>
                          <Link
                            to="section-1"
                            activeClass="tabfilter-active bg-prime"
                            spy={true}
                            smooth={true}
                            offset={-50}
                          >
                            <h6 className="mb-1 brandon-Bold ">
                              <b>Favourite</b>
                            </h6>
                            <p className="mb-0">
                              {favouriteDishDetail_Data &&
                              favouriteDishDetail_Data.totalRecords
                                ? favouriteDishDetail_Data.totalRecords
                                : "0"}{" "}
                              Options
                            </p>
                          </Link>
                        </li>
                      </React.Fragment>
                    ) : null}
                    {whatsNewDish_List &&
                    whatsNewDish_List.totalRecords &&
                    whatsNewDish_List.totalRecords > 0 ? (
                      <React.Fragment>
                        <li>
                          <Link
                            to="section-2"
                            activeClass="tabfilter-active"
                            spy={true}
                            smooth={true}
                            offset={-80}
                          >
                            <h6 className="mb-1 brandon-Bold ">
                              <b>What's new</b>
                            </h6>
                            <p className="mb-0">
                              {whatsNewDish_List &&
                              whatsNewDish_List.totalRecords
                                ? whatsNewDish_List.totalRecords
                                : "0"}{" "}
                              Options
                            </p>
                          </Link>
                        </li>
                      </React.Fragment>
                    ) : null}
                    {breakfastMenuDish_List &&
                    breakfastMenuDish_List.totalRecords &&
                    breakfastMenuDish_List.totalRecords > 0 ? (
                      <React.Fragment>
                        <li>
                          <Link
                            to="section-3"
                            activeClass="tabfilter-active"
                            spy={true}
                            smooth={true}
                            offset={-80}
                          >
                            <h6 className="mb-1 brandon-Bold">
                              <b>Breakfast</b>
                            </h6>
                            <p className="mb-0">
                              {breakfastMenuDish_List &&
                              breakfastMenuDish_List.totalRecords
                                ? breakfastMenuDish_List.totalRecords
                                : "0"}{" "}
                              Options
                            </p>
                          </Link>
                        </li>
                      </React.Fragment>
                    ) : null}
                    {lunchMenuDish_List &&
                    lunchMenuDish_List.totalRecords &&
                    lunchMenuDish_List.totalRecords > 0 ? (
                      <React.Fragment>
                        <li>
                          <Link
                            to="section-4"
                            activeClass="tabfilter-active"
                            spy={true}
                            smooth={true}
                            offset={-80}
                          >
                            <h6 className="mb-1 brandon-Bold">
                              <b>Lunch</b>
                            </h6>
                            <p className="mb-0">
                              {lunchMenuDish_List &&
                              lunchMenuDish_List.totalRecords
                                ? lunchMenuDish_List.totalRecords
                                : "0"}{" "}
                              Options
                            </p>
                          </Link>
                        </li>
                      </React.Fragment>
                    ) : null}
                    {dinnerMenuDish_List &&
                    dinnerMenuDish_List.totalRecords &&
                    dinnerMenuDish_List.totalRecords > 0 ? (
                      <React.Fragment>
                        <li>
                          <Link
                            to="section-5"
                            activeClass="tabfilter-active"
                            spy={true}
                            smooth={true}
                            offset={-80}
                          >
                            <h6 className="mb-1 brandon-Bold">
                              <b>Dinner</b>
                            </h6>
                            <p className="mb-0">
                              {dinnerMenuDish_List &&
                              dinnerMenuDish_List.totalRecords
                                ? dinnerMenuDish_List.totalRecords
                                : "0"}{" "}
                              Options
                            </p>
                          </Link>
                        </li>
                      </React.Fragment>
                    ) : null}
                    {dessertMenuDish_List &&
                    dessertMenuDish_List.totalRecords &&
                    dessertMenuDish_List.totalRecords > 0 ? (
                      <React.Fragment>
                        <li>
                          <Link
                            to="section-6"
                            activeClass="tabfilter-active"
                            spy={true}
                            smooth={true}
                            offset={-80}
                          >
                            <h6 className="mb-1 brandon-Bold">
                              <b>Dessert</b>
                            </h6>
                            <p className="mb-0">
                              {dessertMenuDish_List &&
                              dessertMenuDish_List.totalRecords
                                ? dessertMenuDish_List.totalRecords
                                : "0"}{" "}
                              Options
                            </p>
                          </Link>
                        </li>
                      </React.Fragment>
                    ) : null}
                    {buffetMenuDish_List &&
                    buffetMenuDish_List.totalRecords &&
                    buffetMenuDish_List.totalRecords > 0 ? (
                      <React.Fragment>
                        <li>
                          <Link
                            to="section-7"
                            activeClass="tabfilter-active"
                            spy={true}
                            smooth={true}
                            offset={-80}
                          >
                            <h6 className="mb-1 brandon-Bold">
                              <b>Buffet</b>
                            </h6>
                            <p className="mb-0">
                              {buffetMenuDish_List &&
                              buffetMenuDish_List.totalRecords
                                ? buffetMenuDish_List.totalRecords
                                : "0"}{" "}
                              Options
                            </p>
                          </Link>
                        </li>
                      </React.Fragment>
                    ) : null}
                    {drinksMenuDish_List &&
                    drinksMenuDish_List.totalRecords &&
                    drinksMenuDish_List.totalRecords > 0 ? (
                      <React.Fragment>
                        <li>
                          <Link
                            to="section-8"
                            activeClass="tabfilter-active"
                            spy={true}
                            smooth={true}
                            offset={-80}
                          >
                            <h6 className="mb-1 brandon-Bold">
                              <b>Drinks</b>
                            </h6>
                            <p className="mb-0">
                              {drinksMenuDish_List &&
                              drinksMenuDish_List.totalRecords
                                ? drinksMenuDish_List.totalRecords
                                : "0"}{" "}
                              Options
                            </p>
                          </Link>
                        </li>
                      </React.Fragment>
                    ) : null}
                    {nibbleMenuDish_List &&
                    nibbleMenuDish_List.totalRecords &&
                    nibbleMenuDish_List.totalRecords > 0 ? (
                      <React.Fragment>
                        <li>
                          <Link
                            to="section-9"
                            activeClass="tabfilter-active"
                            spy={true}
                            smooth={true}
                            offset={-80}
                          >
                            <h6 className="mb-1 brandon-Bold">
                              <b>Nibble</b>
                            </h6>
                            <p className="mb-0">
                              {nibbleMenuDish_List &&
                              nibbleMenuDish_List.totalRecords
                                ? nibbleMenuDish_List.totalRecords
                                : "0"}{" "}
                              Options
                            </p>
                          </Link>
                        </li>
                      </React.Fragment>
                    ) : null}
                    {setmenuMenuDish_List &&
                    setmenuMenuDish_List.totalRecords &&
                    setmenuMenuDish_List.totalRecords > 0 ? (
                      <React.Fragment>
                        <li>
                          <Link
                            to="section-10"
                            activeClass="tabfilter-active"
                            spy={true}
                            smooth={true}
                            offset={-80}
                          >
                            <h6 className="mb-1 brandon-Bold">
                              <b>Set Menu</b>
                            </h6>
                            <p className="mb-0">
                              {setmenuMenuDish_List &&
                              setmenuMenuDish_List.totalRecords
                                ? setmenuMenuDish_List.totalRecords
                                : "0"}{" "}
                              Options
                            </p>
                          </Link>
                        </li>
                      </React.Fragment>
                    ) : null}
                  </React.Fragment>
                )}
              </ul>
            </div>
            <div className="col-md-9 tabfilter-content">
              <div>
                <div>
                  {isLoading ? (
                    <React.Fragment>
                      <div className="row">
                        {[1, 2, 3].map((index) => {
                          return (
                            <React.Fragment key={index}>
                              <div className="col-sm-12 col-md-12 col-lg-4 col-xl-4 mb-4">
                                <WebDiscDescriptionCompSkeleton />
                              </div>
                            </React.Fragment>
                          );
                        })}
                      </div>
                    </React.Fragment>
                  ) : (
                    <React.Fragment>
                      {favouriteDishDetail_Data &&
                      favouriteDishDetail_Data.totalRecords &&
                      favouriteDishDetail_Data.totalRecords > 0 ? (
                        <React.Fragment>
                          <Element name="section-1" style={{ paddingTop: 60 }}>
                            <h4 className="text-uppercase mb-4 brandon-Bold">
                              <b>Favourite</b>
                            </h4>
                            <DishListCommonComp
                              fourmoreloading={
                                fourMoreFavouriteDishLoading
                                  ? fourMoreFavouriteDishLoading
                                  : false
                              }
                              fourmoredata={
                                fourFavouriteDishListData
                                  ? fourFavouriteDishListData
                                  : []
                              }
                              selected_data={
                                favouriteDishDetail_Data
                                  ? favouriteDishDetail_Data
                                  : {}
                              }
                              datatoshow={visible}
                              handleDataToShow={(value) => {
                                setVisible(value);
                                dispatch(
                                  getFourFavouriteDishListData({
                                    userCoordinates: [
                                      overalLocation && overalLocation.lat
                                        ? overalLocation.lat
                                        : DEFAULT_LAT,
                                      overalLocation && overalLocation.lng
                                        ? overalLocation.lng
                                        : DEFAULT_LNG,
                                    ],
                                    search: "",
                                    option: "favorite",
                                    styleOfmenu: "",
                                    start: visible,
                                    length: 3,
                                  })
                                );
                              }}
                            />
                          </Element>
                        </React.Fragment>
                      ) : null}
                    </React.Fragment>
                  )}
                </div>
                <div>
                  {isLoading ? (
                    <React.Fragment>
                      <div className="row">
                        {[1, 2, 3].map((index) => {
                          return (
                            <React.Fragment key={index}>
                              <div className="col-sm-12 col-md-12 col-lg-4 col-xl-4 mb-4">
                                <WebDiscDescriptionCompSkeleton />
                              </div>
                            </React.Fragment>
                          );
                        })}
                      </div>
                    </React.Fragment>
                  ) : (
                    <React.Fragment>
                      {whatsNewDish_List &&
                      whatsNewDish_List.totalRecords &&
                      whatsNewDish_List.totalRecords > 0 ? (
                        <React.Fragment>
                          <div className="row mt-3">
                            <div className="col-sm-12">
                              <hr className="borderstyle-dotted" />
                            </div>
                          </div>
                          <Element name="section-2" className="pt-3">
                            <h4 className="text-uppercase mb-4 brandon-Bold">
                              <b>What's new</b>
                            </h4>
                            <DishListCommonComp
                              fourmoreloading={
                                fourMoreWhatsNewDishLoading
                                  ? fourMoreWhatsNewDishLoading
                                  : false
                              }
                              fourmoredata={
                                fourWhatsNewDishListData
                                  ? fourWhatsNewDishListData
                                  : []
                              }
                              selected_data={
                                whatsNewDish_List ? whatsNewDish_List : {}
                              }
                              datatoshow={visible2}
                              handleDataToShow={(value) => {
                                setVisible2(value);
                                dispatch(
                                  getFourWhatsNewDishList({
                                    userCoordinates: [
                                      overalLocation && overalLocation.lat
                                        ? overalLocation.lat
                                        : DEFAULT_LAT,
                                      overalLocation && overalLocation.lng
                                        ? overalLocation.lng
                                        : DEFAULT_LNG,
                                    ],
                                    search: "",
                                    option: "new",
                                    styleOfmenu: "",
                                    start: visible2,
                                    length: 3,
                                  })
                                );
                              }}
                            />
                          </Element>
                        </React.Fragment>
                      ) : null}
                    </React.Fragment>
                  )}
                </div>
                <div>
                  {isLoading ? (
                    <React.Fragment>
                      <div className="row">
                        {[1, 2, 3].map((index) => {
                          return (
                            <React.Fragment key={index}>
                              <div className="col-sm-12 col-md-12 col-lg-4 col-xl-4 mb-4">
                                <WebDiscDescriptionCompSkeleton />
                              </div>
                            </React.Fragment>
                          );
                        })}
                      </div>
                    </React.Fragment>
                  ) : (
                    <React.Fragment>
                      {breakfastMenuDish_List &&
                      breakfastMenuDish_List.totalRecords &&
                      breakfastMenuDish_List.totalRecords > 0 ? (
                        <React.Fragment>
                          <div className="row mt-3">
                            <div className="col-sm-12">
                              <hr className="borderstyle-dotted" />
                            </div>
                          </div>
                          <Element name="section-3" className="pt-3">
                            <h4 className="text-uppercase mb-4 brandon-Bold">
                              <b>Breakfast</b>
                            </h4>
                            <DishListCommonComp
                              fourmoreloading={
                                fourMoreBreakfastDishLoading
                                  ? fourMoreBreakfastDishLoading
                                  : false
                              }
                              fourmoredata={
                                fourBreakfastDishListData
                                  ? fourBreakfastDishListData
                                  : []
                              }
                              selected_data={
                                breakfastMenuDish_List
                                  ? breakfastMenuDish_List
                                  : {}
                              }
                              datatoshow={visible3}
                              handleDataToShow={(value) => {
                                setVisible3(value);
                              }}
                            />
                          </Element>
                        </React.Fragment>
                      ) : null}
                    </React.Fragment>
                  )}
                </div>
                <div>
                  {isLoading ? (
                    <React.Fragment>
                      <div className="row">
                        {[1, 2, 3].map((index) => {
                          return (
                            <React.Fragment key={index}>
                              <div className="col-sm-12 col-md-12 col-lg-4 col-xl-4 mb-4">
                                <WebDiscDescriptionCompSkeleton />
                              </div>
                            </React.Fragment>
                          );
                        })}
                      </div>
                    </React.Fragment>
                  ) : (
                    <React.Fragment>
                      {lunchMenuDish_List &&
                      lunchMenuDish_List.totalRecords &&
                      lunchMenuDish_List.totalRecords > 0 ? (
                        <React.Fragment>
                          <div className="row mt-3">
                            <div className="col-sm-12">
                              <hr className="borderstyle-dotted" />
                            </div>
                          </div>
                          <Element name="section-4" className="pt-3">
                            <h4 className="text-uppercase mb-4 brandon-Bold">
                              <b>Lunch</b>
                            </h4>
                            <DishListCommonComp
                              fourmoreloading={
                                fourMoreLunchMenuDishLoading
                                  ? fourMoreLunchMenuDishLoading
                                  : false
                              }
                              fourmoredata={
                                fourLunchMenuDishListData
                                  ? fourLunchMenuDishListData
                                  : []
                              }
                              selected_data={
                                lunchMenuDish_List ? lunchMenuDish_List : {}
                              }
                              datatoshow={visible4}
                              handleDataToShow={(value) => {
                                setVisible4(value);
                              }}
                            />
                          </Element>
                        </React.Fragment>
                      ) : null}
                    </React.Fragment>
                  )}
                </div>
                <div>
                  {isLoading ? (
                    <React.Fragment>
                      <div className="row">
                        {[1, 2, 3].map((index) => {
                          return (
                            <React.Fragment key={index}>
                              <div className="col-sm-12 col-md-12 col-lg-4 col-xl-4 mb-4">
                                <WebDiscDescriptionCompSkeleton />
                              </div>
                            </React.Fragment>
                          );
                        })}
                      </div>
                    </React.Fragment>
                  ) : (
                    <React.Fragment>
                      {dinnerMenuDish_List &&
                      dinnerMenuDish_List.totalRecords &&
                      dinnerMenuDish_List.totalRecords > 0 ? (
                        <React.Fragment>
                          <div className="row mt-3">
                            <div className="col-sm-12">
                              <hr className="borderstyle-dotted" />
                            </div>
                          </div>
                          <Element name="section-5" className="pt-3">
                            <h4 className="text-uppercase mb-4 brandon-Bold">
                              <b>Dinner</b>
                            </h4>
                            <DishListCommonComp
                              fourmoreloading={
                                fourMoreDinnerMenuDishLoading
                                  ? fourMoreDinnerMenuDishLoading
                                  : false
                              }
                              fourmoredata={
                                fourDinnerMenuDishListData
                                  ? fourDinnerMenuDishListData
                                  : []
                              }
                              selected_data={
                                dinnerMenuDish_List ? dinnerMenuDish_List : {}
                              }
                              datatoshow={visible5}
                              handleDataToShow={(value) => {
                                setVisible5(value);
                              }}
                            />
                          </Element>
                        </React.Fragment>
                      ) : null}
                    </React.Fragment>
                  )}
                </div>
                <div>
                  {isLoading ? (
                    <React.Fragment>
                      <div className="row">
                        {[1, 2, 3].map((index) => {
                          return (
                            <React.Fragment key={index}>
                              <div className="col-sm-12 col-md-12 col-lg-4 col-xl-4 mb-4">
                                <WebDiscDescriptionCompSkeleton />
                              </div>
                            </React.Fragment>
                          );
                        })}
                      </div>
                    </React.Fragment>
                  ) : (
                    <React.Fragment>
                      {dessertMenuDish_List &&
                      dessertMenuDish_List.totalRecords &&
                      dessertMenuDish_List.totalRecords > 0 ? (
                        <React.Fragment>
                          <div className="row mt-3">
                            <div className="col-sm-12">
                              <hr className="borderstyle-dotted" />
                            </div>
                          </div>
                          <Element name="section-6" className="pt-3">
                            <h4 className="text-uppercase mb-4 brandon-Bold">
                              <b>Dessert</b>
                            </h4>
                            <DishListCommonComp
                              fourmoreloading={
                                fourMoreDessertMenuDishLoading
                                  ? fourMoreDessertMenuDishLoading
                                  : false
                              }
                              fourmoredata={
                                fourDessertMenuDishListData
                                  ? fourDessertMenuDishListData
                                  : []
                              }
                              selected_data={
                                dessertMenuDish_List ? dessertMenuDish_List : {}
                              }
                              datatoshow={visible6}
                              handleDataToShow={(value) => {
                                setVisible6(value);
                              }}
                            />
                          </Element>
                        </React.Fragment>
                      ) : null}
                    </React.Fragment>
                  )}
                </div>
                <div>
                  {isLoading ? (
                    <React.Fragment>
                      <div className="row">
                        {[1, 2, 3].map((index) => {
                          return (
                            <React.Fragment key={index}>
                              <div className="col-sm-12 col-md-12 col-lg-4 col-xl-4 mb-4">
                                <WebDiscDescriptionCompSkeleton />
                              </div>
                            </React.Fragment>
                          );
                        })}
                      </div>
                    </React.Fragment>
                  ) : (
                    <React.Fragment>
                      {buffetMenuDish_List &&
                      buffetMenuDish_List.totalRecords &&
                      buffetMenuDish_List.totalRecords > 0 ? (
                        <React.Fragment>
                          <div className="row mt-3">
                            <div className="col-sm-12">
                              <hr className="borderstyle-dotted" />
                            </div>
                          </div>
                          <Element name="section-7" className="pt-3">
                            <h4 className="text-uppercase mb-4 brandon-Bold">
                              <b>Buffet</b>
                            </h4>
                            <DishListCommonComp
                              fourmoreloading={
                                fourMoreBuffetMenuDishLoading
                                  ? fourMoreBuffetMenuDishLoading
                                  : false
                              }
                              fourmoredata={
                                fourBuffetMenuDishListData
                                  ? fourBuffetMenuDishListData
                                  : []
                              }
                              selected_data={
                                buffetMenuDish_List ? buffetMenuDish_List : {}
                              }
                              datatoshow={visible7}
                              handleDataToShow={(value) => {
                                setVisible7(value);
                              }}
                            />
                          </Element>
                        </React.Fragment>
                      ) : null}
                    </React.Fragment>
                  )}
                </div>
                <div>
                  {isLoading ? (
                    <React.Fragment>
                      <div className="row">
                        {[1, 2, 3].map((index) => {
                          return (
                            <React.Fragment key={index}>
                              <div className="col-sm-12 col-md-12 col-lg-4 col-xl-4 mb-4">
                                <WebDiscDescriptionCompSkeleton />
                              </div>
                            </React.Fragment>
                          );
                        })}
                      </div>
                    </React.Fragment>
                  ) : (
                    <React.Fragment>
                      {drinksMenuDish_List &&
                      drinksMenuDish_List.totalRecords &&
                      drinksMenuDish_List.totalRecords > 0 ? (
                        <React.Fragment>
                          <div className="row mt-3">
                            <div className="col-sm-12">
                              <hr className="borderstyle-dotted" />
                            </div>
                          </div>
                          <Element name="section-8" className="pt-3">
                            <h4 className="text-uppercase mb-4 brandon-Bold">
                              <b>Drinks</b>
                            </h4>
                            <DishListCommonComp
                              fourmoreloading={
                                fourMoreDrinksMenuDishLoading
                                  ? fourMoreDrinksMenuDishLoading
                                  : false
                              }
                              fourmoredata={
                                fourDrinksMenuDishListData
                                  ? fourDrinksMenuDishListData
                                  : []
                              }
                              selected_data={
                                drinksMenuDish_List ? drinksMenuDish_List : {}
                              }
                              datatoshow={visible8}
                              handleDataToShow={(value) => {
                                setVisible8(value);
                              }}
                            />
                          </Element>
                        </React.Fragment>
                      ) : null}
                    </React.Fragment>
                  )}
                </div>
                <div>
                  {isLoading ? (
                    <React.Fragment>
                      <div className="row">
                        {[1, 2, 3].map((index) => {
                          return (
                            <React.Fragment key={index}>
                              <div className="col-sm-12 col-md-12 col-lg-4 col-xl-4 mb-4">
                                <WebDiscDescriptionCompSkeleton />
                              </div>
                            </React.Fragment>
                          );
                        })}
                      </div>
                    </React.Fragment>
                  ) : (
                    <React.Fragment>
                      {nibbleMenuDish_List &&
                      nibbleMenuDish_List.totalRecords &&
                      nibbleMenuDish_List.totalRecords > 0 ? (
                        <React.Fragment>
                          <div className="row mt-3">
                            <div className="col-sm-12">
                              <hr className="borderstyle-dotted" />
                            </div>
                          </div>
                          <Element name="section-9" className="pt-3">
                            <h4 className="text-uppercase mb-4 brandon-Bold">
                              <b>Nibble</b>
                            </h4>
                            <DishListCommonComp
                              fourmoreloading={
                                fourMoreNibbleMenuDishLoading
                                  ? fourMoreNibbleMenuDishLoading
                                  : false
                              }
                              fourmoredata={
                                fourNibbleMenuDishListData
                                  ? fourNibbleMenuDishListData
                                  : []
                              }
                              selected_data={
                                nibbleMenuDish_List ? nibbleMenuDish_List : {}
                              }
                              datatoshow={visible9}
                              handleDataToShow={(value) => {
                                setVisible9(value);
                              }}
                            />
                          </Element>
                        </React.Fragment>
                      ) : null}
                    </React.Fragment>
                  )}
                </div>
                <div>
                  {isLoading ? (
                    <React.Fragment>
                      <div className="row">
                        {[1, 2, 3].map((index) => {
                          return (
                            <React.Fragment key={index}>
                              <div className="col-sm-12 col-md-12 col-lg-4 col-xl-4 mb-4">
                                <WebDiscDescriptionCompSkeleton />
                              </div>
                            </React.Fragment>
                          );
                        })}
                      </div>
                    </React.Fragment>
                  ) : (
                    <React.Fragment>
                      {setmenuMenuDish_List &&
                      setmenuMenuDish_List.totalRecords &&
                      setmenuMenuDish_List.totalRecords > 0 ? (
                        <React.Fragment>
                          <div className="row mt-3">
                            <div className="col-sm-12">
                              <hr className="borderstyle-dotted" />
                            </div>
                          </div>
                          <Element name="section-10" className="pt-3">
                            <h4 className="text-uppercase mb-4 brandon-Bold">
                              <b>Set Menu</b>
                            </h4>
                            <DishListCommonComp
                              fourmoreloading={
                                fourMoreSetmenuMenuDishLoading
                                  ? fourMoreSetmenuMenuDishLoading
                                  : false
                              }
                              fourmoredata={
                                fourSetmenuMenuDishListData
                                  ? fourSetmenuMenuDishListData
                                  : []
                              }
                              selected_data={
                                setmenuMenuDish_List ? setmenuMenuDish_List : {}
                              }
                              datatoshow={visible10}
                              handleDataToShow={(value) => {
                                setVisible10(value);
                              }}
                            />
                          </Element>
                        </React.Fragment>
                      ) : null}
                    </React.Fragment>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <br></br>
      <br></br>
      {/* restaurantlist-tab content End */}

      {/* restaurantlist-slider section 2 end content */}
      {/* <div style={{ textAlign: "center" }}>
                <button className="button" onClick={previous}>
                    Previous
          </button>
                <button className="button" onClick={next}>
                    Next
          </button>
            </div> */}
    </>
  );
};

export default DishtListPage;
