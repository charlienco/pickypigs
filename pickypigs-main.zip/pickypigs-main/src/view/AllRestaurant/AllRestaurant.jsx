import React, { useEffect, useRef, useState } from "react";
import DishBlock from "../../components/DishBlock/DishBlock";
import "./AllRestaurant.scss";
import FilterList from "../../components/FilterList/FilterList";
import { Link, NavLink } from "react-router-dom";
// import restaurant_P1 from "../../assets/images/restaurant/r1.png"
// import restaurant_P2 from "../../assets/images/restaurant/r2.png"
// import restaurant_P3 from "../../assets/images/restaurant/r3.png"
// import restaurant_P4 from "../../assets/images/restaurant/r4.png"
// import restaurant_P5 from "../../assets/images/restaurant/r5.png"
// import restaurant_P6 from "../../assets/images/restaurant/r6.png"
// import restaurant_P7 from "../../assets/images/restaurant/r7.png"
// import restaurant_P8 from "../../assets/images/restaurant/r8.png"
// import AllResturantNav from '../AllResturantNav/AllResturantNav';
import { useDispatch, useSelector } from "react-redux";
import {
  getFourDishData,
  getFourRestaurantsData,
  getSearchedDishList,
  getSearchedRestaurantsList,
} from "../../redux/actions/restaurantSearchPageAction";
import AllRestaurantFilterModal from "../AllRestaurantFilterModal/AllRestaurantFilterModal";
import filtershorticonpink from "../../assets/images/filtershort-pinkicon.svg";
import { Form, Navbar, Collapse } from "react-bootstrap";
import menuline from "../../assets/images/menu-line.svg";
import search_icon from "../../assets/images/search_icon.svg";
import no_Data_Image from "../../assets/images/no_data_found.png";
// import DiscDescriptionComp from '../../components/DiscDescriptionComp/DiscDescriptionComp';

import { DEFAULT_LAT, DEFAULT_LNG } from "../../shared/constant";
import WebRestaurantDescSkeleton from "../../components/WebSkeleton/WebRestaurantDescSkeleton/WebRestaurantDescSkeleton";
import WebDiscDescriptionCompSkeleton from "../../components/WebSkeleton/WebDiscDescriptionCompSkeleton/WebDiscDescriptionCompSkeleton";
import { updateAllRestaurantSort } from "../../redux/actions/generalActions";

const DiscDescriptionComp = React.lazy(() =>
  import("../../components/DiscDescriptionComp/DiscDescriptionComp")
);

function useOutsideAlerter(ref, setOpenSearchBar) {
  useEffect(() => {
    /**
     * Alert if clicked on outside of element
     */
    function handleClickOutside(event) {
      if (ref.current && !ref.current.contains(event.target)) {
        // alert("You clicked outside of me!");
        setOpenSearchBar(false);
      }
    }

    // Bind the event listener
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      // Unbind the event listener on clean up
      document.removeEventListener("mousedown", handleClickOutside);
    };
    // eslint-disable-next-line
  }, [ref]);
}

const AllRestaurant = (props) => {
  const dispatch = useDispatch();
  const [dishVisible, setDishVisible] = useState(7);
  const [restroVisible, setRestroVisible] = useState(7);

  // const [allergen, setAllergen] = useState([])
  // const [lifestyle, setLifestyle] = useState([])
  // const [dietary, setDietary] = useState([])
  // const [features, setfeatures] = useState([])
  // const [myDistance, setMyDistance] = useState(0)
  // const [myNearby, setMyNearby] = useState(false)
  let restaurantSortBy = useSelector((state) => {
    return state.general.restaurantSortBy;
  });
  const [shortBy, setShortBy] = useState(restaurantSortBy || "relevance");
  const [openSearchBar, setOpenSearchBar] = useState(false);
  const [filterModalShow, setFilterModalShow] = useState(false);

  const [filterData, setFilterData] = useState({
    allergenId: [],
    dietaryId: [],
    lifestyleId: [],
    featuresId: [],
    toggle: true,
    distance: 0,
  });

  const [filterData1, setFilterData1] = useState({
    allergenId: [],
    dietaryId: [],
    lifestyleId: [],
    featuresId: [],
    toggle: true,
    distance: 0,
  });

  const [firstTab, setFirstTab] = useState(true);

  //Search Bar Open/Close

  const searchRef = useRef(null);
  useOutsideAlerter(searchRef, setOpenSearchBar);
  useEffect(() => {
    window.onscroll = () => {
      if (openSearchBar === true) {
        setOpenSearchBar(false);
      }
    };
    // eslint-disable-next-line
  }, [openSearchBar]);

  //Search Bar Open/Close

  const filterModalClose = () => {
    setFilterModalShow(false);
  };

  const queryString = require("query-string");
  const parsed = queryString.parse(props.location.search);

  // console.log('props =>',props);

  useEffect(() => {
    window.addEventListener("scroll", () => {
      let ele = document.getElementById("top_navbar");
      if (window.scrollY > 170) {
        ele && ele.classList.add("allrsfilter-sticky");
      } else {
        ele && ele.classList.remove("allrsfilter-sticky");
      }
    });
    // eslint-disable-next-line
  }, [window.scrollY]);

  useEffect(() => {
    window.addEventListener("scroll", () => {
      let ele = document.getElementById("selected_search_bar");
      if (window.scrollY > 170) {
        ele && ele.classList.add("d-block");
      } else {
        ele && ele.classList.remove("d-block");
      }
    });
    // eslint-disable-next-line
  }, [window.scrollY]);

  const preferenceData = useSelector((state) => {
    return state.myPreference.selectedPreference;
  });

  let {
    allergendata = [],
    dietarydata = [],
    lifestyledata = [],
    featuredata = [],
    nearby,
    distance,
  } = preferenceData;

  useEffect(() => {
    setFilterData({
      ...filterData,
      allergenId: allergendata ? allergendata : [],
      dietaryId: dietarydata ? dietarydata : [],
      lifestyleId: lifestyledata ? lifestyledata : [],
      featuresId: featuredata ? featuredata : [],
      toggle: nearby,
      distance: distance ? distance : 0,
    });
    // console.log("filterData",filterData)
    setFilterData1({
      ...filterData1,
      allergenId: allergendata ? allergendata : [],
      dietaryId: dietarydata ? dietarydata : [],
      lifestyleId: lifestyledata ? lifestyledata : [],
      featuresId: featuredata ? featuredata : [],
      toggle: nearby,
      distance: distance ? distance : 0,
    });
    // console.log("filterData1",filterData1)
    // eslint-disable-next-line
  }, [preferenceData]);

  useEffect(() => {
    if (restaurantSortBy !== '') {
      setShortBy(restaurantSortBy)
    }
  }, [restaurantSortBy])

  useEffect(() => {
    if (props.location.state && props.location.state.dishes) {
      setFirstTab(false);
    }
    // eslint-disable-next-line
  }, [props.location.state && props.location.state.dishes]);
  // get Restaurant Data start

  const searchRestaurant_Data = useSelector((state) => {
    return state.restaurantSearch;
  });

  let {
    isLoading,
    allRestDishLoading,
    fourMoreRustLoading,
    fourMoreDishLoading,
    searchedRestaurantsList_Data,
    searchedDishList_Data,
    fourDishData,
    fourRestroData,
  } = searchRestaurant_Data;

  const myCordinates = useSelector((state) => {
    return state.googledata;
  });
  let { overalLocation = { lat: DEFAULT_LAT, lng: DEFAULT_LNG } } =
    myCordinates;

  // useEffect(() => {

  // }, [dispatch,location_data,props.location.search, props.location.menu, shortBy, allergen, dietary, lifestyle, features, distance, nearby]);

  useEffect(() => {
    if (
      overalLocation &&
      overalLocation.lat &&
      overalLocation.lng &&
      filterData1.allergenId === preferenceData.allergendata &&
      filterData1.dietaryId === preferenceData.dietarydata &&
      filterData1.lifestyleId === preferenceData.lifestyledata &&
      filterData1.featuresId === preferenceData.featuredata &&
      filterData1.distance === preferenceData.distance &&
      filterData1.toggle === preferenceData.nearby
    ) {
      // console.log('Dm hsadere=>', myLocation, "===>", location_data)
      if (firstTab) {
        dispatch(
          getSearchedRestaurantsList({
            userCoordinates: [
              overalLocation && overalLocation.lat
                ? overalLocation.lat
                : DEFAULT_LAT,
              overalLocation && overalLocation.lng
                ? overalLocation.lng
                : DEFAULT_LNG,
            ],
            styleOfmenu: parsed && parsed.menu ? parsed.menu : "",
            search: parsed && parsed.search ? parsed.search : "",
            sort: shortBy,
            allergen:
              filterData && filterData.allergenId ? filterData.allergenId : [],
            dietary:
              filterData && filterData.dietaryId ? filterData.dietaryId : [],
            lifestyle:
              filterData && filterData.lifestyleId
                ? filterData.lifestyleId
                : [],
            features:
              filterData && filterData.featuresId ? filterData.featuresId : [],
            distance:
              filterData && filterData.toggle
                ? 0
                : filterData && filterData.distance * 1000,
            start: 0,
            length: 7,
          })
        );
        setRestroVisible(7);
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [firstTab === true, overalLocation, props.location.search, props.location.menu, shortBy, filterData,]);

  //load more Restro Start
  const loadMoreRestro = () => {
    setRestroVisible(restroVisible + 4);
    dispatch(
      getFourRestaurantsData({
        userCoordinates: [
          overalLocation && overalLocation.lat
            ? overalLocation.lat
            : DEFAULT_LAT,
          overalLocation && overalLocation.lng
            ? overalLocation.lng
            : DEFAULT_LNG,
        ],
        styleOfmenu: parsed && parsed.menu ? parsed.menu : "",
        search: parsed && parsed.search ? parsed.search : "",
        sort: shortBy,
        allergen:
          filterData && filterData.allergenId ? filterData.allergenId : [],
        dietary: filterData && filterData.dietaryId ? filterData.dietaryId : [],
        lifestyle:
          filterData && filterData.lifestyleId ? filterData.lifestyleId : [],
        features:
          filterData && filterData.featuresId ? filterData.featuresId : [],
        distance:
          filterData && filterData.toggle
            ? 0
            : filterData && filterData.distance * 1000,
        start: restroVisible,
        length: 4,
      })
    );
  };
  //load more Restro Ends

  useEffect(() => {
    if (
      overalLocation &&
      overalLocation.lat &&
      overalLocation.lng &&
      filterData1.allergenId === preferenceData.allergendata &&
      filterData1.dietaryId === preferenceData.dietarydata &&
      filterData1.lifestyleId === preferenceData.lifestyledata &&
      filterData1.featuresId === preferenceData.featuredata &&
      filterData1.distance === preferenceData.distance &&
      filterData1.toggle === preferenceData.nearby
    ) {
      // console.log('Dm here=>', filterData1, "===>", preferenceData)
      if (!firstTab) {
        dispatch(
          getSearchedDishList({
            userCoordinates: [
              overalLocation && overalLocation.lat
                ? overalLocation.lat
                : DEFAULT_LAT,
              overalLocation && overalLocation.lng
                ? overalLocation.lng
                : DEFAULT_LNG,
            ],
            styleOfmenu: parsed && parsed.menu ? parsed.menu : "",
            search: parsed && parsed.search ? parsed.search : "",
            sort: shortBy,
            allergen:
              filterData && filterData.allergenId ? filterData.allergenId : [],
            dietary:
              filterData && filterData.dietaryId ? filterData.dietaryId : [],
            lifestyle:
              filterData && filterData.lifestyleId
                ? filterData.lifestyleId
                : [],
            features:
              filterData && filterData.featuresId ? filterData.featuresId : [],
            distance:
              filterData && filterData.toggle
                ? 0
                : filterData && filterData.distance * 1000,
            start: 0,
            length: 7,
          })
        );

        setDishVisible(7);
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [firstTab === false, overalLocation, props.location.search, props.location.menu, shortBy, filterData]);
  // get Restaurant Data Ends
  //load more dish Start
  const loadMoreDish = () => {
    setDishVisible(dishVisible + 4);
    dispatch(
      getFourDishData({
        userCoordinates: [
          overalLocation && overalLocation.lat
            ? overalLocation.lat
            : DEFAULT_LAT,
          overalLocation && overalLocation.lng
            ? overalLocation.lng
            : DEFAULT_LNG,
        ],
        styleOfmenu: parsed && parsed.menu ? parsed.menu : "",
        search: parsed && parsed.search ? parsed.search : "",
        sort: shortBy,
        allergen:
          filterData && filterData.allergenId ? filterData.allergenId : [],
        dietary: filterData && filterData.dietaryId ? filterData.dietaryId : [],
        lifestyle:
          filterData && filterData.lifestyleId ? filterData.lifestyleId : [],
        features:
          filterData && filterData.featuresId ? filterData.featuresId : [],
        distance:
          filterData && filterData.toggle
            ? 0
            : filterData && filterData.distance * 1000,
        start: dishVisible,
        length: 4,
      })
    );
  };
  //load more dish Ends

  //infinite scroll functionality start

  // const customScrolled = () => {
  //   //visible height +pixel scrolled = total height
  // };

  return (
    <>
      {/* All restaurantlist  Start */}
      {/* {JSON.stringify(props.location.search)} */}
      {/* {JSON.stringify(props.location.state&&props.location.state.allergendata)} */}
      {/* {JSON.stringify(props.location.state&&props.location.state.dietarydata)} */}

      {/* {JSON.stringify(parsed.search)} */}
      {/* {JSON.stringify(filterData1)} */}

      {/* {JSON.stringify(allergen)} */}

      <section className="fr-section allrestaurant-section">
        <div className="container">
          <div className="row pt-5 pb-5">
            <div className="col-sm-12 pt-4">
              <h1 className="text-center brandon-Bold text-uppercase text-white allrestaurant-label">
                {firstTab ? "All Restaurants" : "All Dishes"}
              </h1>
            </div>
          </div>
          <div className="allrestaurant-wrapper position-relative p-3">
            <div className="row">
              <div className="col-sm-12">
                <div className="mb-5 allrestaurant-filter" id="top_navbar">
                  {/* <AllResturantNav totalrestaurant={searchedRestaurantsList_Data&&searchedRestaurantsList_Data.totalRecords?searchedRestaurantsList_Data.totalRecords:"All"}/> */}
                  <section className="AllResturantNav">
                    <Navbar
                      bg="light"
                      variant="light"
                      className="align-items-center pl-0 pr-0 pb-3 allrestaurant-nav container"
                    >
                      <NavLink
                        to="/"
                        className="pt-0 pb-0 menurestaurant-btn mr-3"
                      >
                        <img
                          src={menuline}
                          className="img-fluid"
                          alt="menuline"
                          loading="lazy"
                        />
                      </NavLink>
                      {firstTab ? (
                        <h4 className="brandon-Bold restaurant-no mb-0">
                          {searchedRestaurantsList_Data &&
                            searchedRestaurantsList_Data.totalRecords
                            ? searchedRestaurantsList_Data.totalRecords
                            : "0"}
                          &nbsp;Restaurants
                        </h4>
                      ) : (
                        <h4 className="brandon-Bold restaurant-no mb-0">
                          {searchedDishList_Data &&
                            searchedDishList_Data.totalRecords
                            ? searchedDishList_Data.totalRecords
                            : "0"}
                          &nbsp;Dishes
                        </h4>
                      )}
                      {/* <h4 className="brandon-Bold restaurant-no mb-0">
                                                {searchedRestaurantsList_Data&&searchedRestaurantsList_Data.totalRecords?searchedRestaurantsList_Data.totalRecords:"0"}&nbsp;Restaurants
                                            </h4> */}
                      <div
                        ref={searchRef}
                        className="ml-auto d-flex shortby-btn"
                      >
                        <div className="d-none" id="selected_search_bar">
                          <div
                            type="button"
                            className="search-topnav mr-5 position-relative d-flex"
                            onClick={() => setOpenSearchBar(!openSearchBar)}
                          >
                            <span className="w-100  brandon-Medium mt-1 border-bottom">
                              {parsed && parsed.search
                                ? parsed.search
                                : "Search for restaurant or dish"}
                            </span>
                            <span>&nbsp;</span>
                            <div className="search-navicon">
                              <img
                                src={search_icon}
                                className="img-fluid ml-2"
                                alt="search_icon"
                                loading="lazy"
                              />
                            </div>
                          </div>
                          {/* <Button onClick={() => setOpenSearchBar(!openSearchBar)}>Search for restaurant or dish</Button> */}
                          <Collapse in={openSearchBar}>
                            <div
                              style={{
                                position: "absolute",
                                top: "8rem",
                                left: 0,
                                width: "100%",
                              }}
                            >
                              <div className="row">
                                <div className="col-sm-12">
                                  <div className="fr-wrapper fr-rl-wrapper">
                                    <FilterList
                                      showautosuggestion={false}
                                      openSearchBar={openSearchBar}
                                      mysearchdata={
                                        parsed && parsed.search
                                          ? parsed.search
                                          : ""
                                      }
                                    />
                                  </div>
                                </div>
                              </div>
                            </div>
                          </Collapse>
                        </div>

                        {/* Below form commented based on client request on 22-11-2021  */}
                        <Form
                          inline
                          className="mr-5"
                          onChange={(e) => {
                            dispatch(updateAllRestaurantSort(e.target.value))
                            // setShortBy(e.target.value);
                          }}
                        >
                          <Form.Group controlId="exampleForm.SelectCustom">
                            <Form.Label className="mr-2">Sort By:</Form.Label>
                            <Form.Control as="select" value={shortBy} custom>
                              <option value="relevance">Relevance</option>
                              <option value="popularity">Popularity</option>
                              <option value="priceh2l">
                                Price High to Low
                              </option>
                              <option value="pricel2h">
                                Price Low to High
                              </option>
                            </Form.Control>
                          </Form.Group>
                        </Form>

                        <button
                          className="filtershort-btn ml-2 p-0 filtershort-lightbtn"
                          onClick={() => {
                            setFilterModalShow(true);
                          }}
                        >
                          Filters
                          <img
                            width="20"
                            src={filtershorticonpink}
                            className="img-fluid"
                            alt="filterIcon"
                            loading="lazy"
                          />
                        </button>
                        <AllRestaurantFilterModal
                          show={filterModalShow}
                          onHide={filterModalClose}
                        />
                      </div>
                    </Navbar>
                  </section>
                </div>
              </div>
              <div className="col-sm-12">
                <div className="row">
                  <div className="col-sm-12 mb-5">
                    <div className="rstab-subhead d-flex justify-content-between align-items-center flex-wrap">
                      <div className="rstab-lists d-flex flex-wrap align-items-center">
                        <button
                          className={`rstab-btn mr-5 brandon-Bold  ${firstTab ? "active" : null
                            }`}
                          onClick={() => {
                            setFirstTab(true);
                          }}
                        >
                          Restaurants
                        </button>
                        <button
                          className={`rstab-btn mr-5 brandon-Bold  ${firstTab ? null : "active"
                            }`}
                          onClick={() => {
                            setFirstTab(false);
                          }}
                        >
                          Dishes
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              {firstTab ? (
                <React.Fragment>
                  <div className="col-sm-12">
                    <div className="row">
                      {isLoading ? (
                        <React.Fragment>
                          {[1, 2, 3, 4].map((index) => {
                            return (
                              <React.Fragment key={index}>
                                <div className="col-sm-6 col-md-6 col-lg-3 col-xl-3">
                                  <WebRestaurantDescSkeleton />
                                </div>
                              </React.Fragment>
                            );
                          })}
                        </React.Fragment>
                      ) : (
                        <React.Fragment>
                          {searchedRestaurantsList_Data &&
                            searchedRestaurantsList_Data.data &&
                            searchedRestaurantsList_Data.data.length > 0 ? (
                            <React.Fragment>
                              {searchedRestaurantsList_Data.data &&
                                searchedRestaurantsList_Data.data.map(
                                  (data, index) => {
                                    return (
                                      <React.Fragment key={index}>
                                        <div className="col-sm-6 col-md-6 col-lg-3 col-xl-3">
                                          <Link
                                            to={"/restaurant/" + data._id}
                                            style={{
                                              textDecoration: "none",
                                              color: "initial",
                                            }}
                                          >
                                            <DishBlock
                                              restaurant_name={
                                                data.name ? data.name : ""
                                              }
                                              restaurant_pic={
                                                data.restaurantProfilePhoto
                                                  ? data.restaurantProfilePhoto
                                                  : ""
                                              }
                                              kmvalue={
                                                data.distance &&
                                                  data.distance.text
                                                  ? data.distance.text
                                                  : ""
                                              }
                                              rating={4.5}
                                              restaurantfeature={
                                                data.restaurantFeaturesOptionsList
                                                  ? data.restaurantFeaturesOptionsList
                                                  : []
                                              }
                                            />
                                          </Link>
                                        </div>
                                      </React.Fragment>
                                    );
                                  }
                                )}

                              <React.Fragment>
                                {fourRestroData && fourRestroData.length > 0 ? (
                                  <React.Fragment>
                                    {fourRestroData &&
                                      fourRestroData.map((data, index) => {
                                        return (
                                          <React.Fragment key={index}>
                                            <div className="col-sm-6 col-md-6 col-lg-3 col-xl-3">
                                              <Link
                                                to={"/restaurant/" + data._id}
                                                style={{
                                                  textDecoration: "none",
                                                  color: "initial",
                                                }}
                                              >
                                                <DishBlock
                                                  restaurant_name={
                                                    data.name ? data.name : ""
                                                  }
                                                  restaurant_pic={
                                                    data.restaurantProfilePhoto
                                                      ? data.restaurantProfilePhoto
                                                      : ""
                                                  }
                                                  kmvalue={
                                                    data.distance &&
                                                      data.distance.text
                                                      ? data.distance.text
                                                      : ""
                                                  }
                                                  rating={4.5}
                                                  restaurantfeature={
                                                    data.restaurantFeaturesOptionsList
                                                      ? data.restaurantFeaturesOptionsList
                                                      : []
                                                  }
                                                />
                                              </Link>
                                            </div>
                                          </React.Fragment>
                                        );
                                      })}
                                  </React.Fragment>
                                ) : null}

                                {fourMoreRustLoading ? (
                                  <React.Fragment>
                                    {[1, 2, 3, 4].map((index) => {
                                      return (
                                        <React.Fragment key={index}>
                                          <div className="col-sm-6 col-md-6 col-lg-3 col-xl-3">
                                            <WebRestaurantDescSkeleton />
                                          </div>
                                        </React.Fragment>
                                      );
                                    })}
                                  </React.Fragment>
                                ) : null}
                              </React.Fragment>
                              {searchedRestaurantsList_Data &&
                                searchedRestaurantsList_Data.totalRecords <=
                                restroVisible ? null : (
                                <div className="col-sm-6 col-md-6 col-lg-3 col-xl-3">
                                  <button
                                    onClick={loadMoreRestro.bind(this)}
                                    className="btn filter-morebtn w-100"
                                  >
                                    <h4 className="brandon-Bold">
                                      <b>
                                        +
                                        {searchedRestaurantsList_Data &&
                                          searchedRestaurantsList_Data.totalRecords &&
                                          searchedRestaurantsList_Data.totalRecords -
                                          restroVisible}{" "}
                                        MORE
                                      </b>
                                    </h4>
                                  </button>
                                </div>
                              )}
                            </React.Fragment>
                          ) : (
                            <React.Fragment>
                              <div className="w-100 d-flex align-items-center justify-content-center ">
                                <img
                                  src={no_Data_Image}
                                  className="img-fluid"
                                  alt="img"
                                  loading="lazy"
                                />
                              </div>
                            </React.Fragment>
                          )}
                        </React.Fragment>
                      )}
                    </div>
                  </div>
                </React.Fragment>
              ) : (
                <React.Fragment>
                  <div className="col-sm-12">
                    <div className="row">
                      {allRestDishLoading ? (
                        <React.Fragment>
                          {[1, 2, 3, 4].map((index) => {
                            return (
                              <React.Fragment key={index}>
                                <div className="col-sm-6 col-md-6 col-lg-3 col-xl-3">
                                  <WebDiscDescriptionCompSkeleton />
                                </div>
                              </React.Fragment>
                            );
                          })}
                        </React.Fragment>
                      ) : (
                        <React.Fragment>
                          {searchedDishList_Data &&
                            searchedDishList_Data.data &&
                            searchedDishList_Data.data.length > 0 ? (
                            <React.Fragment>
                              {searchedDishList_Data.data &&
                                searchedDishList_Data.data.map(
                                  (data, index) => {
                                    return (
                                      <React.Fragment key={index}>
                                        <div className="col-sm-6 col-md-6 col-lg-3 col-xl-3 mb-4 pb-2">
                                          <Link
                                            to={
                                              "/restaurant_dish_info/" +
                                              data._id
                                            }
                                            style={{
                                              textDecoration: "none",
                                              color: "initial",
                                            }}
                                          >
                                            <DiscDescriptionComp
                                              dish_name={
                                                data.name ? data.name : ""
                                              }
                                              dish_image={
                                                data.dishPhoto
                                                  ? data.dishPhoto
                                                  : ""
                                              }
                                              dish_priceunit={
                                                data.dishPriceUnit
                                                  ? data.dishPriceUnit
                                                  : ""
                                              }
                                              dish_price={
                                                data.dishPrice
                                                  ? data.dishPrice
                                                  : "-"
                                              }
                                              dish_description={
                                                data.dishDescription
                                                  ? data.dishDescription
                                                  : ""
                                              }
                                              dish_menu={
                                                data.menuList
                                                  ? data.menuList
                                                  : []
                                              }
                                              dish_allergy={
                                                data.allergensList
                                                  ? data.allergensList
                                                  : []
                                              }
                                              dish_new_tag={
                                                data.new ? data.new : false
                                              }
                                              dish_available_tag={
                                                data.available
                                                  ? data.available
                                                  : false
                                              }
                                            />
                                          </Link>
                                        </div>
                                      </React.Fragment>
                                    );
                                  }
                                )}

                              <React.Fragment>
                                {fourDishData && fourDishData.length > 0 ? (
                                  <React.Fragment>
                                    {fourDishData &&
                                      fourDishData.map((data, index) => {
                                        return (
                                          <React.Fragment key={index}>
                                            <div className="col-sm-6 col-md-6 col-lg-3 col-xl-3 mb-4 pb-2">
                                              <Link
                                                to={
                                                  "/restaurant_dish_info/" +
                                                  data._id
                                                }
                                                style={{
                                                  textDecoration: "none",
                                                  color: "initial",
                                                }}
                                              >
                                                <DiscDescriptionComp
                                                  dish_name={
                                                    data.name ? data.name : ""
                                                  }
                                                  dish_image={
                                                    data.dishPhoto
                                                      ? data.dishPhoto
                                                      : ""
                                                  }
                                                  dish_priceunit={
                                                    data.dishPriceUnit
                                                      ? data.dishPriceUnit
                                                      : ""
                                                  }
                                                  dish_price={
                                                    data.dishPrice
                                                      ? data.dishPrice
                                                      : "-"
                                                  }
                                                  dish_description={
                                                    data.dishDescription
                                                      ? data.dishDescription
                                                      : ""
                                                  }
                                                  dish_menu={
                                                    data.menuList
                                                      ? data.menuList
                                                      : []
                                                  }
                                                  dish_allergy={
                                                    data.allergensList
                                                      ? data.allergensList
                                                      : []
                                                  }
                                                  dish_new_tag={
                                                    data.new ? data.new : false
                                                  }
                                                  dish_available_tag={
                                                    data.available
                                                      ? data.available
                                                      : false
                                                  }
                                                />
                                              </Link>
                                            </div>
                                          </React.Fragment>
                                        );
                                      })}
                                  </React.Fragment>
                                ) : null}

                                {fourMoreDishLoading ? (
                                  <React.Fragment>
                                    {[1, 2, 3, 4].map((index) => {
                                      return (
                                        <React.Fragment key={index}>
                                          <div className="col-sm-6 col-md-6 col-lg-3 col-xl-3">
                                            <WebDiscDescriptionCompSkeleton />
                                          </div>
                                        </React.Fragment>
                                      );
                                    })}
                                  </React.Fragment>
                                ) : null}
                              </React.Fragment>

                              {searchedDishList_Data &&
                                searchedDishList_Data.totalRecords <=
                                dishVisible ? null : (
                                <div className="col-sm-6 col-md-6 col-lg-3 col-xl-3">
                                  <button
                                    onClick={loadMoreDish.bind(this)}
                                    className="btn filter-morebtn w-100"
                                  >
                                    <h4 className="brandon-Bold">
                                      <b>
                                        +
                                        {searchedDishList_Data &&
                                          searchedDishList_Data.totalRecords &&
                                          searchedDishList_Data.totalRecords -
                                          dishVisible}{" "}
                                        MORE
                                      </b>
                                    </h4>
                                  </button>
                                </div>
                              )}
                            </React.Fragment>
                          ) : (
                            <React.Fragment>
                              <div className="w-100 d-flex align-items-center justify-content-center ">
                                <img
                                  src={no_Data_Image}
                                  className="img-fluid"
                                  alt="img"
                                  loading="lazy"
                                />
                              </div>
                            </React.Fragment>
                          )}
                        </React.Fragment>
                      )}
                    </div>
                  </div>
                </React.Fragment>
              )}
            </div>
          </div>
        </div>
        <br></br>
        <br></br>
      </section>
      {/* All restaurantlist  End */}
    </>
  );
};
export default AllRestaurant;
