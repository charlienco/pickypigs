import React from "react";
import SignUpSignInComponent from "../../components/SignUpSignInComponent/SignUpSignInComponent";
import FirstOverlapedCardComp from "../../components/FirstOverlapedCardComp/FirstOverlapedCardComp";
import SecondOverlapedCardComp from "../../components/SecondOverlapedCardComp/SecondOverlapedCardComp";
import BulletOverlapedRightCardComp from "../../components/BulletOverlapedCardComp/BulletOverlapedRightCardComp";
import img_1 from "../../assets/images/xd-image/Pic PWU 1.jpg";
import PWU_4 from "../../assets/images/xd-image/Pic PWU 4.jpg";
import PWU_6 from "../../assets/images/xd-image/Pic PWU 6.jpg";
// import img_2 from "../../assets/images/work-img.svg";

import Dashboard_01 from "../../assets/images/xd-image/Dashboard_01.png";
import Dashboard_03 from "../../assets/images/xd-image/Dashboard_03.png";

import pattern_img from "../../assets/images/Pattern.png";
import Tab_08 from "../../assets/images/xd-image/tab-8.png";

import JoinPickyPigComponent from "../../components/JoinPickyPigComponent/JoinPickyPigComponent";
import "./AdminLoginPage.scss";
import PlanSectionComp from "../../components/PlanSectionComp/PlanSectionComp";
import OurVisionComponent from "../../components/OurVisionComponent/OurVisionComponent";
import { showAdminSignUpPopup } from "../../redux/actions/restaurantAdminAction";
import { useDispatch } from "react-redux";
import BulletOverlapedLeftCardComp from "../../components/BulletOverlapedCardComp/BulletOverlapedLeftCardComp";
// import LoginPageHeader from "../../components/LoginPageHeader/LoginPageHeader";
// import LoginPageFooter from "../../components/LoginPageFooter/LoginPageFooter";
// import OurVisionComponent from "../../components/OurVisionComponent/OurVisionComponent";

const detail_0 = [
  " Save time, money, energy and effort in training hours, staff hours on shift and time spent back and forth to the kitchen.",
  " Free yourself from printing new allergy sheets and matrices every time a dish is updated or added.",
  " Support your teams and guests in providing all tracing, cleaning and policy information in a concise, transparent and easily accessible way.",
  " Put yourself on the map for the ultimate dining out application. The more accurate the information, the better the guest experience.",
  " Provide live personalised menus to each guest to meet their own unique needs.",
];

const detail_1 = [
  " Showcase your restaurant features, making it easy for your perfect guest to find you.",
  "Provide your guests with unique menus tailored to their every dining need.",
  "Offer dishes to meet a range of allergy requirements, dietary preferences and lifestyle choices.",
  "Calculate and display the allergen, calorie and macro content of every meal.",
  "Enable your guests to order from home, fuss free.",
  "Integrate with your POS system to allow information to be communicated straight away.",
];
const detail_2 = [
  "Manage your ingredients, recipes and dishes within your unique dashboard, giving you the chance to think more about making your menu sustainable and local.",
  "Use the reporting tool to identify all needs and trends in your business, helping with GP calculation, menu development and staff training.",
  "Secure and protect your business by offering a disclaimer to every guest, giving them the control and choice of how and what they do or don't eat.",
  "Enhance the guest experience before they even step foot in your venue, from searching and viewing, to ordering and arriving.",
];

const features_1 = [
  "Sign up with your restaurant, add backdrop image and logo for your venue. ",
  "Add all of your restaurant details, opening times, location, booking, details, and social channels.",
  "Select pre-set restaurant features, additionally add your own restaurant features specific to your venue.",
  "You choose the images that are displayed in your gallery and to every guess. ",
];
const features_2 = [
  "Pick pigs allows you to build a menu as close as possible to your own menu. ",
  "Firstly, create you menu's even add the times that they are available.",
  "Secondly, create the different categories for each menu.",
  "Should you require more detail you can add sub catogories for each topic to divide your menu further.",
  "Once your menu has been created, now you can start adding dishes. ",
];

const features_3 = [
  "Simply add the basics for each dish, title, description, and price.",
  "Select status of the dish new/available.",
  "Select pre-set allergies, dietry requires, lifestyle choices, and cooking methods.",
  "For more detail add each element and show whether they are customizable.",
  "Even add the calories and macros of each dish.",
];

const AdminLoginPage = () => {
  const dispatch = useDispatch();

  return (
    <>
      <section id="loginRef" className="gradient-bg">
        <div className="container">
          <SignUpSignInComponent />
        </div>
      </section>
      <section>
        <div className="container">
          <div>
            <div className="row">
              <div className="col-sm-12 text-center mb-5">
                <h1 className="heading-content brandon-Bold">WORK WITH US</h1>
                <p className="f-15">
                  Set yourself up on a whole new level of detail.
                </p>
              </div>
            </div>
            <BulletOverlapedLeftCardComp
              img={img_1}
              heading="Digitalise Today"
              detail={detail_0}
            />
            <BulletOverlapedRightCardComp
              img={Tab_08}
              heading="Fuss Free Food"
              detail={detail_1}
            />
            <BulletOverlapedLeftCardComp
              img={Dashboard_01}
              heading="The Whole Package"
              detail={detail_2}
            />
          </div>
          <JoinPickyPigComponent />
          <section className="mb-5">
            <div className="row">
              <div className="col-sm-12 text-center mb-5">
                <h1 className="heading-content brandon-Bold">HOW IT WORKS</h1>

                <p className="f-15">
                  Simple steps to digitalise your menu and have full
                  transparency.
                </p>
              </div>
            </div>
            <div>
              <SecondOverlapedCardComp
                img={PWU_4}
                workslist="works-list"
                heading="SIGN UP AND SET UP"
                detail={features_1}
              />
            </div>
            <div>
              <FirstOverlapedCardComp
                img={Dashboard_03}
                workslist="works-list"
                heading="BUILD YOUR MENU"
                detail={features_2}
              />
            </div>
            <div>
              <SecondOverlapedCardComp
                img={PWU_6}
                workslist="works-list"
                heading="ADD YOUR DISHES"
                detail={features_3}
              />
            </div>
          </section>
        </div>
      </section>
      <section className="bg-light-pink waiting-section">
        <div className="container pl-0 pr-0">
          <div className="bg-white waiting-wrapper d-flex align-items-center">
            <div className="container waiting-container">
              <div className="row align-items-center justify-content-between">
                <div className="what-waiting-wrapper">
                  <h4 className="brandon-Bold mb-2">
                    What are you waiting for?
                  </h4>
                  <p className="f-15 darkgray-txt">
                    Enquire today for your digital menu solution. Support your
                    teams, save yourself time and energy, gain more clarity and
                    transparency on your menu, all while increases guest
                    experience and expectations.
                  </p>
                </div>
                <button
                  onClick={() => {
                    dispatch(showAdminSignUpPopup(true));
                  }}
                  className="signup-btn pinkbg-btn min-height-50 border-radius-25 min-width-270 shadow-light"
                >
                  Sign up
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>
      <br />
      <br />
      <br />
      <br />
      <br />
      <section>
        <PlanSectionComp />
      </section>

      <section>
        <div className="container">
          <div className="row">
            <div className="col-sm-12">
              <div className="patternimg-wrapper">
                <img
                  src={pattern_img}
                  className="img-fluid"
                  loading="lazy"
                  alt="img"
                />
              </div>
            </div>
          </div>
        </div>
      </section>
      <section className="">
        <OurVisionComponent />
      </section>
    </>
  );
};

export default AdminLoginPage;
