import Axios from "./axios";
import { setAlert } from "./alertAction";
import { RESTAURANT_ADMIN_URL } from "../../shared/constant";
import Swal from "sweetalert2";
const deActivatedMessage =
  '<span class="text">Currently your account is <strong class="modal-color">deactivated</strong>, if not contacted by Sasha within 24 hours re it being approved please email her <strong><a class="modal-color email-link" href = "mailto: sasha@pickypigs.com">sasha@pickypigs.com</a></strong></span>';
// register a user
export const registerRestaurant = (user) => {
  return async (dispatch) => {
    try {
      dispatch({ type: "REGISTER_RESTAURANT_REQUEST" });
      let config = {
        headers: {
          "Content-Type": "application/json",
        },
      };
      let dataURL = `/auth/restaurant_signup`;
      let response = await Axios.post(dataURL, JSON.stringify(user), config);
      dispatch({ type: "REGISTER_RESTAURANT_SUCCESS", payload: response.data });
      dispatch(setAlert("Restaurant Registration Successful", "success"));
      dispatch(showAdminSignUpPopup(false));
      Swal.fire({
        title: "<span class='modal-color'>You've successfully signed up!",
        html: deActivatedMessage,
        icon: "warning",
        iconColor: "#cb007b",
        confirmButtonColor: "#cb007b",
        confirmButtonText: "Ok",
        confirmButtonClass: "btn btn-confirm",
        showClass: {
          popup: "animated fadeInDown faster",
          icon: "animated heartBeat delay-1s",
        },
      });
    } catch (error) {
      dispatch({ type: "REGISTER_RESTAURANT_FAILURE", payload: error });
      if (error.response) {
        dispatch(setAlert(`${error.response.data.message}`, "error"));
      } else {
        dispatch(setAlert("Something Went Wrong!", "error"));
      }
    }
  };
};

export const getAdminLogin = (data) => {
  return async (dispatch) => {
    try {
      dispatch({ type: "GET_ADMINLOGIN_REQUEST" });
      let config = {
        headers: {
          "Content-Type": "application/json",
        },
      };
      let dataURL = `/auth/login`;
      let response = await Axios.post(
        dataURL,
        JSON.stringify({ ...data, role: "restaurant_admin" }),
        config
      );
      dispatch({ type: "GET_ADMINLOGIN_SUCCESS", payload: response.data });
      dispatch(setAlert("Admin LogIn Success", "success"));
      if (response) {
        window.open(
          `${RESTAURANT_ADMIN_URL}/login/${response.data.token}`,
          "_self", // <- This is what makes it open in a new window.
          "replace=true"
        );
      }
      // const token = localStorage.getItem("access_token");
      // if (token) axios.defaults.headers.common = { "x-access-token": token };
    } catch (error) {
      dispatch({ type: "GET_ADMINLOGIN_FAILURE", payload: error });
      if (error.response.data.message === "Your account has been inactived.") {
        Swal.fire({
          // title: '<span class="modal-color">Successfully SignUp!',
          html: deActivatedMessage,
          icon: "warning",
          iconColor: "#cb007b",
          confirmButtonColor: "#cb007b",
          confirmButtonText: "Ok",
          confirmButtonClass: "btn btn-confirm",
          showClass: {
            popup: "animated fadeInDown faster",
            icon: "animated heartBeat delay-1s",
          },
        });
      } else {
        dispatch(setAlert("Wrong Credential", "error"));
      }
    }
  };
};

export const forgotAdminPassword = (data) => {
  return async (dispatch) => {
    try {
      dispatch({ type: "FORGOT_ADMINPASSWORD_REQUEST" });
      let config = {
        headers: {
          "Content-Type": "application/json",
        },
      };
      let dataURL = `/auth/forgot_password`;
      let response = await Axios.post(
        dataURL,
        JSON.stringify({ ...data, role: "restaurant_admin" }),
        config
      );
      dispatch({
        type: "FORGOT_ADMINPASSWORD_SUCCESS",
        payload: response.data,
      });
      if (response.data.message === "Email is not found !") {
        dispatch(setAlert(`Email is not found !`, "error"));
      } else {
        dispatch(setAlert(`${response.data.message}`, "success"));
      }
    } catch (error) {
      dispatch({ type: "FORGOT_ADMINPASSWORD_FAILURE", payload: error });
      dispatch(setAlert("Something Went Wrong", "error"));
    }
  };
};

export const showAdminSignUpPopup = (data, type) => {
  return async (dispatch) => {
    try {
      await dispatch({
        type: "SHOW_ADMINSIGNUP_POPUP",
        payload: { data: data, type: type },
      });
    } catch (error) {
      console.error(error);
    }
  };
};

export const showContactUsPopup = (data) => {
  return async (dispatch) => {
    try {
      await dispatch({
        type: "SHOW_CONTACTUS_POPUP",
        payload: data,
      });
    } catch (error) {
      console.error(error);
    }
  };
};
