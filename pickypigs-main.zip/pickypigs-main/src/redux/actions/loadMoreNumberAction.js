export const MobileHomePageRestaurantQuantity = (data) => {
    
    return async(dispatch)=>{
      try{
          await dispatch({type :"MOBILEHOMEPAGE_RESTAURANT_QUANTITY " , payload : data });
      }
      catch(error){
          console.error(error);
      }
    }
  };