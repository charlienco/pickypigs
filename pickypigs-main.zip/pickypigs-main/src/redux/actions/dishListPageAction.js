import Axios from './axios';
import {setAlert} from './alertAction';


export const getSubscribedDishListData=()=>{
  return async(dispatch)=>{
      try{
          dispatch({type:"GET_SUBSCRIBEDDISHLISTDATA_REQUEST"});
          let config= {
            headers:{
             "Content-Type":"application/json"
             }
          }
          let dataURL=`/frontend/restaurant_search_page/green_slider_dishes`
          let response = await Axios.post(dataURL,config );
          dispatch({type:"GET_SUBSCRIBEDDISHLISTDATA_SUCCESS",payload:response.data});
      }
    
      catch(error){
          dispatch({type:"GET_SUBSCRIBEDDISHLISTDATA_FAILURE",payload:error});
          if (error.response) {
            dispatch(setAlert(`${error.response.data.message}`, 'error'));
          } else {
            dispatch(setAlert('Something Went Wrong!', 'error'));
          }
      }
  }
};


export const getFavouriteDishListData=(data)=>{
  return async(dispatch)=>{
      try{
          dispatch({type:"GET_FAVOURITEDISHLISTDATA_REQUEST"});
          let config= {
            headers:{
             "Content-Type":"application/json"
             }
          }
          let dataURL=`/frontend/restaurant_search_page/page_1_dishes`
          let response = await Axios.post(dataURL,JSON.stringify(data),config );
          dispatch({type:"GET_FAVOURITEDISHLISTDATA_SUCCESS",payload:response.data});
      }
    
      catch(error){
          dispatch({type:"GET_FAVOURITEDISHLISTDATA_FAILURE",payload:error});
          if (error.response) {
            dispatch(setAlert(`${error.response.data.message}`, 'error'));
          } else {
            dispatch(setAlert('Something Went Wrong!', 'error'));
          }
      }
  }
};

export const getFourFavouriteDishListData=(data)=>{
  return async(dispatch)=>{
      try{
          dispatch({type:"GET_FOURFAVOURITEDISHLISTDATA_REQUEST"});
          let config= {
            headers:{
             "Content-Type":"application/json"
             }
          }
          let dataURL=`/frontend/restaurant_search_page/page_1_dishes`
          let response = await Axios.post(dataURL,JSON.stringify(data),config );
          dispatch({type:"GET_FOURFAVOURITEDISHLISTDATA_SUCCESS",payload:response.data});
      }
    
      catch(error){
          dispatch({type:"GET_FOURFAVOURITEDISHLISTDATA_FAILURE",payload:error});
          if (error.response) {
            dispatch(setAlert(`${error.response.data.message}`, 'error'));
          } else {
            dispatch(setAlert('Something Went Wrong!', 'error'));
          }
      }
  }
};



export const getWhatsNewDishList=(data)=>{
  return async(dispatch)=>{
      try{
          dispatch({type:"GET_WHATSNEWDISHLIST_REQUEST"});
          let config= {
            headers:{
             "Content-Type":"application/json"
             }
          }
          let dataURL=`/frontend/restaurant_search_page/page_1_dishes`
          let response = await Axios.post(dataURL,JSON.stringify(data),config );
          dispatch({type:"GET_WHATSNEWDISHLIST_SUCCESS",payload:response.data});
      }
    
      catch(error){
          dispatch({type:"GET_WHATSNEWDISHLIST_FAILURE",payload:error});
          if (error.response) {
            dispatch(setAlert(`${error.response.data.message}`, 'error'));
          } else {
            dispatch(setAlert('Something Went Wrong!', 'error'));
          }
      }
  }
};

export const getFourWhatsNewDishList=(data)=>{
  return async(dispatch)=>{
      try{
          dispatch({type:"GET_FOURWHATSNEWDISHLIST_REQUEST"});
          let config= {
            headers:{
             "Content-Type":"application/json"
             }
          }
          let dataURL=`/frontend/restaurant_search_page/page_1_dishes`
          let response = await Axios.post(dataURL,JSON.stringify(data),config );
          dispatch({type:"GET_FOURWHATSNEWDISHLIST_SUCCESS",payload:response.data});
      }
    
      catch(error){
          dispatch({type:"GET_FOURWHATSNEWDISHLIST_FAILURE",payload:error});
          if (error.response) {
            dispatch(setAlert(`${error.response.data.message}`, 'error'));
          } else {
            dispatch(setAlert('Something Went Wrong!', 'error'));
          }
      }
  }
};

export const getBreakfastMenuDishList=(data)=>{
    return async(dispatch)=>{
        try{
            dispatch({type:"GET_BREAKFASTMENUDISHLIST_REQUEST"});
            let config= {
              headers:{
               "Content-Type":"application/json"
               }
            }
            let dataURL=`/frontend/restaurant_search_page/page_1_dishes`
            let response = await Axios.post(dataURL,JSON.stringify(data),config );
            dispatch({type:"GET_BREAKFASTMENUDISHLIST_SUCCESS",payload:response.data});
        }
      
        catch(error){
            dispatch({type:"GET_BREAKFASTMENUDISHLIST_FAILURE",payload:error});
            if (error.response) {
              dispatch(setAlert(`${error.response.data.message}`, 'error'));
            } else {
              dispatch(setAlert('Something Went Wrong!', 'error'));
            }
        }
    }
};

export const getFourBreakfastMenuDishList=(data)=>{
  return async(dispatch)=>{
      try{
          dispatch({type:"GET_FOURBREAKFASTMENUDISHLIST_REQUEST"});
          let config= {
            headers:{
             "Content-Type":"application/json"
             }
          }
          let dataURL=`/frontend/restaurant_search_page/page_1_dishes`
          let response = await Axios.post(dataURL,JSON.stringify(data),config );
          dispatch({type:"GET_FOURBREAKFASTMENUDISHLIST_SUCCESS",payload:response.data});
      }
    
      catch(error){
          dispatch({type:"GET_FOURBREAKFASTMENUDISHLIST_FAILURE",payload:error});
          if (error.response) {
            dispatch(setAlert(`${error.response.data.message}`, 'error'));
          } else {
            dispatch(setAlert('Something Went Wrong!', 'error'));
          }
      }
  }
};

export const getLunchMenuDishList=(data)=>{
    return async(dispatch)=>{
        try{
            dispatch({type:"GET_LUNCHTMENUDISHLIST_REQUEST"});
            let config= {
              headers:{
               "Content-Type":"application/json"
               }
            }
            let dataURL=`/frontend/restaurant_search_page/page_1_dishes`
            let response = await Axios.post(dataURL,JSON.stringify(data),config );
            dispatch({type:"GET_LUNCHTMENUDISHLIST_SUCCESS",payload:response.data});
        }
      
        catch(error){
            dispatch({type:"GET_LUNCHTMENUDISHLIST_FAILURE",payload:error});
            if (error.response) {
              dispatch(setAlert(`${error.response.data.message}`, 'error'));
            } else {
              dispatch(setAlert('Something Went Wrong!', 'error'));
            }
        }
    }
};  

export const getFourLunchMenuDishList=(data)=>{
  return async(dispatch)=>{
      try{
          dispatch({type:"GET_FOURLUNCHTMENUDISHLIST_REQUEST"});
          let config= {
            headers:{
             "Content-Type":"application/json"
             }
          }
          let dataURL=`/frontend/restaurant_search_page/page_1_dishes`
          let response = await Axios.post(dataURL,JSON.stringify(data),config );
          dispatch({type:"GET_FOURLUNCHTMENUDISHLIST_SUCCESS",payload:response.data});
      }
    
      catch(error){
          dispatch({type:"GET_FOURLUNCHTMENUDISHLIST_FAILURE",payload:error});
          if (error.response) {
            dispatch(setAlert(`${error.response.data.message}`, 'error'));
          } else {
            dispatch(setAlert('Something Went Wrong!', 'error'));
          }
      }
  }
}; 

export const getDinnerMenuDishList=(data)=>{
    return async(dispatch)=>{
        try{
            dispatch({type:"GET_DINNERMENUDISHLIST_REQUEST"});
            let config= {
              headers:{
               "Content-Type":"application/json"
               }
            }
            let dataURL=`/frontend/restaurant_search_page/page_1_dishes`
            let response = await Axios.post(dataURL,JSON.stringify(data),config );
            dispatch({type:"GET_DINNERMENUDISHLIST_SUCCESS",payload:response.data});
        }
      
        catch(error){
            dispatch({type:"GET_DINNERMENUDISHLIST_FAILURE",payload:error});
            if (error.response) {
              dispatch(setAlert(`${error.response.data.message}`, 'error'));
            } else {
              dispatch(setAlert('Something Went Wrong!', 'error'));
            }
        }
    }
};

export const getFourDinnerMenuDishList=(data)=>{
  return async(dispatch)=>{
      try{
          dispatch({type:"GET_FOURDINNERMENUDISHLIST_REQUEST"});
          let config= {
            headers:{
             "Content-Type":"application/json"
             }
          }
          let dataURL=`/frontend/restaurant_search_page/page_1_dishes`
          let response = await Axios.post(dataURL,JSON.stringify(data),config );
          dispatch({type:"GET_FOURDINNERMENUDISHLIST_SUCCESS",payload:response.data});
      }
    
      catch(error){
          dispatch({type:"GET_FOURDINNERMENUDISHLIST_FAILURE",payload:error});
          if (error.response) {
            dispatch(setAlert(`${error.response.data.message}`, 'error'));
          } else {
            dispatch(setAlert('Something Went Wrong!', 'error'));
          }
      }
  }
};

export const getDessertMenuDishList=(data)=>{
    return async(dispatch)=>{
        try{
            dispatch({type:"GET_DESSERTMENUDISHLIST_REQUEST"});
            let config= {
              headers:{
               "Content-Type":"application/json"
               }
            }
            let dataURL=`/frontend/restaurant_search_page/page_1_dishes`
            let response = await Axios.post(dataURL,JSON.stringify(data),config );
            dispatch({type:"GET_DESSERTMENUDISHLIST_SUCCESS",payload:response.data});
        }
      
        catch(error){
            dispatch({type:"GET_DESSERTMENUDISHLIST_FAILURE",payload:error});
            if (error.response) {
              dispatch(setAlert(`${error.response.data.message}`, 'error'));
            } else {
              dispatch(setAlert('Something Went Wrong!', 'error'));
            }
        }
    }
};

export const getFourDessertMenuDishList=(data)=>{
  return async(dispatch)=>{
      try{
          dispatch({type:"GET_FOURDESSERTMENUDISHLIST_REQUEST"});
          let config= {
            headers:{
             "Content-Type":"application/json"
             }
          }
          let dataURL=`/frontend/restaurant_search_page/page_1_dishes`
          let response = await Axios.post(dataURL,JSON.stringify(data),config );
          dispatch({type:"GET_FOURDESSERTMENUDISHLIST_SUCCESS",payload:response.data});
      }
    
      catch(error){
          dispatch({type:"GET_FOURDESSERTMENUDISHLIST_FAILURE",payload:error});
          if (error.response) {
            dispatch(setAlert(`${error.response.data.message}`, 'error'));
          } else {
            dispatch(setAlert('Something Went Wrong!', 'error'));
          }
      }
  }
};

export const getBuffetMenuDishList=(data)=>{
    return async(dispatch)=>{
        try{
            dispatch({type:"GET_BUFFETMENUDISHLIST_REQUEST"});
            let config= {
              headers:{
               "Content-Type":"application/json"
               }
            }
            let dataURL=`/frontend/restaurant_search_page/page_1_dishes`
            let response = await Axios.post(dataURL,JSON.stringify(data),config );
            dispatch({type:"GET_BUFFETMENUDISHLIST_SUCCESS",payload:response.data});
        }
      
        catch(error){
            dispatch({type:"GET_BUFFETMENUDISHLIST_FAILURE",payload:error});
            if (error.response) {
              dispatch(setAlert(`${error.response.data.message}`, 'error'));
            } else {
              dispatch(setAlert('Something Went Wrong!', 'error'));
            }
        }
    }
};

export const getFourBuffetMenuDishList=(data)=>{
  return async(dispatch)=>{
      try{
          dispatch({type:"GET_FOURBUFFETMENUDISHLIST_REQUEST"});
          let config= {
            headers:{
             "Content-Type":"application/json"
             }
          }
          let dataURL=`/frontend/restaurant_search_page/page_1_dishes`
          let response = await Axios.post(dataURL,JSON.stringify(data),config );
          dispatch({type:"GET_FOURBUFFETMENUDISHLIST_SUCCESS",payload:response.data});
      }
    
      catch(error){
          dispatch({type:"GET_FOURBUFFETMENUDISHLIST_FAILURE",payload:error});
          if (error.response) {
            dispatch(setAlert(`${error.response.data.message}`, 'error'));
          } else {
            dispatch(setAlert('Something Went Wrong!', 'error'));
          }
      }
  }
};


export const getDrinksMenuDishList=(data)=>{
    return async(dispatch)=>{
        try{
            dispatch({type:"GET_DRINKSMENUDISHLIST_REQUEST"});
            let config= {
              headers:{
               "Content-Type":"application/json"
               }
            }
            let dataURL=`/frontend/restaurant_search_page/page_1_dishes`
            let response = await Axios.post(dataURL,JSON.stringify(data),config );
            dispatch({type:"GET_DRINKSMENUDISHLIST_SUCCESS",payload:response.data});
        }
      
        catch(error){
            dispatch({type:"GET_DRINKSMENUDISHLIST_FAILURE",payload:error});
            if (error.response) {
              dispatch(setAlert(`${error.response.data.message}`, 'error'));
            } else {
              dispatch(setAlert('Something Went Wrong!', 'error'));
            }
        }
    }
};

export const getFourDrinksMenuDishList=(data)=>{
  return async(dispatch)=>{
      try{
          dispatch({type:"GET_FOURDRINKSMENUDISHLIST_REQUEST"});
          let config= {
            headers:{
             "Content-Type":"application/json"
             }
          }
          let dataURL=`/frontend/restaurant_search_page/page_1_dishes`
          let response = await Axios.post(dataURL,JSON.stringify(data),config );
          dispatch({type:"GET_FOURDRINKSMENUDISHLIST_SUCCESS",payload:response.data});
      }
    
      catch(error){
          dispatch({type:"GET_FOURDRINKSMENUDISHLIST_FAILURE",payload:error});
          if (error.response) {
            dispatch(setAlert(`${error.response.data.message}`, 'error'));
          } else {
            dispatch(setAlert('Something Went Wrong!', 'error'));
          }
      }
  }
};


export const getNibbleMenuDishList=(data)=>{
    return async(dispatch)=>{
        try{
            dispatch({type:"GET_NIBBLEMENUDISHLIST_REQUEST"});
            let config= {
              headers:{
               "Content-Type":"application/json"
               }
            }
            let dataURL=`/frontend/restaurant_search_page/page_1_dishes`
            let response = await Axios.post(dataURL,JSON.stringify(data),config );
            dispatch({type:"GET_NIBBLEMENUDISHLIST_SUCCESS",payload:response.data});
        }
      
        catch(error){
            dispatch({type:"GET_NIBBLEMENUDISHLIST_FAILURE",payload:error});
            if (error.response) {
              dispatch(setAlert(`${error.response.data.message}`, 'error'));
            } else {
              dispatch(setAlert('Something Went Wrong!', 'error'));
            }
        }
    }
};

export const getFourNibbleMenuDishList=(data)=>{
  return async(dispatch)=>{
      try{
          dispatch({type:"GET_FOURNIBBLEMENUDISHLIST_REQUEST"});
          let config= {
            headers:{
             "Content-Type":"application/json"
             }
          }
          let dataURL=`/frontend/restaurant_search_page/page_1_dishes`
          let response = await Axios.post(dataURL,JSON.stringify(data),config );
          dispatch({type:"GET_FOURNIBBLEMENUDISHLIST_SUCCESS",payload:response.data});
      }
    
      catch(error){
          dispatch({type:"GET_FOURNIBBLEMENUDISHLIST_FAILURE",payload:error});
          if (error.response) {
            dispatch(setAlert(`${error.response.data.message}`, 'error'));
          } else {
            dispatch(setAlert('Something Went Wrong!', 'error'));
          }
      }
  }
};

export const getSetmenuMenuDishList=(data)=>{
    return async(dispatch)=>{
        try{
            dispatch({type:"GET_SETMENUMENUDISHLIST_REQUEST"});
            let config= {
              headers:{
               "Content-Type":"application/json"
               }
            }
            let dataURL=`/frontend/restaurant_search_page/page_1_dishes`
            let response = await Axios.post(dataURL,JSON.stringify(data),config );
            dispatch({type:"GET_SETMENUMENUDISHLIST_SUCCESS",payload:response.data});
        }
      
        catch(error){
            dispatch({type:"GET_SETMENUMENUDISHLIST_FAILURE",payload:error});
            if (error.response) {
              dispatch(setAlert(`${error.response.data.message}`, 'error'));
            } else {
              dispatch(setAlert('Something Went Wrong!', 'error'));
            }
        }
    }
};

export const getFourSetmenuMenuDishList=(data)=>{
  return async(dispatch)=>{
      try{
          dispatch({type:"GET_FOURSETMENUMENUDISHLIST_REQUEST"});
          let config= {
            headers:{
             "Content-Type":"application/json"
             }
          }
          let dataURL=`/frontend/restaurant_search_page/page_1_dishes`
          let response = await Axios.post(dataURL,JSON.stringify(data),config );
          dispatch({type:"GET_FOURSETMENUMENUDISHLIST_SUCCESS",payload:response.data});
      }
    
      catch(error){
          dispatch({type:"GET_FOURSETMENUMENUDISHLIST_FAILURE",payload:error});
          if (error.response) {
            dispatch(setAlert(`${error.response.data.message}`, 'error'));
          } else {
            dispatch(setAlert('Something Went Wrong!', 'error'));
          }
      }
  }
};