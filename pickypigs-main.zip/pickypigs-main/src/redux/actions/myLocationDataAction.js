import Axios from './axios';



export const getMyLocationName = (value) => {
    
    return async(dispatch)=>{
      try{
          await dispatch({type :"GET_MYLOCATION_NAME" , payload : value });
      }
      catch(error){
          console.error(error);
      }
  }
};

  // update product Form
export const getMyLocationData = (value) => {
    
    return async(dispatch)=>{
      try{
          await dispatch({type :"GET_MYLOCATION_DATA" , payload : value });
      }
      catch(error){
          console.error(error);
      }
  }
};
