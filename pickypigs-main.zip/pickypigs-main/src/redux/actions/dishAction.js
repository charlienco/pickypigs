import Axios from './axios';
import {setAlert} from './alertAction';

export const getSelectedRestaurantDetailInfoData=(selectedId,data,history)=>{
  return async(dispatch)=>{
      try{
          dispatch({type:"GET_SELECTEDRESTAURANTDETAILINFO_REQUEST"});
          let config= {
            headers:{
             "Content-Type":"application/json"
             }
          }
          let dataURL=`/frontend/restaurant/info/${selectedId}`
          let response = await Axios.post(dataURL,JSON.stringify(data),config );
          dispatch({type:"GET_SELECTEDRESTAURANTDETAILINFO_SUCCESS",payload:response.data});

          if(response.data&&response.data.restaurantDetail&&response.data.restaurantDetail.length<=0){
            history.push("/404");
          }
      }
    
      catch(error){
          dispatch({type:"GET_SELECTEDRESTAURANTDETAILINFO_FAILURE",payload:error});
          if (error.response) {
            dispatch(setAlert(`${error.response.data.message}`, 'error'));
            history.push("/404");
          } else {
            dispatch(setAlert('Something Went Wrong!', 'error'));
          }
      }
  }
};



export const getSelectedDiscInfoData=(selectedId,history)=>{
    return async(dispatch)=>{
        try{
            dispatch({type:"GET_SELECTEDDISCINFO_REQUEST"});

            let response = await Axios.get(`/frontend/restaurant/dish_info/${selectedId}`)
            dispatch({type:"GET_SELECTEDDISCINFO_SUCCESS",payload:response.data});
            if(response.data&&response.data.dishDetails&&response.data.dishDetails.length<=0){
              history.push("/404");
            }
        }
      
        catch(error){
            dispatch({type:"GET_SELECTEDDISCINFO_FAILURE",payload:error});
            if (error.response) {
              dispatch(setAlert(`${error.response.data.message}`, 'error'));
              history.push("/404");
            } else {
              dispatch(setAlert('Something Went Wrong!', 'error'));
            }
        }
    }
};