import React from "react";
import Skeleton from "react-loading-skeleton";

const SearchAutoSuggestionMobileSkeleton=()=>{
    return(
        <React.Fragment>
            
            <div className="d-flex align-items-center mt-1 mb-1 p-2">
                <Skeleton count={1} width={60}  height={60} style={{borderRadius:10}}/>
                <div className="w-100">
                    <Skeleton count={1}  className="w-100 ml-3" />
                </div>
            </div>
            <div style={{borderBottom:'2px solid #f7f7f7'}}></div>

        </React.Fragment>
    )
};

export default SearchAutoSuggestionMobileSkeleton;