import React from "react";
import './AllRestaurantMobileSkeleton.scss'
import Skeleton from "react-loading-skeleton";

const AllRestaurantMobileSkeleton=()=>{
    return(
        <React.Fragment>
            <section>
            <div className="AllRestaurantMobileSkeleton-content">
                <div className="rs-infoblock">
                    <div className="media  mb-3">
                        <Skeleton count={1} width={80}  height={80} style={{borderRadius:10}}/>
                        <div className="media-body">
                            <div className="d-flex justify-content-between align-items-baseline">
                                <div className="restaurant-details brandon-Medium pl-3">
                                    <div className="d-flex justify-content-between align-items-center mb-2">
                                        <Skeleton count={1}  className="w-100"/>
                                    </div>
                                    <Skeleton count={2}  className="w-100"/>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="foodtypes-wrap d-flex mb-2">
                        <Skeleton circle={true} height={38} width={38} className="mr-3"/>
                        <Skeleton circle={true} height={38} width={38} className="mr-3"/>
                        <Skeleton circle={true} height={38} width={38} className="mr-3"/>
                    </div>
                 
                    <div>
                        <Skeleton count={3}  className="w-100"/>
                    </div>
                    <div className="border-top mt-2 mb-2"></div>
                    <div className="d-flex justify-content-between align-items-center">
                        <Skeleton count={1} width={100} />
                        <Skeleton count={1}  width={100} />
                    </div>
                </div>
            </div>
        </section>
            
        </React.Fragment>
    )
};

export default AllRestaurantMobileSkeleton;