import React from "react";
import Skeleton from "react-loading-skeleton";

const RestaurantDiscInfoMobilePageSkeleton=()=>{
    return(
        <React.Fragment>
            <div className="container">
                <div>
                    <Skeleton count={1}  height={250}  className="w-100" />
                </div>
                <div className="pt-2 pb-2 bg-white">
                    <div className="pt-3 pb-3">
                        <Skeleton count={3}  className="w-100"/>
                    </div>
                    <div className="d-flex">
                        <Skeleton circle={true} height={45} width={45} className="mr-3"/>
                        <Skeleton circle={true} height={45} width={45} className="mr-3"/>
                        <Skeleton circle={true} height={45} width={45} className="mr-3"/>
                    </div>

                    <div className="p-3 mt-5" style={{boxShadow:'0px 3px 16px 0px #00000010',borderRadius:10}}>
                        <span className="d-flex align-items-center w-100 mb-2">
                            <Skeleton circle={true} height={38} width={38} className="mr-3"/>
                            <div  className="w-100">
                                <Skeleton count={1}  className="w-100"/>
                            </div>
                        </span>
                        <Skeleton count={1}  className="w-100"/>
                    </div>
               
                    <div className="p-3 mt-5" style={{boxShadow:'0px 3px 16px 0px #00000010',borderRadius:10}}>
                        <span className="d-flex align-items-center w-100">
                            <Skeleton circle={true} height={38} width={38} className="mr-3"/>
                            <div  className="w-100">
                                <Skeleton count={1}  className="w-100"/>
                            </div>
                        </span>
                    </div>

                </div>
            </div>
            
        </React.Fragment>
    )
};

export default RestaurantDiscInfoMobilePageSkeleton;