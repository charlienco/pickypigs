import React from "react";
import Skeleton from "react-loading-skeleton";
import Slider from "react-slick";

const RestaurantDiscMobileMenuTabSkeleton=()=>{
    const settings = {
        dots: true,
        infinite: false,
        slidesToShow: 1.2,
        slidesToScroll: 1,
           
      };
    return(
        <React.Fragment>
            <div className="container">
                                                        
                <Slider {...settings}>
                    <div className="pt-3 pb-2 pl-0 pr-3">
                        <Skeleton count={1}  height={250}  className="w-100" />
                    </div>
                    <div className="pt-3 pb-2 pl-0 pr-3">
                        <Skeleton count={1}  height={250}  className="w-100" />
                    </div>
                </Slider>
               
                <div className="pt-2 pb-2 bg-white">
                    <div className="p-3 mt-5" style={{boxShadow:'0px 3px 16px 0px #00000010',borderRadius:10}}>
                        <span className="d-flex align-items-center w-100 mb-2">
                            <Skeleton circle={true} height={38} width={38} className="mr-3"/>
                            <div  className="w-100">
                                <Skeleton count={1} width={100} />
                            </div>
                        </span>
                        <Skeleton count={1}  className="w-100 mt-3"/>
                        <Skeleton count={1}  className="w-100 mt-3"/>
                        <Skeleton count={1}  className="w-100 mt-3"/>
                        <Skeleton count={1}  className="w-100 mt-3"/>
                    </div>
                </div>
            </div>
            
        </React.Fragment>
    )
};

export default RestaurantDiscMobileMenuTabSkeleton;