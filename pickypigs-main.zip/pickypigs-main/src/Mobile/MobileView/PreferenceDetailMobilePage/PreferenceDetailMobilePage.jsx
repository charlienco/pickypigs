import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import {
  getAllAllergyData,
  getAllDietaryData,
  getAllLifestyleData,
  getAllRestaurantFeaturesData,
} from "../../../redux/actions/allergyAction";
import * as Yup from "yup";
import { Formik, Form } from "formik";
import "./PreferenceDetailMobilePage.scss";
import { SERVER_URL } from "../../../shared/constant";
import { useHistory, useLocation } from "react-router-dom";
import {
  getUserProfileDetail,
  updateUserProfileDetail,
} from "../../../redux/actions/userProfileAction";
import editblack_icon from "../../../assets/images/mobile_imgs/edit-black-icon.svg";

const PreferenceDetailMobilePage = () => {
  const dispatch = useDispatch();
  const [reset, setReset] = useState(false);
  const history = useHistory();
  const [editForm, setEditForm] = useState(true);

  const location = useLocation();
  const current_page = location.pathname;

  useEffect(() => {
    dispatch(getAllAllergyData());
    dispatch(getAllDietaryData());
    dispatch(getAllLifestyleData());
    dispatch(getAllRestaurantFeaturesData());
  }, [dispatch]);

  let allAllergy_data = useSelector((state) => {
    return state.allergy;
  });
  let { allergy_Data, dietary_Data, lifestyle_Data, restaurantFeatures_Data } =
    allAllergy_data;

  useEffect(() => {
    if (!localStorage.getItem("access_token")) {
      history.push("/");
    } else {
      dispatch(getUserProfileDetail(history));
    }
    // eslint-disable-next-line
  }, [dispatch, localStorage.getItem("access_token")]);

  const User_Data = useSelector((state) => {
    return state.userProfile;
  });

  const { userProfile_Data } = User_Data;
  const { userDetail } = userProfile_Data;

  const initialValues = {
    allergenInformation:
      userDetail &&
      userDetail.myPreferences &&
      userDetail.myPreferences.allergenInformation
        ? userDetail.myPreferences.allergenInformation.filter(
            (val) =>
              allergy_Data &&
              allergy_Data.data &&
              allergy_Data.data.map((data) => data._id).includes(val)
          )
        : [],
    dietaryPreferences:
      userDetail &&
      userDetail.myPreferences &&
      userDetail.myPreferences.dietaryPreferences
        ? userDetail.myPreferences.dietaryPreferences.filter(
            (val) =>
              dietary_Data &&
              dietary_Data.data &&
              dietary_Data.data.map((data) => data._id).includes(val)
          )
        : [],
    lifestyleChoice:
      userDetail &&
      userDetail.myPreferences &&
      userDetail.myPreferences.lifestyleChoice
        ? userDetail.myPreferences.lifestyleChoice.filter(
            (val) =>
              lifestyle_Data &&
              lifestyle_Data.data &&
              lifestyle_Data.data.map((data) => data._id).includes(val)
          )
        : [],
    restaurantFeatures:
      userDetail &&
      userDetail.myPreferences &&
      userDetail.myPreferences.restaurantFeatures
        ? userDetail.myPreferences.restaurantFeatures.filter(
            (val) =>
              restaurantFeatures_Data &&
              restaurantFeatures_Data.data &&
              restaurantFeatures_Data.data.map((data) => data._id).includes(val)
          )
        : [],
  };
  const initialValues2 = {
    allergenInformation: [],
    dietaryPreferences: [],
    lifestyleChoice: [],
    restaurantFeatures: [],
  };

  const validationSchema = Yup.object().shape({
    // allergenId: Yup.array().required('Please Select Allergen'),
    // dietaryId: Yup.array().required('Please Select  Dietary'),
    // lifestyleId: Yup.array().required('Please Select Lifestyle'),
    // featuresId: Yup.array().required('Please Select Restaurant Feature'),
  });

  const handleAlergy = (e, alergy, setFieldValue) => {
    e.preventDefault();
    if (alergy.indexOf(e.target.id) !== -1) {
      var Index = alergy.indexOf(e.target.id);
      if (Index > -1) {
        // setAlergy(alergy.slice(0,Index).concat(alergy.slice(Index+ 1, alergy.length)));
        setFieldValue(
          "allergenInformation",
          alergy.filter((myallergy) => myallergy !== e.target.id)
        );
      }
    } else {
      setFieldValue("allergenInformation", [...alergy, e.target.id]);
    }
  };

  const handleDietaryPreference = (e, dietary, setFieldValue) => {
    e.preventDefault();
    if (dietary.indexOf(e.target.id) !== -1) {
      var Index = dietary.indexOf(e.target.id);
      if (Index > -1) {
        setFieldValue(
          "dietaryPreferences",
          dietary.filter((mydietary) => mydietary !== e.target.id)
        );
      }
    } else {
      setFieldValue("dietaryPreferences", [...dietary, e.target.id]);
    }
  };

  const handleLifestyle = (e, lifestyle, setFieldValue) => {
    e.preventDefault();
    if (lifestyle.indexOf(e.target.id) !== -1) {
      var Index = lifestyle.indexOf(e.target.id);
      if (Index > -1) {
        setFieldValue(
          "lifestyleChoice",
          lifestyle.filter((mylifestyle) => mylifestyle !== e.target.id)
        );
      }
    } else {
      setFieldValue("lifestyleChoice", [...lifestyle, e.target.id]);
    }
  };

  const handleRestaurant = (e, restaurant, setFieldValue) => {
    e.preventDefault();
    if (restaurant.indexOf(e.target.id) !== -1) {
      var Index = restaurant.indexOf(e.target.id);
      if (Index > -1) {
        setFieldValue(
          "restaurantFeatures",
          restaurant.filter((myrestaurant) => myrestaurant !== e.target.id)
        );
      }
    } else {
      setFieldValue("restaurantFeatures", [...restaurant, e.target.id]);
    }
  };
  const onSubmit = (fields) => {
    dispatch(updateUserProfileDetail({ myPreferences: fields }));
    setEditForm(true);
  };

  return (
    <>
      <section>
        <section className="PreferenceDetailMobilePage-comp">
          <div className="row">
            <div className="col-sm-12">
              <div className="col-sm-12 mt-3">
                <div className="d-flex justify-content-between align-items-center">
                  <h4 className="brandon-Bold mb-3">My Preferences</h4>
                  {current_page === "/preference_mobile" ? (
                    <React.Fragment>
                      {editForm ? (
                        <button
                          className="btn d-inline-flex align-items-center justify-content-center mb-3 "
                          type="button"
                          onClick={() => {
                            setEditForm(false);
                          }}
                        >
                          <img
                            src={editblack_icon}
                            className="img_fluid"
                            alt="img"
                            width="20px"
                            loading="lazy"
                          />
                        </button>
                      ) : null}
                    </React.Fragment>
                  ) : null}
                </div>
              </div>
            </div>
          </div>
          <Formik
            enableReinitialize={true}
            initialValues={!reset ? initialValues : initialValues2}
            validationSchema={validationSchema}
            onSubmit={onSubmit}
          >
            {({ values, resetForm, setFieldValue }) => (
              <Form>
                <div className="row">
                  <div className="col-sm-12">
                    <div className="col-sm-12">
                      <div className="col-sm-12 preferences-wrapper pb-1">
                        <div className="d-flex justify-content-end">
                          {editForm ? (
                            <button
                              className="btn d-inline-flex align-items-center justify-content-center mb-3 preference-profileform-btn"
                              type="button"
                              onClick={() => {
                                setEditForm(false);
                              }}
                            >
                              <img
                                src={editblack_icon}
                                className="img_fluid"
                                alt="img"
                                loading="lazy"
                              />
                            </button>
                          ) : (
                            <button
                              className="clearall-btn text-right"
                              type="reset"
                              onClick={() => {
                                setReset(true);
                              }}
                            >
                              Clear All
                            </button>
                          )}
                        </div>
                        {/* {JSON.stringify(values)} */}
                        <div className="main-accordion-wrapper ">
                          <div
                            className="accordion accordion-main "
                            id="accordionExample"
                          >
                            <div className="accordion-item">
                              <div id="headingOne">
                                <div
                                  className="mb-3 mt-3 pt-1 pb-1 w-100 accordion-button d-flex justify-content-between align-items-center accordion-header position-relative"
                                  type="button"
                                  data-bs-toggle="collapse"
                                  data-bs-target="#collapseOne"
                                  aria-expanded="true"
                                  aria-controls="collapseOne"
                                >
                                  <div className="accordion-title">
                                    <h5 className="brandon-Bold mb-0">
                                      I’m allergic to
                                    </h5>
                                    <p className="brandon-Medium txt-darkgreen mb-0">
                                      Select your allergens
                                    </p>
                                  </div>
                                  <div className="expand-button position-absolute top-0 right-0"></div>
                                </div>
                              </div>
                              <div
                                id="collapseOne"
                                className="accordion-collapse collapse show"
                                aria-labelledby="headingOne"
                                data-bs-parent="#accordionExample1"
                              >
                                <div className="accordion-body">
                                  <section className="accordion-list__item ">
                                    <div className="row">
                                      <div className="col-sm-12">
                                        {/* {JSON.stringify(values.allergenInformation)} */}
                                        <div className="allergen-btn-wrapper d-flex align-items-start flex-wrap">
                                          {allergy_Data &&
                                            allergy_Data.data &&
                                            allergy_Data.data.map(
                                              (data, index) => {
                                                return (
                                                  <React.Fragment key={index}>
                                                    {editForm ? (
                                                      <React.Fragment>
                                                        <button
                                                          id={data._id}
                                                          type="button"
                                                          className={`allergen-btn d-flex flex-column justify-content-center mr-4 mb-3 p-0 align-items-center ${
                                                            userDetail &&
                                                            userDetail.myPreferences &&
                                                            userDetail.myPreferences.allergenInformation.indexOf(
                                                              data._id
                                                            ) !== -1 &&
                                                            "active"
                                                          }`}
                                                        >
                                                          <div className="allergen-icon d-flex align-items-center justify-content-center mb-2">
                                                            <img
                                                              src={`${SERVER_URL}/${data.image}`}
                                                              className="img-fluid"
                                                              loading="lazy"
                                                              alt="img"
                                                            />
                                                          </div>
                                                          <span className="mb-0 f-12 txt-lightgray">
                                                            {data.name}
                                                          </span>
                                                        </button>
                                                      </React.Fragment>
                                                    ) : (
                                                      <React.Fragment>
                                                        <button
                                                          id={data._id}
                                                          onClick={(e) => {
                                                            handleAlergy(
                                                              e,
                                                              values.allergenInformation,
                                                              setFieldValue
                                                            );
                                                          }}
                                                          type="button"
                                                          className={`allergen-btn d-flex flex-column justify-content-center mr-4 mb-3 p-0 align-items-center ${
                                                            values.allergenInformation &&
                                                            values.allergenInformation.indexOf(
                                                              data._id
                                                            ) !== -1 &&
                                                            "active"
                                                          }`}
                                                        >
                                                          <div
                                                            id={data._id}
                                                            className="allergen-icon d-flex align-items-center justify-content-center mb-2"
                                                            onClick={(e) => {
                                                              handleAlergy(
                                                                e,
                                                                values.allergenInformation,
                                                                setFieldValue
                                                              );
                                                            }}
                                                          >
                                                            <img
                                                              id={data._id}
                                                              src={`${SERVER_URL}/${data.image}`}
                                                              className="img-fluid"
                                                              loading="lazy"
                                                              alt="img"
                                                              onClick={(e) => {
                                                                handleAlergy(
                                                                  e,
                                                                  values.allergenInformation,
                                                                  setFieldValue
                                                                );
                                                              }}
                                                            />
                                                          </div>
                                                          <span
                                                            id={data._id}
                                                            className="mb-0 f-12 txt-lightgray"
                                                            onClick={(e) => {
                                                              handleAlergy(
                                                                e,
                                                                values.allergenInformation,
                                                                setFieldValue
                                                              );
                                                            }}
                                                          >
                                                            {data.name}
                                                          </span>
                                                        </button>
                                                      </React.Fragment>
                                                    )}
                                                  </React.Fragment>
                                                );
                                              }
                                            )}
                                        </div>
                                      </div>
                                    </div>
                                  </section>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="dotted_border"></div>
                        <div className="main-accordion-wrapper ">
                          <div
                            className="accordion accordion-main "
                            id="accordionExample2"
                          >
                            <div className="accordion-item">
                              <div
                                className="mb-3 mt-3 pt-1 pb-1 w-100 accordion-button d-flex justify-content-between align-items-center accordion-header position-relative"
                                id="headingTwo"
                              >
                                <div
                                  className="w-100 accordion-button"
                                  type="button"
                                  data-bs-toggle="collapse"
                                  data-bs-target="#collapseTwo"
                                  aria-expanded="true"
                                  aria-controls="collapseTwo"
                                >
                                  <div className="accordion-title">
                                    <h5 className="brandon-Bold mb-0">
                                      My diet is
                                    </h5>
                                    <p className="brandon-Medium txt-darkgreen mb-0">
                                      Select your dietary preferences
                                    </p>
                                  </div>
                                  <div className="expand-button position-absolute top-0 right-0"></div>
                                </div>
                              </div>
                              <div
                                id="collapseTwo"
                                className="accordion-collapse collapse show"
                                aria-labelledby="headingTwo"
                                data-bs-parent="#accordionExample2"
                              >
                                <div className="accordion-body">
                                  <section className="accordion-list__item ">
                                    <div className="row">
                                      <div className="col-sm-12">
                                        <div className="dietary-wrapper d-flex flex-wrap">
                                          {dietary_Data &&
                                            dietary_Data.data &&
                                            dietary_Data.data.map(
                                              (data, index) => {
                                                return (
                                                  <React.Fragment key={index}>
                                                    {editForm ? (
                                                      <React.Fragment>
                                                        <button
                                                          id={data._id}
                                                          type="button"
                                                          className={`tags-btn mr-3 mb-3 ${
                                                            userDetail &&
                                                            userDetail.myPreferences &&
                                                            userDetail.myPreferences.dietaryPreferences.indexOf(
                                                              data._id
                                                            ) !== -1 &&
                                                            "active"
                                                          }`}
                                                        >
                                                          {data.name}
                                                        </button>
                                                      </React.Fragment>
                                                    ) : (
                                                      <React.Fragment>
                                                        <button
                                                          id={data._id}
                                                          type="button"
                                                          onClick={(e) => {
                                                            handleDietaryPreference(
                                                              e,
                                                              values.dietaryPreferences,
                                                              setFieldValue
                                                            );
                                                          }}
                                                          className={`tags-btn mr-3 mb-3 ${
                                                            values.dietaryPreferences &&
                                                            values.dietaryPreferences.indexOf(
                                                              data._id
                                                            ) !== -1 &&
                                                            "active"
                                                          }`}
                                                        >
                                                          {data.name}
                                                        </button>
                                                      </React.Fragment>
                                                    )}
                                                  </React.Fragment>
                                                );
                                              }
                                            )}
                                        </div>
                                      </div>
                                    </div>
                                  </section>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="dotted_border"></div>
                        <div className="main-accordion-wrapper ">
                          <div
                            className="accordion accordion-main "
                            id="accordionExample3"
                          >
                            <div className="accordion-item">
                              <div
                                className="mb-3 mt-3 pt-1 pb-1 w-100 accordion-button d-flex justify-content-between align-items-center accordion-header position-relative"
                                id="headingThree"
                              >
                                <div
                                  className="w-100 accordion-button"
                                  type="button"
                                  data-bs-toggle="collapse"
                                  data-bs-target="#collapseThree"
                                  aria-expanded="true"
                                  aria-controls="collapseThree"
                                >
                                  <div className="accordion-title">
                                    <h5 className="brandon-Bold mb-0">
                                      My Lifestyle is
                                    </h5>
                                    <p className="brandon-Medium txt-darkgreen mb-0">
                                      Select your Lifestyle choice
                                    </p>
                                  </div>
                                  <div className="expand-button position-absolute top-0 right-0"></div>
                                </div>
                              </div>
                              <div
                                id="collapseThree"
                                className="accordion-collapse collapse show"
                                aria-labelledby="headingThree"
                                data-bs-parent="#accordionExample3"
                              >
                                <div className="accordion-body">
                                  <section className="accordion-list__item ">
                                    <div className="row">
                                      <div className="col-sm-12">
                                        <div className="lifestyle-wrapper d-flex flex-wrap">
                                          {lifestyle_Data &&
                                            lifestyle_Data.data &&
                                            lifestyle_Data.data.map(
                                              (data, index) => {
                                                return (
                                                  <React.Fragment key={index}>
                                                    {editForm ? (
                                                      <React.Fragment>
                                                        <button
                                                          id={data._id}
                                                          type="button"
                                                          className={`tags-btn mr-4 mb-4 ${
                                                            userDetail &&
                                                            userDetail.myPreferences &&
                                                            userDetail.myPreferences.lifestyleChoice.indexOf(
                                                              data._id
                                                            ) !== -1 &&
                                                            "active"
                                                          }`}
                                                        >
                                                          {data.name}
                                                        </button>
                                                      </React.Fragment>
                                                    ) : (
                                                      <React.Fragment>
                                                        <button
                                                          id={data._id}
                                                          type="button"
                                                          onClick={(e) => {
                                                            handleLifestyle(
                                                              e,
                                                              values.lifestyleChoice,
                                                              setFieldValue
                                                            );
                                                          }}
                                                          className={`tags-btn mr-4 mb-4 ${
                                                            values.lifestyleChoice &&
                                                            values.lifestyleChoice.indexOf(
                                                              data._id
                                                            ) !== -1 &&
                                                            "active"
                                                          }`}
                                                        >
                                                          {data.name}
                                                        </button>
                                                      </React.Fragment>
                                                    )}
                                                  </React.Fragment>
                                                );
                                              }
                                            )}
                                        </div>
                                      </div>
                                    </div>
                                  </section>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="dotted_border"></div>
                        <div className="main-accordion-wrapper ">
                          <div
                            className="accordion accordion-main "
                            id="accordionExample4"
                          >
                            <div className="accordion-item">
                              <div
                                className="mb-3 mt-3 pt-1 pb-1 w-100 accordion-button d-flex justify-content-between align-items-center accordion-header position-relative"
                                id="headingFour"
                              >
                                <div
                                  className="w-100 accordion-button"
                                  type="button"
                                  data-bs-toggle="collapse"
                                  data-bs-target="#collapseFour"
                                  aria-expanded="true"
                                  aria-controls="collapseFour"
                                >
                                  <div className="accordion-title">
                                    <h5 className="brandon-Bold mb-0">
                                      Restaurant Type
                                    </h5>
                                    <p className="brandon-Medium txt-darkgreen mb-0">
                                      Select the type of restaurants you’re
                                      looking for
                                    </p>
                                  </div>
                                  <div className="expand-button position-absolute top-0 right-0"></div>
                                </div>
                              </div>
                              <div
                                id="collapseFour"
                                className="accordion-collapse collapse show"
                                aria-labelledby="headingFour"
                                data-bs-parent="#accordionExample4"
                              >
                                <div className="accordion-body">
                                  <section className="accordion-list__item ">
                                    <div className="row">
                                      <div className="col-sm-12">
                                        <div className="rsfeatures-wrapper d-flex flex-wrap">
                                          {restaurantFeatures_Data &&
                                            restaurantFeatures_Data.data &&
                                            restaurantFeatures_Data.data.map(
                                              (data, index) => {
                                                return (
                                                  <React.Fragment key={index}>
                                                    {editForm ? (
                                                      <React.Fragment>
                                                        <button
                                                          id={data._id}
                                                          type="button"
                                                          className={`tags-btn mr-4 mb-4 ${
                                                            userDetail &&
                                                            userDetail.myPreferences &&
                                                            userDetail.myPreferences.restaurantFeatures.indexOf(
                                                              data._id
                                                            ) !== -1 &&
                                                            "active"
                                                          }`}
                                                        >
                                                          {data.name}
                                                        </button>
                                                      </React.Fragment>
                                                    ) : (
                                                      <React.Fragment>
                                                        <button
                                                          id={data._id}
                                                          type="button"
                                                          onClick={(e) => {
                                                            handleRestaurant(
                                                              e,
                                                              values.restaurantFeatures,
                                                              setFieldValue
                                                            );
                                                          }}
                                                          className={`tags-btn mr-4 mb-4 ${
                                                            values.restaurantFeatures &&
                                                            values.restaurantFeatures.indexOf(
                                                              data._id
                                                            ) !== -1 &&
                                                            "active"
                                                          }`}
                                                        >
                                                          {data.name}
                                                        </button>
                                                      </React.Fragment>
                                                    )}
                                                  </React.Fragment>
                                                );
                                              }
                                            )}
                                        </div>
                                      </div>
                                    </div>
                                  </section>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                {editForm ? null : (
                  <div className="d-flex justify-content-center mb-3 preference-bottom-btn">
                    <button
                      className="lightgray-btn btn cancel-btn mr-4"
                      type="reset"
                      onClick={() => {
                        resetForm();
                        setReset(false);
                        setEditForm(true);
                      }}
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="theme-pink-btn apply-btn brandon-Bold"
                    >
                      Apply
                    </button>
                  </div>
                )}
              </Form>
            )}
          </Formik>
        </section>
      </section>
    </>
  );
};

export default PreferenceDetailMobilePage;
