import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useHistory, useParams } from "react-router";
import { RestaurantDetailMobileComp } from "../../MobileComponents/RestaurantDetailMobileComp/RestaurantDetailMobileComp";
import RestaurantGalleeryMobileComp from "../../MobileComponents/RestaurantGalleeryMobileComp/RestaurantGalleeryMobileComp";
import RestaurantInfoMobileComponent from "../../MobileComponents/RestaurantInfoMobileComponent/RestaurantInfoMobileComponent";
import RestaurantMenuMobileComp from "../../MobileComponents/RestaurantMenuMobileComp/RestaurantMenuMobileComp";
import RestaurantReviewMobileComp from "../../MobileComponents/RestaurantReviewMobileComp/RestaurantReviewMobileComp";
import {
  getCategorySubcategoryDishesList,
  getmenuTabTopPickList,
  getRestaurantMenuTabList,
} from "../../../redux/actions/restaurantMenuTabAction";
import { getSelectedRestaurantDetailInfoData } from "../../../redux/actions/dishAction";
import { DEFAULT_LAT, DEFAULT_LNG } from "../../../shared/constant";
import "./RestaurantDiscMobilePage.scss";
import RestaurantDiscMobilePageSkeleton from "../../Skeleton/RestaurantDiscMobilePageSkeleton/RestaurantDiscMobilePageSkeleton";
import RestaurantDiscMobileMenuTabSkeleton from "../../Skeleton/RestaurantDiscMobileMenuTabSkeleton/RestaurantDiscMobileMenuTabSkeleton";
import filtershorticonpink from "../../../assets/images/filtershort-pinkicon.svg";
import search_icon from "../../../assets/images/search_icon.svg";
import RestaurantMenuAllergyFilterMobilePage from "../RestaurantMenuAllergyFilterMobilePage/RestaurantMenuAllergyFilterMobilePage";
import { updatePreferenceFilter } from "../../../redux/actions/globalPreferenceFilterAction";
import useDebounce from "../../../shared/useDebounce.hook";

const RestaurantDiscMobilePage = () => {
  const dispatch = useDispatch();
  const history = useHistory();
  const params = useParams();
  let restaurantId = params.restId;

  let [mobileTabs, setMobileTabs] = useState({
    tab1: true,
    tab2: false,
    tab3: false,
    tab4: false,
  });

  const [searchData, setSearchData] = useState("");
  const [selectData, setSelectData] = useState("priceh2l");
  const [filterData, setFilterData] = useState({
    allergenId: [],
    dietaryId: [],
    lifestyleId: [],
  });
  const [filterData1, setFilterData1] = useState({
    allergenId: [],
    dietaryId: [],
    lifestyleId: [],
  });
  const [filterModalShow, setFilterModalShow] = useState(false);
  const filterModalClose = () => {
    setFilterModalShow(false);
  };

  const debouncedSearchTerm = useDebounce(searchData, 500);

  /////////updating preference Starts//////////

  let User_Data = useSelector((state) => {
    return state.userProfile;
  });
  let { userProfile_Data = {} } = User_Data;

  let User_loginstatus_Data = useSelector((state) => {
    return state.general.userLoginStatus_Data;
  });

  useEffect(() => {
    if (User_loginstatus_Data) {
      if (
        userProfile_Data &&
        userProfile_Data.userDetail &&
        userProfile_Data.userDetail.myPreferences &&
        userProfile_Data.userDetail.myPreferences.allergenInformation
      ) {
        dispatch(
          updatePreferenceFilter(
            "allergendata",
            userProfile_Data &&
              userProfile_Data.userDetail &&
              userProfile_Data.userDetail.myPreferences &&
              userProfile_Data.userDetail.myPreferences.allergenInformation
          )
        );
      }
      if (
        userProfile_Data &&
        userProfile_Data.userDetail &&
        userProfile_Data.userDetail.myPreferences &&
        userProfile_Data.userDetail.myPreferences.dietaryPreferences
      ) {
        dispatch(
          updatePreferenceFilter(
            "dietarydata",
            userProfile_Data &&
              userProfile_Data.userDetail &&
              userProfile_Data.userDetail.myPreferences &&
              userProfile_Data.userDetail.myPreferences.dietaryPreferences
          )
        );
      }
      if (
        userProfile_Data &&
        userProfile_Data.userDetail &&
        userProfile_Data.userDetail.myPreferences &&
        userProfile_Data.userDetail.myPreferences.lifestyleChoice
      ) {
        dispatch(
          updatePreferenceFilter(
            "lifestyledata",
            userProfile_Data &&
              userProfile_Data.userDetail &&
              userProfile_Data.userDetail.myPreferences &&
              userProfile_Data.userDetail.myPreferences.lifestyleChoice
          )
        );
      }
      if (
        userProfile_Data &&
        userProfile_Data.userDetail &&
        userProfile_Data.userDetail.myPreferences &&
        userProfile_Data.userDetail.myPreferences.restaurantFeatures
      ) {
        dispatch(
          updatePreferenceFilter(
            "featuredata",
            userProfile_Data &&
              userProfile_Data.userDetail &&
              userProfile_Data.userDetail.myPreferences &&
              userProfile_Data.userDetail.myPreferences.restaurantFeatures
          )
        );
      }
      // setTimeout(() => {
      //     dispatch(getUserLoginStatusData(false));
      //   }, 3000);
    }
  }, [dispatch, userProfile_Data, User_loginstatus_Data]);

  /////////updating preference ends//////////

  const preferenceData = useSelector((state) => {
    return state.myPreference.selectedPreference;
  });
  let {
    allergendata = [],
    dietarydata = [],
    lifestyledata = [],
  } = preferenceData;

  useEffect(() => {
    setFilterData({
      ...filterData,
      allergenId: allergendata ? allergendata : [],
      dietaryId: dietarydata ? dietarydata : [],
      lifestyleId: lifestyledata ? lifestyledata : [],
    });
    // console.log("filterData",filterData)
    setFilterData1({
      ...filterData1,
      allergenId: allergendata ? allergendata : [],
      dietaryId: dietarydata ? dietarydata : [],
      lifestyleId: lifestyledata ? lifestyledata : [],
    });
    // console.log("filterData1",filterData1)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [preferenceData]);

  const myCordinates = useSelector((state) => {
    return state.googledata;
  });
  let { overalLocation = { lat: DEFAULT_LAT, lng: DEFAULT_LNG } } =
    myCordinates;

  useEffect(() => {
    if (overalLocation && overalLocation.lat && overalLocation.lng) {
      dispatch(
        getSelectedRestaurantDetailInfoData(
          restaurantId,
          {
            userCoordinates: [
              overalLocation && overalLocation.lat ? overalLocation.lat : "",
              overalLocation && overalLocation.lng ? overalLocation.lng : "",
            ],
          },
          history
        )
      );
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [restaurantId, overalLocation]);

  const restaurant_data = useSelector((state) => {
    return state.dishes.selectedRestaurantDetail_Data;
  });
  let myLoading = useSelector((state) => {
    return state.dishes.isResturantLoading;
  });

  useEffect(() => {
    dispatch(getRestaurantMenuTabList(restaurantId));
  }, [dispatch, restaurantId]);
  useEffect(() => {
    if (
      filterData1.allergenId === preferenceData.allergendata &&
      filterData1.dietaryId === preferenceData.dietarydata &&
      filterData1.lifestyleId === preferenceData.lifestyledata
    ) {
      dispatch(
        getmenuTabTopPickList({
          restaurantId: restaurantId,
          sort: selectData,
          search: searchData,
          allergen:
            filterData && filterData.allergenId ? filterData.allergenId : [],
          dietary:
            filterData && filterData.dietaryId ? filterData.dietaryId : [],
          lifestyle:
            filterData && filterData.lifestyleId ? filterData.lifestyleId : [],
        })
      );
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [restaurantId, debouncedSearchTerm, selectData, filterData]);
  useEffect(() => {
    if (
      filterData1.allergenId === preferenceData.allergendata &&
      filterData1.dietaryId === preferenceData.dietarydata &&
      filterData1.lifestyleId === preferenceData.lifestyledata
    ) {
      dispatch(
        getCategorySubcategoryDishesList({
          restaurantId: restaurantId,
          sort: selectData,
          search: searchData,
          allergen:
            filterData && filterData.allergenId ? filterData.allergenId : [],
          dietary:
            filterData && filterData.dietaryId ? filterData.dietaryId : [],
          lifestyle:
            filterData && filterData.lifestyleId ? filterData.lifestyleId : [],
        })
      );
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [dispatch, restaurantId, debouncedSearchTerm, selectData, filterData]);

  const MenuTab_data = useSelector((state) => {
    return state.restaurantMenuTab;
  });
  let { isLoading, menuTabTopPick_Data, menuTabCategory_Data } = MenuTab_data;
 
  return (
    <>
      <section>
        <div className="RestaurantDiscMobilePage-infotab">
          {myLoading ? (
            <React.Fragment>
              <RestaurantDiscMobilePageSkeleton />
            </React.Fragment>
          ) : (
            <React.Fragment>
              <RestaurantDetailMobileComp
                restaurant_image={
                  restaurant_data && restaurant_data.restaurantCoverPhoto
                    ? restaurant_data.restaurantCoverPhoto
                    : ""
                }
                restaurant_name={
                  restaurant_data && restaurant_data.name
                    ? restaurant_data.name
                    : ""
                }
                restaurant_location={
                  restaurant_data &&
                  restaurant_data.address &&
                  restaurant_data.address.street
                    ? restaurant_data.address.street
                    : ""
                }
                restaurant_distance={
                  restaurant_data &&
                  restaurant_data.distance &&
                  restaurant_data.distance.text
                    ? restaurant_data.distance.text
                    : ""
                }
                restaurant_cuisine={
                  restaurant_data &&
                  restaurant_data.restaurantFeatures &&
                  restaurant_data.restaurantFeatures.cuisineTypeList
                    ? restaurant_data.restaurantFeatures.cuisineTypeList
                    : []
                }
                restaurant_feature={
                  restaurant_data &&
                  restaurant_data.restaurantFeatures &&
                  restaurant_data.restaurantFeatures
                    .restaurantFeaturesOptionsList
                    ? restaurant_data.restaurantFeatures
                        .restaurantFeaturesOptionsList
                    : []
                }
                restaurant_time={
                  restaurant_data &&
                  restaurant_data.restaurantDetails &&
                  restaurant_data.restaurantDetails.openingTimings
                    ? restaurant_data.restaurantDetails.openingTimings
                    : {}
                }
                rest_about={
                  restaurant_data && restaurant_data.about
                    ? restaurant_data.about
                    : ""
                }
              />
              <div className="row">
                <div className="col-sm-12">
                  <div className="col-sm-12">
                    <div
                      className="mt-3 mb-3"
                      style={{
                        borderBottom: "2px #d9d9d9",
                        borderBottomStyle: "dotted",
                      }}
                    ></div>
                  </div>
                </div>
              </div>

              <div className="row mt-3">
                <div className="col-sm-12">
                  <div className="col-sm-12">
                    <div className="d-flex justify-content-between align-items-center flex-wrap restaurantdetail-infotab">
                      <button
                        className={`mr-2 brandon-Bold text-uppercase ${
                          mobileTabs.tab1 ? "active" : null
                        }`}
                        onClick={() => {
                          setMobileTabs({
                            tab1: true,
                            tab2: false,
                            tab3: false,
                            tab4: false,
                          });
                        }}
                      >
                        Menu
                      </button>
                      <button
                        className={`mr-2 brandon-Bold text-uppercase ${
                          mobileTabs.tab2 ? "active" : null
                        }`}
                        onClick={() => {
                          setMobileTabs({
                            tab1: false,
                            tab2: true,
                            tab3: false,
                            tab4: false,
                          });
                        }}
                      >
                        Restaurant Info
                      </button>
                      <button
                        className={`mr-2 brandon-Bold text-uppercase ${
                          mobileTabs.tab3 ? "active" : null
                        }`}
                        onClick={() => {
                          setMobileTabs({
                            tab1: false,
                            tab2: false,
                            tab3: true,
                            tab4: false,
                          });
                        }}
                      >
                        Gallery
                      </button>
                      {/* <button className={`mr-2 brandon-Bold text-uppercase ${mobileTabs.tab4 ? 'active' : null}`} onClick={() => { setMobileTabs({ tab1: false, tab2: false, tab3: false, tab4: true }) }}>Review</button> */}
                    </div>
                    {mobileTabs.tab1 ? (
                      <div className="ml-auto filter-formlist mt-3">
                        <div className="ml-auto d-flex shortby-btn align-items-center justify-content-between">
                          <form style={{ width: 100 }}>
                            <div className="search-input position-relative d-flex align-items-center">
                              <div className="search-icon">
                                <img src={search_icon} className="img-fluid" alt="searchicon" />
                              </div>
                              <input
                                className="search-inputbox"
                                name="searchData"
                                value={searchData}
                                onChange={(e) => setSearchData(e.target.value)}
                                type="text"
                                alt="searchData"
                                placeholder="Search"
                                style={{ width: 100 }}
                              />
                            </div>
                          </form>

                          <select
                            className="custom-select select-shortby"
                            value={selectData}
                            onChange={(e) => setSelectData(e.target.value)}
                            aria-label="Default select example"
                          >
                            {/* <option value="">Sort By</option> */}
                            <option value="priceh2l">Price High To Low</option>
                            <option value="pricel2h">Price Low To High</option>
                          </select>
                          <button
                            className="filtershort-btn ml-2 p-0 filtershort-lightbtn position-relative"
                            onClick={() => {
                              setFilterModalShow(true);
                            }}
                          >
                            <img
                              width="20"
                              src={filtershorticonpink}
                              className="img-fluid ml-2"
                              alt="filterIcon"
                            />
                            {(allergendata && allergendata.length) +
                              (dietarydata && dietarydata.length) +
                              (lifestyledata && lifestyledata.length) >
                            0 ? (
                              <small className="preference_count">
                                {(allergendata && allergendata.length) +
                                  (dietarydata && dietarydata.length) +
                                  (lifestyledata && lifestyledata.length)}
                              </small>
                            ) : null}
                          </button>
                          <RestaurantMenuAllergyFilterMobilePage
                            show={filterModalShow}
                            onHide={filterModalClose}
                            name="filterData"
                            onChangeData={(value) => {
                              setFilterData1(value);
                              value &&
                                value.allergenInformation !==
                                  filterData.allergenId &&
                                dispatch(
                                  updatePreferenceFilter(
                                    "allergendata",
                                    value &&
                                      value.allergenInformation &&
                                      value.allergenInformation.length > 0
                                      ? value.allergenInformation
                                      : []
                                  )
                                );
                              value &&
                                value.dietaryPreferences !==
                                  filterData.dietaryId &&
                                dispatch(
                                  updatePreferenceFilter(
                                    "dietarydata",
                                    value &&
                                      value.dietaryPreferences &&
                                      value.dietaryPreferences.length > 0
                                      ? value.dietaryPreferences
                                      : []
                                  )
                                );
                              value &&
                                value.lifestyleChoice !==
                                  filterData.lifestyleId &&
                                dispatch(
                                  updatePreferenceFilter(
                                    "lifestyledata",
                                    value &&
                                      value.lifestyleChoice &&
                                      value.lifestyleChoice.length > 0
                                      ? value.lifestyleChoice
                                      : []
                                  )
                                );
                              // dispatch(getUserLoginStatusData(false));
                            }}
                            // onChangeData={(value) => { setFilterData( value); }}
                            value={filterData1}
                          />
                        </div>
                      </div>
                    ) : null}
                  </div>
                  <br></br>
                  {mobileTabs.tab1 ? (
                    <section>
                      {isLoading ? (
                        <RestaurantDiscMobileMenuTabSkeleton />
                      ) : (
                        <React.Fragment>
                          <RestaurantMenuMobileComp
                            lefttabmenu_data={
                              menuTabCategory_Data &&
                              menuTabCategory_Data.menuList
                                ? menuTabCategory_Data.menuList
                                : []
                            }
                            menutab_toppicks={
                              menuTabTopPick_Data &&
                              menuTabTopPick_Data.dishList
                                ? menuTabTopPick_Data.dishList
                                : []
                            }
                            all_menudata={
                              menuTabCategory_Data &&
                              menuTabCategory_Data.menuList
                                ? menuTabCategory_Data.menuList
                                : []
                            }
                          />
                        </React.Fragment>
                      )}
                    </section>
                  ) : mobileTabs.tab2 ? (
                    <section>
                      <RestaurantInfoMobileComponent
                        rest_about={
                          restaurant_data && restaurant_data.about
                            ? restaurant_data.about
                            : ""
                        }
                        rest_address={
                          restaurant_data && restaurant_data.address
                            ? restaurant_data.address
                            : {}
                        }
                        rest_cuisine={
                          restaurant_data &&
                          restaurant_data.restaurantFeatures &&
                          restaurant_data.restaurantFeatures.cuisineTypeList
                            ? restaurant_data.restaurantFeatures.cuisineTypeList
                            : []
                        }
                        rest_other={
                          restaurant_data &&
                          restaurant_data.restaurantFeatures &&
                          restaurant_data.restaurantFeatures
                            .restaurantFeaturesOptionsList
                            ? restaurant_data.restaurantFeatures
                                .restaurantFeaturesOptionsList
                            : []
                        }
                        rest_cost={
                          restaurant_data && restaurant_data.restaurantFeatures
                            ? restaurant_data.restaurantFeatures
                            : {}
                        }
                        rest_website={
                          restaurant_data &&
                          restaurant_data.restaurantDetails &&
                          restaurant_data.restaurantDetails.website
                            ? restaurant_data.restaurantDetails.website
                            : {}
                        }
                        rest_contact={
                          restaurant_data && restaurant_data.info
                            ? restaurant_data.info
                            : {}
                        }
                        rest_booking={
                          restaurant_data &&
                          restaurant_data.restaurantDetails &&
                          restaurant_data.restaurantDetails.bookings
                            ? restaurant_data.restaurantDetails.bookings
                            : {}
                        }
                        rest_social={
                          restaurant_data &&
                          restaurant_data.restaurantDetails &&
                          restaurant_data.restaurantDetails.socialMedia
                            ? restaurant_data.restaurantDetails.socialMedia
                            : {}
                        }
                        rest_applies={
                          restaurant_data &&
                          restaurant_data.restaurantFeatures &&
                          restaurant_data.restaurantFeatures.appliesOfRestaurant
                            ? restaurant_data.restaurantFeatures
                                .appliesOfRestaurant
                            : []
                        }
                        restaurant_time={
                          restaurant_data &&
                          restaurant_data.restaurantDetails &&
                          restaurant_data.restaurantDetails.openingTimings
                            ? restaurant_data.restaurantDetails.openingTimings
                            : {}
                        }
                      />
                    </section>
                  ) : mobileTabs.tab3 ? (
                    <section>
                      <RestaurantGalleeryMobileComp
                        food={
                          restaurant_data &&
                          restaurant_data.restaurant_galleries &&
                          restaurant_data.restaurant_galleries.food
                            ? restaurant_data.restaurant_galleries.food
                            : []
                        }
                        ambience={
                          restaurant_data &&
                          restaurant_data.restaurant_galleries &&
                          restaurant_data.restaurant_galleries.ambience
                            ? restaurant_data.restaurant_galleries.ambience
                            : []
                        }
                      />
                    </section>
                  ) : (
                    <section>
                      {" "}
                      <RestaurantReviewMobileComp />{" "}
                    </section>
                  )}
                </div>
              </div>
            </React.Fragment>
          )}
        </div>
      </section>
      {/* </div> */}
      {/* </section> */}
    </>
  );
};

export default RestaurantDiscMobilePage;
