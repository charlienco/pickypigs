import React, { useEffect } from "react";
import DiscDescriptionMobileComp from "../../MobileComponents/DiscDescriptionMobileComp/DiscDescriptionMobileComp";
import left_arrow from "../../../assets/images/left-arrow.svg";
import allergenicon from "../../../assets/images/dishinfo_img/allergen-icon.svg";
import Ingredientsicon from "../../../assets/images/dishinfo_img/Ingredients-icon.svg";
import nutritionFactsicon from "../../../assets/images/dishinfo_img/NutritionFacts-icon.svg";

import "./RestaurantDiscInfoMobilePage.scss";
import AllergyInformationdMobileModal from "../../MobileComponents/AllergyInformationdMobileModal/AllergyInformationdMobileModal";
import CaloriesInformationMobileModal from "../../MobileComponents/CaloriesInformationMobileModal/CaloriesInformationMobileModal";
import IngredientsDetailMobileModal from "../../MobileComponents/IngredientsDetailMobileModal/IngredientsDetailMobileModal";
import { useHistory, useParams } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { getSelectedDiscInfoData } from "../../../redux/actions/dishAction";
import CookingDetailMobileModal from "../../MobileComponents/CookingDetailMobileModal/CookingDetailMobileModal";
import RestaurantDiscInfoMobilePageSkeleton from "../../Skeleton/RestaurantDiscInfoMobilePageSkeleton/RestaurantDiscInfoMobilePageSkeleton";
import cookingicon from "../../../assets/images/dishinfo_img/cooking.svg";

const RestaurantDiscInfoMobilePage = () => {
  const params = useParams();
  const dishInfoId = params.dishId;
  const dispatch = useDispatch();
  const history = useHistory();

  useEffect(() => {
    dispatch(getSelectedDiscInfoData(dishInfoId, history));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [dispatch, dishInfoId]);

  let selectedDiscInfo_data = useSelector((state) => {
    return state.dishes.selectedDiscInfo_Data;
  });

  // console.log("selectedDiscInfo_data =>", selectedDiscInfo_data);
  let myLoading = useSelector((state) => {
    return state.dishes.isDishLoading;
  });
  const [allergyModalShow, setAllergyModalShow] = React.useState(false);
  const [calloriesModalShow, setCalloriesModalShow] = React.useState(false);
  const [ingredientModalShow, setIngredientModalShow] = React.useState(false);
  const [cookingModalShow, setCookingModalShow] = React.useState(false);

  const myAllergydata =
    selectedDiscInfo_data && selectedDiscInfo_data.allergensDetail
      ? selectedDiscInfo_data.allergensDetail
      : [];

  return (
    <>
      <section>
        <div>
          {/* className="container restaurantDiscInfoMobilePage-container" */}
          {myLoading ? (
            <React.Fragment>
              <RestaurantDiscInfoMobilePageSkeleton />
            </React.Fragment>
          ) : (
            <React.Fragment>
              <DiscDescriptionMobileComp
                restaurantId={
                  selectedDiscInfo_data && selectedDiscInfo_data.restaurantId
                }
                restaurantName={
                  selectedDiscInfo_data && selectedDiscInfo_data.restaurantName
                }
                itemimage={
                  selectedDiscInfo_data && selectedDiscInfo_data.image
                    ? selectedDiscInfo_data.image
                    : ""
                }
                name={
                  selectedDiscInfo_data && selectedDiscInfo_data.name
                    ? selectedDiscInfo_data.name
                    : "Nmae Not Available"
                }
                price={
                  selectedDiscInfo_data && selectedDiscInfo_data.price
                    ? selectedDiscInfo_data.price
                    : "Price Not Available"
                }
                priceunit={
                  selectedDiscInfo_data && selectedDiscInfo_data.priceUnit
                    ? selectedDiscInfo_data.priceUnit
                    : "$"
                }
                description={
                  selectedDiscInfo_data && selectedDiscInfo_data.description
                    ? selectedDiscInfo_data.description
                    : "Dish Description Not Available"
                }
                allergydetail={
                  selectedDiscInfo_data && selectedDiscInfo_data.allergensDetail
                    ? selectedDiscInfo_data.allergensDetail
                    : []
                }
                diateryDetail={
                  selectedDiscInfo_data && selectedDiscInfo_data.dietariesDetail
                    ? selectedDiscInfo_data.dietariesDetail
                    : []
                }
                lifestyleDetail={
                  selectedDiscInfo_data &&
                  selectedDiscInfo_data.lifestylesDetail
                    ? selectedDiscInfo_data.lifestylesDetail
                    : []
                }
                cookingDetail={
                  selectedDiscInfo_data && selectedDiscInfo_data.cooking_methods
                    ? selectedDiscInfo_data.cooking_methods
                    : []
                }
                dish_new_tag={
                  selectedDiscInfo_data && selectedDiscInfo_data.new
                    ? selectedDiscInfo_data.new
                    : false
                }
              />
              <div className="col-sm-12">
                <div className="row">
                  <div className="col-sm-12">
                    {/* <p className="txt-lightgray f-14">Serving Size : 1 Meal (454 gm)</p> */}

                    <div className="row">
                      <div className="col-12 mb-3">
                        <div
                          role="button"
                          className="rs-infoblock"
                          onClick={() => setAllergyModalShow(true)}
                        >
                          <div className="d-flex justify-content-between align-items-center flex-nowrap">
                            <div className="d-flex">
                              <img
                                src={allergenicon}
                                className="img-fluid rs-allergyInfomodalbtn-icon"
                                alt="icon"
                                loading="lazy"
                              />
                              <h5 className="brandon-Medium mb-0">
                                Allergy Information
                              </h5>
                            </div>
                            <div className="">
                              <img
                                src={left_arrow}
                                className="img-fluid"
                                alt="icon"
                                loading="lazy"
                              />
                            </div>
                          </div>
                          <p className="mb-0 text-left brandon-Medium mt-2 f-14">
                            Contains&nbsp;
                            {myAllergydata && myAllergydata.length > 0 ? (
                              <React.Fragment>
                                {myAllergydata &&
                                  myAllergydata
                                    .slice(0, 2)
                                    .map((data, index) => {
                                      return (
                                        <React.Fragment key={index}>
                                          {index ? ", " : null}
                                          {data.name ? data.name : null}
                                        </React.Fragment>
                                      );
                                    })}
                                {myAllergydata && myAllergydata.length > 3
                                  ? ` and ${
                                      myAllergydata && myAllergydata.length - 2
                                    } More`
                                  : null}
                              </React.Fragment>
                            ) : (
                              <React.Fragment>
                                <span>No Allergies</span>
                              </React.Fragment>
                            )}
                          </p>
                        </div>
                        <AllergyInformationdMobileModal
                          show={allergyModalShow}
                          onHide={() => setAllergyModalShow(false)}
                          allergydata={
                            selectedDiscInfo_data &&
                            selectedDiscInfo_data.allergensDetail
                              ? selectedDiscInfo_data.allergensDetail
                              : []
                          }
                        />
                      </div>
                    </div>

                    <div className="row">
                      <div className="col-12 mb-3">
                        <div
                          role="button"
                          className="rs-infoblock"
                          onClick={() => setIngredientModalShow(true)}
                        >
                          <div className="d-flex justify-content-between align-items-center flex-nowrap">
                            <div className="d-flex">
                              <img
                                src={Ingredientsicon}
                                className="img-fluid rs-allergyInfomodalbtn-icon"
                                alt="icon"
                                loading="lazy"
                              />
                              <h5 className="brandon-Medium mb-0">
                                Ingredient
                              </h5>
                            </div>
                            <div>
                              <img
                                src={left_arrow}
                                className="img-fluid"
                                alt="icon"
                                loading="lazy"
                              />
                            </div>
                          </div>
                        </div>
                        <IngredientsDetailMobileModal
                          show={ingredientModalShow}
                          onHide={() => setIngredientModalShow(false)}
                          ingredient={
                            selectedDiscInfo_data &&
                            selectedDiscInfo_data.ingredientSection &&
                            selectedDiscInfo_data.ingredientSection
                              .dish_ingredients
                              ? selectedDiscInfo_data.ingredientSection
                                  .dish_ingredients
                              : []
                          }
                        />
                      </div>
                    </div>

                    <div className="row">
                      <div className="col-12 mb-3">
                        <div
                          role="button"
                          className="rs-infoblock"
                          onClick={() => setCookingModalShow(true)}
                        >
                          <div className="d-flex justify-content-between align-items-center flex-nowrap">
                            <div className="d-flex">
                              <img
                                src={cookingicon}
                                className="img-fluid rs-allergyInfomodalbtn-icon"
                                alt="icon"
                                loading="lazy"
                              />
                              <h5 className="brandon-Medium mb-0">
                                Cooking Method
                              </h5>
                            </div>
                            <div>
                              <img
                                src={left_arrow}
                                className="img-fluid"
                                alt="icon"
                                loading="lazy"
                              />
                            </div>
                          </div>
                        </div>
                        <CookingDetailMobileModal
                          show={cookingModalShow}
                          onHide={() => setCookingModalShow(false)}
                          cookingdata={
                            selectedDiscInfo_data &&
                            selectedDiscInfo_data.cooking_methods
                              ? selectedDiscInfo_data.cooking_methods
                              : []
                          }
                        />
                      </div>
                    </div>

                    <div className="row">
                      <div className="col-12 mb-3">
                        <div
                          role="button"
                          className="rs-infoblock"
                          onClick={() => setCalloriesModalShow(true)}
                        >
                          <p className="brandon-Medium">Nutritation Facts</p>
                          <div className="d-flex justify-content-between align-items-center flex-nowrap">
                            <div className="d-flex">
                              <img
                                src={nutritionFactsicon}
                                className="img-fluid rs-allergyInfomodalbtn-icon"
                                style={{ height: 24 }}
                                alt="icon"
                                loading="lazy"
                              />
                              <h5 className="brandon-Medium mb-0">
                                Calories and Macros
                              </h5>
                            </div>
                            {/* <div>
                              <h5 className="brandon-Medium mb-0">507</h5>
                            </div> */}
                          </div>
                          <div
                            className="mt-3 mb-3"
                            style={{ border: "1px dashed rgb(217, 217, 217)" }}
                          ></div>
                          <div className="d-flex justify-content-between align-items-center flex-nowrap">
                            <div className="d-flex">
                              <p className="mb-0 text-left brandon-Medium f-14">
                                View additional details
                              </p>
                            </div>
                            <div>
                              <img
                                src={left_arrow}
                                className="img-fluid"
                                alt="icon"
                                loading="lazy"
                              />
                            </div>
                          </div>
                        </div>
                        <CaloriesInformationMobileModal
                          show={calloriesModalShow}
                          onHide={() => setCalloriesModalShow(false)}
                          caloriesandmacrosdetail={
                            selectedDiscInfo_data &&
                            selectedDiscInfo_data.caloriesandmacrosDetail
                              ? selectedDiscInfo_data.caloriesandmacrosDetail
                              : {}
                          }
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </React.Fragment>
          )}
        </div>
      </section>
    </>
  );
};

export default RestaurantDiscInfoMobilePage;
