import React from 'react'
import "./EmailverificationSuccessMobileScreen.scss"
import { useSelector} from 'react-redux';

import Tick from '../../../assets/images/check.svg' 




const EmailverificationSuccessMobileScreen = (props) => {

    let verification_Data=useSelector((state)=>{
        return state.emailVerification
    });
    let {emailVerification_Message}=verification_Data;

    return (
        
        <div className="EmailverificationSuccessMobileScreen-comp">
            <div className="d-flex flex-column justify-content-center align-items-center" style={{height:250}}>
                <img src={Tick} className="img-fluid pb-4" width="50px" loading="lazy" alt="icon"/>
                <p className="brandon-Bold" >{emailVerification_Message&&emailVerification_Message.message?emailVerification_Message.message:''}</p>
                <p className="f-15 "><span>Please Login with Verified Email</span></p>
                <button className="pinkline-btn signup-btn btn w-50 text-uppercase border-radius-25"  onClick={()=>{props.gotoLogin()}}>
                                                Login
                </button>   
            </div>
        </div>
        
    )
}

export default EmailverificationSuccessMobileScreen;
