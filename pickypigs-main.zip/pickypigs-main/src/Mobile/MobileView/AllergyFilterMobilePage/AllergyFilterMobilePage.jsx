import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import {
  getAllAllergyData,
  getAllDietaryData,
  getAllLifestyleData,
  getAllRestaurantFeaturesData,
} from "../../../redux/actions/allergyAction";
import * as Yup from "yup";
import { Formik, Field, Form } from "formik";
import "./AllergyFilterMobilePage.scss";
import { SERVER_URL } from "../../../shared/constant";
import { Modal } from "react-bootstrap";
import {
  updatePreferenceFilter,
  updateAllPreferenceFilter,
} from "../../../redux/actions/globalPreferenceFilterAction";
import { getUserLoginStatusData } from "../../../redux/actions/generalActions";
import Slider from "rc-slider";
import "rc-slider/assets/index.css";
const createSliderWithTooltip = Slider.createSliderWithTooltip;
const SliderWithTooltip = createSliderWithTooltip(Slider);

const AllergyFilterMobilePage = (props) => {
  const dispatch = useDispatch();
  const [reset, setReset] = useState(false);
  const [checkValue, setCheckValue] = useState(false);
  const [filterData, setFilterData] = useState({
    allergenInformation: [],
    dietaryPreferences: [],
    lifestyleChoice: [],
    restaurantFeatures: [],
    toggle: false,
    distance: 0,
  });

  useEffect(() => {
    dispatch(getAllAllergyData());
    dispatch(getAllDietaryData());
    dispatch(getAllLifestyleData());
    dispatch(getAllRestaurantFeaturesData());
  }, [dispatch]);

  useEffect(() => {
    if (reset) {
      setReset(false);
    }
    // eslint-disable-next-line
  }, [props.show]);

  let allAllergy_data = useSelector((state) => {
    return state.allergy;
  });
  let { allergy_Data, dietary_Data, lifestyle_Data, restaurantFeatures_Data } =
    allAllergy_data;

  const preferenceData = useSelector((state) => {
    return state.myPreference.selectedPreference;
  });
  let {
    allergendata,
    dietarydata,
    lifestyledata,
    featuredata,
    nearby,
    distance,
  } = preferenceData;

  let User_loginstatus_Data = useSelector((state) => {
    return state.general.userLoginStatus_Data;
  });

  useEffect(() => {
    setCheckValue(User_loginstatus_Data);
  }, [props.show, User_loginstatus_Data]);

  useEffect(() => {
    if (User_loginstatus_Data) {
    }
    setFilterData({
      ...filterData,
      allergenInformation: allergendata ? allergendata : [],
      dietaryPreferences: dietarydata ? dietarydata : [],
      lifestyleChoice: lifestyledata ? lifestyledata : [],
      restaurantFeatures: featuredata ? featuredata : [],
      toggle: nearby,
      distance: distance ? distance : 0,
    });
    // eslint-disable-next-line
  }, [preferenceData]);

  // const initialValues = {
  //     allergenInformation: allergendata ? allergendata : [],
  //     dietaryPreferences: dietarydata ? dietarydata : [],
  //     lifestyleChoice: lifestyledata ? lifestyledata : [],
  //     restaurantFeatures: featuredata ? featuredata : [],
  //     toggle: nearby ,
  //     distance: distance ? distance : 0,
  // }
  const initialValues2 = {
    allergenInformation: [],
    dietaryPreferences: [],
    lifestyleChoice: [],
    restaurantFeatures: [],
    toggle: true,
    distance: 0,
  };

  const validationSchema = Yup.object().shape({
    // allergenId: Yup.array().required('Please Select Allergen'),
    // dietaryId: Yup.array().required('Please Select  Dietary'),
    // lifestyleId: Yup.array().required('Please Select Lifestyle'),
    // featuresId: Yup.array().required('Please Select Restaurant Feature'),
    // toggle: Yup.boolean().oneOf([true, false]),
    // distance: Yup.string().required('distance is required'),
  });

  const handleAlergy = (e, alergy, setFieldValue) => {
    setCheckValue(false);
    e.preventDefault();
    if (alergy.indexOf(e.target.id) !== -1) {
      var Index = alergy.indexOf(e.target.id);
      if (Index > -1) {
        // setAlergy(alergy.slice(0,Index).concat(alergy.slice(Index+ 1, alergy.length)));
        setFieldValue(
          "allergenInformation",
          alergy.filter((myallergy) => myallergy !== e.target.id)
        );
        setFilterData({
          ...filterData,
          allergenInformation: alergy.filter(
            (myallergy) => myallergy !== e.target.id
          ),
        });
      }
    } else {
      setFieldValue("allergenInformation", [...alergy, e.target.id]);
      setFilterData({
        ...filterData,
        allergenInformation: [...alergy, e.target.id],
      });
    }
  };

  const handleDietaryPreference = (e, dietary, setFieldValue) => {
    setCheckValue(false);
    e.preventDefault();
    if (dietary.indexOf(e.target.id) !== -1) {
      var Index = dietary.indexOf(e.target.id);
      if (Index > -1) {
        setFieldValue(
          "dietaryPreferences",
          dietary.filter((mydietary) => mydietary !== e.target.id)
        );
        setFilterData({
          ...filterData,
          dietaryPreferences: dietary.filter(
            (mydietary) => mydietary !== e.target.id
          ),
        });
      }
    } else {
      setFieldValue("dietaryPreferences", [...dietary, e.target.id]);
      setFilterData({
        ...filterData,
        dietaryPreferences: [...dietary, e.target.id],
      });
    }
  };

  const handleLifestyle = (e, lifestyle, setFieldValue) => {
    setCheckValue(false);
    e.preventDefault();
    if (lifestyle.indexOf(e.target.id) !== -1) {
      var Index = lifestyle.indexOf(e.target.id);
      if (Index > -1) {
        setFieldValue(
          "lifestyleChoice",
          lifestyle.filter((mylifestyle) => mylifestyle !== e.target.id)
        );
        setFilterData({
          ...filterData,
          lifestyleChoice: lifestyle.filter(
            (mylifestyle) => mylifestyle !== e.target.id
          ),
        });
      }
    } else {
      setFieldValue("lifestyleChoice", [...lifestyle, e.target.id]);
      setFilterData({
        ...filterData,
        lifestyleChoice: [...lifestyle, e.target.id],
      });
    }
  };

  const handleRestaurant = (e, restaurant, setFieldValue) => {
    setCheckValue(false);
    e.preventDefault();
    if (restaurant.indexOf(e.target.id) !== -1) {
      var Index = restaurant.indexOf(e.target.id);
      if (Index > -1) {
        setFieldValue(
          "restaurantFeatures",
          restaurant.filter((myrestaurant) => myrestaurant !== e.target.id)
        );
        setFilterData({
          ...filterData,
          restaurantFeatures: restaurant.filter(
            (myrestaurant) => myrestaurant !== e.target.id
          ),
        });
      }
    } else {
      setFieldValue("restaurantFeatures", [...restaurant, e.target.id]);
      setFilterData({
        ...filterData,
        restaurantFeatures: [...restaurant, e.target.id],
      });
    }
  };

  let User_Data = useSelector((state) => {
    return state.userProfile;
  });
  let { userProfile_Data = {} } = User_Data;

  const token = localStorage.getItem("access_token");

  useEffect(() => {
    if (User_loginstatus_Data) {
      if (
        userProfile_Data &&
        userProfile_Data.userDetail &&
        userProfile_Data.userDetail.myPreferences &&
        userProfile_Data.userDetail.myPreferences.allergenInformation
      ) {
        dispatch(
          updatePreferenceFilter(
            "allergendata",
            userProfile_Data &&
              userProfile_Data.userDetail &&
              userProfile_Data.userDetail.myPreferences &&
              userProfile_Data.userDetail.myPreferences.allergenInformation
          )
        );
      }
      if (
        userProfile_Data &&
        userProfile_Data.userDetail &&
        userProfile_Data.userDetail.myPreferences &&
        userProfile_Data.userDetail.myPreferences.dietaryPreferences
      ) {
        dispatch(
          updatePreferenceFilter(
            "dietarydata",
            userProfile_Data &&
              userProfile_Data.userDetail &&
              userProfile_Data.userDetail.myPreferences &&
              userProfile_Data.userDetail.myPreferences.dietaryPreferences
          )
        );
      }
      if (
        userProfile_Data &&
        userProfile_Data.userDetail &&
        userProfile_Data.userDetail.myPreferences &&
        userProfile_Data.userDetail.myPreferences.lifestyleChoice
      ) {
        dispatch(
          updatePreferenceFilter(
            "lifestyledata",
            userProfile_Data &&
              userProfile_Data.userDetail &&
              userProfile_Data.userDetail.myPreferences &&
              userProfile_Data.userDetail.myPreferences.lifestyleChoice
          )
        );
      }
      if (
        userProfile_Data &&
        userProfile_Data.userDetail &&
        userProfile_Data.userDetail.myPreferences &&
        userProfile_Data.userDetail.myPreferences.restaurantFeatures
      ) {
        dispatch(
          updatePreferenceFilter(
            "featuredata",
            userProfile_Data &&
              userProfile_Data.userDetail &&
              userProfile_Data.userDetail.myPreferences &&
              userProfile_Data.userDetail.myPreferences.restaurantFeatures
          )
        );
      }
    }
  }, [dispatch, User_loginstatus_Data, userProfile_Data]);

  // const initialValues3 = {
  //     allergenInformation: userProfile_Data && userProfile_Data.userDetail && userProfile_Data.userDetail.myPreferences && userProfile_Data.userDetail.myPreferences.allergenInformation ? userProfile_Data && userProfile_Data.userDetail && userProfile_Data.userDetail.myPreferences && userProfile_Data.userDetail.myPreferences.allergenInformation : [],
  //     dietaryPreferences: userProfile_Data && userProfile_Data.userDetail && userProfile_Data.userDetail.myPreferences && userProfile_Data.userDetail.myPreferences.dietaryPreferences ? userProfile_Data && userProfile_Data.userDetail && userProfile_Data.userDetail.myPreferences && userProfile_Data.userDetail.myPreferences.dietaryPreferences : [],
  //     lifestyleChoice: userProfile_Data && userProfile_Data.userDetail && userProfile_Data.userDetail.myPreferences && userProfile_Data.userDetail.myPreferences.lifestyleChoice ? userProfile_Data && userProfile_Data.userDetail && userProfile_Data.userDetail.myPreferences && userProfile_Data.userDetail.myPreferences.lifestyleChoice : [],
  //     restaurantFeatures: userProfile_Data && userProfile_Data.userDetail && userProfile_Data.userDetail.myPreferences && userProfile_Data.userDetail.myPreferences.restaurantFeatures ? userProfile_Data && userProfile_Data.userDetail && userProfile_Data.userDetail.myPreferences && userProfile_Data.userDetail.myPreferences.restaurantFeatures : [],
  //     toggle: true,
  //     distance: 0,
  // }

  const handleChangeInitialData = (status) => {
    if (status) {
      setFilterData({
        ...filterData,
        allergenInformation:
          userProfile_Data &&
          userProfile_Data.userDetail &&
          userProfile_Data.userDetail.myPreferences &&
          userProfile_Data.userDetail.myPreferences.allergenInformation
            ? userProfile_Data &&
              userProfile_Data.userDetail &&
              userProfile_Data.userDetail.myPreferences &&
              userProfile_Data.userDetail.myPreferences.allergenInformation
            : [],
        dietaryPreferences:
          userProfile_Data &&
          userProfile_Data.userDetail &&
          userProfile_Data.userDetail.myPreferences &&
          userProfile_Data.userDetail.myPreferences.dietaryPreferences
            ? userProfile_Data &&
              userProfile_Data.userDetail &&
              userProfile_Data.userDetail.myPreferences &&
              userProfile_Data.userDetail.myPreferences.dietaryPreferences
            : [],
        lifestyleChoice:
          userProfile_Data &&
          userProfile_Data.userDetail &&
          userProfile_Data.userDetail.myPreferences &&
          userProfile_Data.userDetail.myPreferences.lifestyleChoice
            ? userProfile_Data &&
              userProfile_Data.userDetail &&
              userProfile_Data.userDetail.myPreferences &&
              userProfile_Data.userDetail.myPreferences.lifestyleChoice
            : [],
        restaurantFeatures:
          userProfile_Data &&
          userProfile_Data.userDetail &&
          userProfile_Data.userDetail.myPreferences &&
          userProfile_Data.userDetail.myPreferences.restaurantFeatures
            ? userProfile_Data &&
              userProfile_Data.userDetail &&
              userProfile_Data.userDetail.myPreferences &&
              userProfile_Data.userDetail.myPreferences.restaurantFeatures
            : [],
        toggle: true,
        distance: 0,
      });
    } else {
      setFilterData({
        ...filterData,
        allergenInformation: allergendata ? allergendata : [],
        dietaryPreferences: dietarydata ? dietarydata : [],
        lifestyleChoice: lifestyledata ? lifestyledata : [],
        restaurantFeatures: featuredata ? featuredata : [],
        toggle: nearby,
        distance: distance ? distance : 0,
      });
    }
  };

  const onSubmit = (fields) => {
    dispatch(
      updateAllPreferenceFilter({
        allergendata: fields.allergenInformation,
        dietarydata: fields.dietaryPreferences,
        lifestyledata: fields.lifestyleChoice,
        featuredata: fields.restaurantFeatures,
        nearby: fields.toggle,
        distance: fields.distance,
      })
    );
    props.onHide();
    dispatch(getUserLoginStatusData(checkValue));
  };

  return (
    <>
      <section>
        <Modal {...props} className="allergyfiltermobilepage-modal bg-white">
          {/* <Modal.Header closeButton><Modal.Title id="contained-modal-title-vcenter"> Modal heading</Modal.Title></Modal.Header> */}
          <Modal.Body>
            <section className="allergyfiltermobilepage-comp">
              <div className="d-flex justify-content-between align-items-center">
                <div className="filter-title">
                  {/* <button className="filtermodal-closebtn fw-600 brandon-Medium pl-0 pr-0 mr-3" onClick={()=>{props.onHide();setReset(false)}}>x</button> */}
                  <h4 className="brandon-Bold mb-0">Filters </h4>
                </div>
                {token &&
                userProfile_Data &&
                userProfile_Data.role === "user" ? (
                  <div className="accordion-list__item">
                    <div className="form-check custom-control custom-checkbox filter-checkbox">
                      <input
                        type="checkbox"
                        id="sssss"
                        className="form-check-input custom-control-input"
                        checked={checkValue}
                        onClick={(e) => {
                          setCheckValue(e.target.checked);
                          setReset(false);
                          handleChangeInitialData(e.target.checked);
                        }}
                      />
                      <label
                        className="form-check-label custom-control-label f-14 pt-1"
                        htmlFor="sssss"
                      >
                        Show my preference{" "}
                      </label>
                    </div>
                  </div>
                ) : null}
              </div>

              <Formik
                enableReinitialize={true}
                initialValues={!reset ? filterData : initialValues2}
                validationSchema={validationSchema}
                onSubmit={onSubmit}
              >
                {({ values, resetForm, setFieldValue }) => (
                  <Form>
                    <div className="d-flex justify-content-end">
                      <button
                        className="clearall-btn text-right"
                        type="reset"
                        onClick={() => {
                          setReset(true);
                          setCheckValue(false);
                        }}
                      >
                        Clear All{" "}
                      </button>
                    </div>
                    <div>{/* {JSON.stringify(values)} */}</div>
                    <div className="main-accordion-wrapper ">
                      <div
                        className="accordion accordion-main "
                        id="accordionExample"
                      >
                        <div className="accordion-item">
                          <div id="headingOne">
                            <div
                              className="mb-3 mt-3 pt-1 pb-1 w-100 accordion-button d-flex justify-content-between align-items-center accordion-header position-relative"
                              type="button"
                              data-bs-toggle="collapse"
                              data-bs-target="#collapseOne"
                              aria-expanded="true"
                              aria-controls="collapseOne"
                            >
                              <div className="accordion-title">
                                <h5 className="brandon-Bold mb-0">Allergens</h5>
                              </div>
                              <div className="expand-button position-absolute top-0 right-0"></div>
                            </div>
                          </div>
                          <div
                            id="collapseOne"
                            className="accordion-collapse collapse show"
                            aria-labelledby="headingOne"
                            data-bs-parent="#accordionExample1"
                          >
                            <div className="accordion-body">
                              <section className="accordion-list__item ">
                                <div className="row">
                                  <div className="col-sm-12">
                                    {/* {JSON.stringify(values.allergenInformation)} */}
                                    <div className="allergen-btn-wrapper d-flex align-items-start flex-wrap">
                                      {allergy_Data &&
                                        allergy_Data.data &&
                                        allergy_Data.data.map((data, index) => {
                                          return (
                                            <React.Fragment key={index}>
                                              <button
                                                id={data._id}
                                                onClick={(e) => {
                                                  handleAlergy(
                                                    e,
                                                    values.allergenInformation,
                                                    setFieldValue
                                                  );
                                                }}
                                                type="button"
                                                className={`allergen-btn d-flex flex-column justify-content-center mr-3 mb-3 p-0 align-items-center ${
                                                  values.allergenInformation &&
                                                  values.allergenInformation.indexOf(
                                                    data._id
                                                  ) !== -1 &&
                                                  "active"
                                                }`}
                                              >
                                                <div
                                                  id={data._id}
                                                  className="allergen-icon d-flex align-items-center justify-content-center mb-2"
                                                  onClick={(e) => {
                                                    handleAlergy(
                                                      e,
                                                      values.allergenInformation,
                                                      setFieldValue
                                                    );
                                                  }}
                                                >
                                                  <img
                                                    id={data._id}
                                                    src={`${SERVER_URL}/${data.image}`}
                                                    className="img-fluid"
                                                    onClick={(e) => {
                                                      handleAlergy(
                                                        e,
                                                        values.allergenInformation,
                                                        setFieldValue
                                                      );
                                                    }}
                                                    alt="img"
                                                    loading="lazy"
                                                  />
                                                </div>
                                                <span
                                                  id={data._id}
                                                  className="mb-0 f-12 txt-lightgray"
                                                  onClick={(e) => {
                                                    handleAlergy(
                                                      e,
                                                      values.allergenInformation,
                                                      setFieldValue
                                                    );
                                                  }}
                                                >
                                                  {data.name}
                                                </span>
                                              </button>
                                            </React.Fragment>
                                          );
                                        })}
                                    </div>
                                  </div>
                                </div>
                              </section>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="dotted_border"></div>
                    <div className="main-accordion-wrapper ">
                      <div
                        className="accordion accordion-main "
                        id="accordionExample2"
                      >
                        <div className="accordion-item">
                          <div
                            className="mb-3 mt-3 pt-1 pb-1 w-100 accordion-button d-flex justify-content-between align-items-center accordion-header position-relative"
                            id="headingTwo"
                          >
                            <div
                              className="w-100 accordion-button"
                              type="button"
                              data-bs-toggle="collapse"
                              data-bs-target="#collapseTwo"
                              aria-expanded="true"
                              aria-controls="collapseTwo"
                            >
                              <div className="accordion-title">
                                <h5 className="brandon-Bold mb-0">
                                  Dietary preferences
                                </h5>
                              </div>
                              <div className="expand-button position-absolute top-0 right-0"></div>
                            </div>
                          </div>
                          <div
                            id="collapseTwo"
                            className="accordion-collapse collapse show"
                            aria-labelledby="headingTwo"
                            data-bs-parent="#accordionExample2"
                          >
                            <div className="accordion-body">
                              <section className="accordion-list__item ">
                                <div className="row">
                                  <div className="col-sm-12">
                                    <div className="allergen-btn-wrapper d-flex align-items-start flex-wrap">
                                      {dietary_Data &&
                                        dietary_Data.data &&
                                        dietary_Data.data.map((data, index) => {
                                          return (
                                            <React.Fragment key={index}>
                                              <button
                                                id={data._id}
                                                type="button"
                                                onClick={(e) => {
                                                  handleDietaryPreference(
                                                    e,
                                                    values.dietaryPreferences,
                                                    setFieldValue
                                                  );
                                                }}
                                                className={`allergen-btn d-flex flex-column justify-content-center mr-3 mb-3 p-0 align-items-center ${
                                                  values.dietaryPreferences &&
                                                  values.dietaryPreferences.indexOf(
                                                    data._id
                                                  ) !== -1 &&
                                                  "active"
                                                }`}
                                              >
                                                <div
                                                  id={data._id}
                                                  className="allergen-icon d-flex align-items-center justify-content-center mb-2"
                                                  onClick={(e) => {
                                                    handleDietaryPreference(
                                                      e,
                                                      values.dietaryPreferences,
                                                      setFieldValue
                                                    );
                                                  }}
                                                >
                                                  <img
                                                    id={data._id}
                                                    src={`${SERVER_URL}/${data.image}`}
                                                    className="img-fluid"
                                                    onClick={(e) => {
                                                      handleDietaryPreference(
                                                        e,
                                                        values.dietaryPreferences,
                                                        setFieldValue
                                                      );
                                                    }}
                                                    alt="img"
                                                    loading="lazy"
                                                  />
                                                </div>
                                                <span
                                                  id={data._id}
                                                  className="mb-0 f-12 txt-lightgray"
                                                  onClick={(e) => {
                                                    handleDietaryPreference(
                                                      e,
                                                      values.dietaryPreferences,
                                                      setFieldValue
                                                    );
                                                  }}
                                                >
                                                  {data.name}
                                                </span>
                                              </button>
                                            </React.Fragment>
                                          );
                                        })}
                                    </div>
                                  </div>
                                </div>
                              </section>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="dotted_border"></div>
                    <div className="main-accordion-wrapper ">
                      <div
                        className="accordion accordion-main "
                        id="accordionExample3"
                      >
                        <div className="accordion-item">
                          <div
                            className="mb-3 mt-3 pt-1 pb-1 w-100 accordion-button d-flex justify-content-between align-items-center accordion-header position-relative"
                            id="headingThree"
                          >
                            <div
                              className="w-100 accordion-button"
                              type="button"
                              data-bs-toggle="collapse"
                              data-bs-target="#collapseThree"
                              aria-expanded="true"
                              aria-controls="collapseThree"
                            >
                              <div className="accordion-title">
                                <h5 className="brandon-Bold mb-0">
                                  Lifestyle choice
                                </h5>
                              </div>
                              <div className="expand-button position-absolute top-0 right-0"></div>
                            </div>
                          </div>
                          <div
                            id="collapseThree"
                            className="accordion-collapse collapse show"
                            aria-labelledby="headingThree"
                            data-bs-parent="#accordionExample3"
                          >
                            <div className="accordion-body">
                              <section className="accordion-list__item ">
                                <div className="row">
                                  <div className="col-sm-12">
                                    <div className="allergen-btn-wrapper d-flex align-items-start flex-wrap">
                                      {lifestyle_Data &&
                                        lifestyle_Data.data &&
                                        lifestyle_Data.data.map(
                                          (data, index) => {
                                            return (
                                              <React.Fragment key={index}>
                                                <button
                                                  id={data._id}
                                                  type="button"
                                                  onClick={(e) => {
                                                    handleLifestyle(
                                                      e,
                                                      values.lifestyleChoice,
                                                      setFieldValue
                                                    );
                                                  }}
                                                  className={`allergen-btn d-flex flex-column justify-content-center mr-3 mb-3 p-0 align-items-center ${
                                                    values.lifestyleChoice &&
                                                    values.lifestyleChoice.indexOf(
                                                      data._id
                                                    ) !== -1 &&
                                                    "active"
                                                  }`}
                                                >
                                                   <div
                                                  id={data._id}
                                                  className="allergen-icon d-flex align-items-center justify-content-center mb-2"
                                                  onClick={(e) => {
                                                    handleLifestyle(
                                                      e,
                                                      values.lifestyleChoice,
                                                      setFieldValue
                                                    );
                                                  }}
                                                >
                                                  <img
                                                    id={data._id}
                                                    src={`${SERVER_URL}/${data.image}`}
                                                    className="img-fluid"
                                                    onClick={(e) => {
                                                      handleLifestyle(
                                                        e,
                                                        values.lifestyleChoice,
                                                        setFieldValue
                                                      );
                                                    }}
                                                    alt="img"
                                                    loading="lazy"
                                                  />
                                                </div>
                                                <span
                                                  id={data._id}
                                                  className="mb-0 f-12 txt-lightgray"
                                                  onClick={(e) => {
                                                    handleLifestyle(
                                                      e,
                                                      values.lifestyleChoice,
                                                      setFieldValue
                                                    );
                                                  }}
                                                >
                                                  {data.name}
                                                </span>
                                                </button>
                                              </React.Fragment>
                                            );
                                          }
                                        )}
                                    </div>
                                  </div>
                                </div>
                              </section>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="dotted_border"></div>
                    <div className="main-accordion-wrapper ">
                      <div
                        className="accordion accordion-main "
                        id="accordionExample4"
                      >
                        <div className="accordion-item">
                          <div
                            className="mb-3 mt-3 pt-1 pb-1 w-100 accordion-button d-flex justify-content-between align-items-center accordion-header position-relative"
                            id="headingFour"
                          >
                            <div
                              className="w-100 accordion-button"
                              type="button"
                              data-bs-toggle="collapse"
                              data-bs-target="#collapseFour"
                              aria-expanded="true"
                              aria-controls="collapseFour"
                            >
                              <div className="accordion-title">
                                <h5 className="brandon-Bold mb-0">
                                  Restaurant Type
                                </h5>
                              </div>
                              <div className="expand-button position-absolute top-0 right-0"></div>
                            </div>
                          </div>
                          <div
                            id="collapseFour"
                            className="accordion-collapse collapse show"
                            aria-labelledby="headingFour"
                            data-bs-parent="#accordionExample4"
                          >
                            <div className="accordion-body">
                              <section className="accordion-list__item ">
                                <div className="row">
                                  <div className="col-sm-12">
                                    <div className="allergen-btn-wrapper d-flex align-items-start flex-wrap">
                                      {restaurantFeatures_Data &&
                                        restaurantFeatures_Data.data &&
                                        restaurantFeatures_Data.data.map(
                                          (data, index) => {
                                            return (
                                              <React.Fragment key={index}>
                                                <button
                                                  id={data._id}
                                                  type="button"
                                                  onClick={(e) => {
                                                    handleRestaurant(
                                                      e,
                                                      values.restaurantFeatures,
                                                      setFieldValue
                                                    );
                                                  }}
                                                  className={`allergen-btn d-flex flex-column justify-content-center mr-3 mb-3 p-0 align-items-center ${
                                                    values.restaurantFeatures &&
                                                    values.restaurantFeatures.indexOf(
                                                      data._id
                                                    ) !== -1 &&
                                                    "active"
                                                  }`}
                                                >
                                                  <div
                                                  id={data._id}
                                                  className="allergen-icon d-flex align-items-center justify-content-center mb-2"
                                                  onClick={(e) => {
                                                    handleRestaurant(
                                                      e,
                                                      values.restaurantFeatures,
                                                      setFieldValue
                                                    );
                                                  }}
                                                >
                                                  <img
                                                    id={data._id}
                                                    src={`${SERVER_URL}/${data.image}`}
                                                    className="img-fluid"
                                                    onClick={(e) => {
                                                      handleRestaurant(
                                                        e,
                                                        values.restaurantFeatures,
                                                        setFieldValue
                                                      );
                                                    }}
                                                    alt="img"
                                                    loading="lazy"
                                                  />
                                                </div>
                                                <span
                                                  id={data._id}
                                                  className="mb-0 f-12 txt-lightgray"
                                                  onClick={(e) => {
                                                    handleRestaurant(
                                                      e,
                                                      values.restaurantFeatures,
                                                      setFieldValue
                                                    );
                                                  }}
                                                >
                                                  {data.name}
                                                </span>
                                                </button>
                                              </React.Fragment>
                                            );
                                          }
                                        )}
                                    </div>
                                  </div>
                                </div>
                              </section>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="dotted_border"></div>
                    <div className="main-accordion-wrapper mb-3 pb-5">
                      <div
                        className="accordion accordion-main "
                        id="accordionExample5"
                      >
                        <div className="accordion-item">
                          <div
                            className="mb-3 mt-3 pt-1 pb-1 w-100 accordion-button d-flex justify-content-between align-items-center accordion-header position-relative"
                            id="headingFive"
                          >
                            <div
                              className="w-100 accordion-button"
                              type="button"
                              data-bs-toggle="collapse"
                              data-bs-target="#collapseFive"
                              aria-expanded="true"
                              aria-controls="collapseFive"
                            >
                              <div className="accordion-title">
                                <h5 className="brandon-Bold mb-0">
                                  Restaurant Distance
                                </h5>
                              </div>
                              <div className="expand-button position-absolute top-0 right-0"></div>
                            </div>
                          </div>

                          <div
                            id="collapseFive"
                            className="accordion-collapse collapse show"
                            aria-labelledby="headingFive"
                            data-bs-parent="#accordionExample5"
                          >
                            <div className="accordion-body">
                              <section className="accordion-list__item">
                                <div className="form-check custom-control custom-checkbox filter-checkbox mb-4">
                                  <Field
                                    type="checkbox"
                                    name="toggle"
                                    className="form-check-input custom-control-input"
                                    id="exampleCheck15"
                                    onClick={(e) => {
                                      setFieldValue("distance", 0);
                                      setCheckValue(false);
                                    }}
                                    style={{
                                      marginLeft: 2,
                                      zIndex: 1,
                                      cursor: "pointer",
                                    }}
                                  />
                                  <label
                                    className="form-check-label custom-control-label"
                                    htmlFor="exampleCheck15"
                                    style={{ zIndex: -1 }}
                                  >
                                    Near you (optional)
                                  </label>
                                </div>
                                <div className="form-check custom-control custom-checkbox filter-checkbox pl-0 mb-0">
                                  <SliderWithTooltip
                                    min={0}
                                    max={100}
                                    value={values.distance}
                                    onChange={(value) => {
                                      setFieldValue("distance", value);
                                    }}
                                    disabled={values.toggle}
                                    tipProps={{
                                      placement: "bottom",
                                      prefixCls: "rc-slider-tooltip",
                                      overlay: `${values.distance} km`,
                                      visible: true,
                                    }}
                                    railStyle={{
                                      height: "2px",
                                      backgroundColor: "#cb007b",
                                    }}
                                    trackStyle={{
                                      backgroundColor: "#cb007b",
                                      height: "2px",
                                    }}
                                    handleStyle={{
                                      prefixCls: "rc-slider-handle-custom",
                                    }}
                                  />

                                  {/* <Field type="range" disabled={values.toggle} name="distance" className="form-control-range" id="formControlRange" />
                                                                    <label htmlFor="formControlRange" className="ranage-txt" style={{ left: values.distance * 2.45 }}> {values.distance}mi</label> */}
                                </div>
                              </section>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="d-flex justify-content-center mb-3 filters-btns">
                      <button
                        className="lightgray-btn btn cancel-btn mr-4"
                        type="reset"
                        onClick={() => {
                          props.onHide();
                          resetForm();
                          setReset(false);
                          handleChangeInitialData(false);
                        }}
                      >
                        Cancel
                      </button>
                      <button
                        type="submit"
                        className="theme-pink-btn apply-btn brandon-Bold"
                      >
                        Apply
                      </button>
                    </div>
                  </Form>
                )}
              </Formik>
            </section>
          </Modal.Body>
          {/* <Modal.Footer>
                <Button onClick={props.onHide}>Close</Button>
            </Modal.Footer> */}
        </Modal>
      </section>
    </>
  );
};

export default AllergyFilterMobilePage;
