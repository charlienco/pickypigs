import React, { useState } from "react";
import { FACEBOOK_APP_ID, GOOGLE_CLIENT_ID } from "../../../shared/constant";
import { Field, Form, Formik } from "formik";
import * as Yup from "yup";
import { useHistory } from "react-router-dom";
import GoogleLogin from "react-google-login";
// import FacebookLogin from "react-facebook-login";
import showpassword from "../../../assets/images/eye_icon.svg";
import signup_logo from "../../../assets/images/mobile_imgs/signup_logo.png";

import "./SignupMobilePage.scss";
import { useDispatch, useSelector } from "react-redux";
import {
  registerUser,
  facebookLogin,
  googleLogin,
} from "../../../redux/actions/generalActions";
import CustomLoadingComp from "../../../components/CustomLoadingComp/CustomLoadingComp";
import SocialButton from "../../../components/SocialButton";

const passwordRegExp = RegExp(
  // eslint-disable-next-line
  /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})/
);

const validationSchema = Yup.object().shape({
  name: Yup.string().required("Name Required"),
  email: Yup.string()
    .email("Email must be a valid email")
    .required("Email Required"),
  password: Yup.string()
    .label("Password")
    .required("Password Required")
    .min(8, "Seems a bit short(Min 8 characters)...")
    .max(24, "Please try a shorter password(Max 24 characters)...).")
    .matches(
      passwordRegExp,
      "Password should Have 1 Uppercase,1 Lowercase,1 digit,1 special characte"
    ),
  // phone: Yup.string().required("Phone Number is required").matches(phoneRegex, "Invalid Phone Number").min(10, "to short").max(10, "Not More Than 10 "),
  confirmPassword: Yup.string()
    .required("Confirm password Required")
    .label("Confirm password")
    .test("passwords-match", "Passwords must match", function (value) {
      return this.parent.password === value;
    }),
});

const SignupMobilePage = (props) => {
  const dispatch = useDispatch();
  const history = useHistory();
  const [type, setType] = useState("password");
  const [confirmType, setConfirmType] = useState("password");

  const handleForm = (input, { setStatus, resetForm }) => {
    let obj = {
      email: input.email,
      name: input.name,
      // phone: input.phone,
      password: input.password,
      confirmPassword: input.confirmPassword,
      role: "user",
    };
    dispatch(registerUser(obj, history, "signUp"));
  };

  const googleResponse = (response) => {
    let obj = {
      email: response.profileObj.email,
      googleId: response.profileObj.id,
      name: response.profileObj.name,
      // token: response._token.accessToken,
    };
    dispatch(googleLogin(obj, history, "signUp"));
  };

  const handleSocialLogin = (user) => {
    if (user._provider === "facebook") {
        let obj = {
            email: user._profile.email,
            facebookId: user._profile.id,
            name: user._profile.name,
            // token: user._token.accessToken,
        };
        dispatch(facebookLogin(obj, history, "signIn"));
    }
    if (user._provider === "google") {
        // console.log(user);
        let obj = {
            email: user._profile.email,
            googleId: user._profile.id,
            name: user._profile.name,
            // token: user._token.accessToken,
        };
        dispatch(googleLogin(obj, history, "signIn"));
    }
  };
  const handleSocialLoginFailure = (err) => {
      console.error(err);
  };

  // const onFailure = error => {
  //     console.log("error login", error)
  //     // alert(error)
  // }
  const handlePassword = () => {
    let ele = document.getElementById("password");
    if (type === "password") {
      ele.classList.add("show");
      setType("text");
    } else {
      ele.classList.remove("show");
      setType("password");
    }
  };

  const handleConfirmPassword = () => {
    if (confirmType === "password") {
      setConfirmType("text");
    } else {
      setConfirmType("password");
    }
  };
  let loading = useSelector((state) => {
    return state.general.isLoading;
  });

  return (
    <section>
      <div className="mobileSignup-modalbody">
        <div className="logo">
          <img src={signup_logo} loading="lazy" alt="img" />
        </div>
        <Formik
          initialValues={{
            name: "",
            email: "",
            password: "",
            confirmPassword: "",
          }}
          validationSchema={validationSchema}
          onSubmit={handleForm}
        >
          {({
            values,
            errors,
            touched,
            handleChange,
            handleBlur,
            isSubmitting,
            /* and other goodies */
          }) => (
            <Form>
              <div className="row">
                <div className="col-sm-12">
                  <div className="form-group">
                    <Field
                      name="name"
                      className="form-control signup-input signup-input-name "
                      placeholder="Name or Full name"
                    />
                    {touched.name && errors.name && (
                      <div className="error text-white f-11">{errors.name}</div>
                    )}
                  </div>
                  <div className="form-group">
                    <Field
                      name="email"
                      placeholder="Email"
                      className="form-control signup-input email-input"
                    />
                    {/* {touched.email && errors.email &&
                                        <div className="error text-white f-11">{errors.email}</div>} */}
                    <div className="error text-white f-11">
                      {touched.email && errors.email && errors.email}
                    </div>
                  </div>
                  {/* <div className="form-group">
                                        <Field name="phone" placeholder="Phone" className="form-control signup-input" />
                                        {touched.phone && errors.phone && <div className="error text-white f-11">{errors.phone}</div>}
                                    </div> */}
                  <div className="form-group position-relative">
                    <Field
                      type={type}
                      name="password"
                      placeholder="Password"
                      className="form-control signup-input password-input"
                    />
                    <div
                      className="showpassword-block"
                      id="password"
                      onClick={() => handlePassword()}
                    >
                      <img
                        src={showpassword}
                        className="img-fluid"
                        alt="img"
                        loading="lazy"
                      />
                    </div>
                    {touched.password && errors.password && (
                      <div className="error text-white f-11">
                        {errors.password}
                      </div>
                    )}
                  </div>
                  {/* <div className="form-group">
                                        <Field type="password" name="confirmPassword" placeholder="Confirm Password" className="form-control signup-input" />
                                        {touched.confirmPassword && errors.confirmPassword && <div className="error text-white f-11">{errors.confirmPassword}</div>}
                                    </div> */}
                  <div className="form-group position-relative">
                    <Field
                      type={confirmType}
                      name="confirmPassword"
                      placeholder="Confirm new password"
                      className="form-control signup-input password-input"
                    />
                    <div
                      className={`showpassword-block ${
                        confirmType === "password" ? null : "show"
                      }`}
                      id="confirmPassword"
                      onClick={handleConfirmPassword}
                    >
                      <img
                        src={showpassword}
                        className="img-fluid"
                        alt="showpassword"
                        loading="lazy"
                      />
                    </div>
                    <div className="error text-white f-11">
                      {touched.confirmPassword &&
                        errors.confirmPassword &&
                        errors.confirmPassword}
                    </div>
                  </div>

                  <div className="form-group">
                    <button
                      className="pinkline-btn signup-btn btn mt-4 w-100 border-radius-25 brandon-Medium"
                      type="submit"
                    >
                      Sign up
                    </button>
                  </div>
                </div>
              </div>
            </Form>
          )}
        </Formik>
        <React.Fragment>
          {loading ? <CustomLoadingComp /> : null}
        </React.Fragment>
        <div className="row">
          <div className="col-sm-12">
            <div className="or-txt">
              <span className="or_left_line"></span>
              <span className="f-14">or</span>
              <span className="or_right_line"></span>
            </div>
          </div>
        </div>
        <div className="row">
          <div className="col-sm-12 pl-xl-4 pr-xl-4">
            <div className="socail-login d-flex justify-content-between align-items-center mt-3 pl-5 pr-5">
              <SocialButton
                  style={{ backgroundColor: "transparent", border: "none" }}
                  provider={"facebook"}
                  appId={FACEBOOK_APP_ID}
                  onLoginSuccess={handleSocialLogin}
                  onLoginFailure={handleSocialLoginFailure}
              >
                  <div className="btnFacebook socail-btn"></div>
              </SocialButton>
              <GoogleLogin
                clientId={GOOGLE_CLIENT_ID}
                onSuccess={googleResponse}
                className="btnGoogle socail-btn"
                icon={false}
              >
                {/* <span>Google</span> */}
                <span></span>
              </GoogleLogin>
            </div>
          </div>
        </div>
        <div className="text-center ">
          <button
            className="trans_button text-white"
            style={{ textDecoration: "none" }}
            onClick={() => {
              props.gotoLogin();
            }}
          >
            <span>
              Already I'm a Pickypig<br></br>
              Sign in to your account
            </span>
          </button>
        </div>
        <div className="text-center ">
          <span>Or</span>
        </div>

        <div className="text-center ">
          <button
            className="trans_button text-white"
            style={{ textDecoration: "none" }}
            onClick={() => {
              props.onHide();
            }}
          >
            <span>Skip</span>
          </button>
        </div>
      </div>
    </section>
  );
};

export default SignupMobilePage;
