import React, { useEffect, useState } from "react";
import UserPersonalDetailMobileComp from "../../MobileComponents/UserPersonalDetailMobileComp/UserPersonalDetailMobileComp";

import "./UserProfileMobilePage.scss";
import { useDispatch, useSelector } from "react-redux";
import { useHistory } from "react-router-dom";
import {
  getUserProfileDetail,
  updateUserProfileImage,
} from "../../../redux/actions/userProfileAction";
import { SERVER_URL } from "../../../shared/constant";
import profileimage from "../../../assets/images/profileimage.gif";
import PreferenceDetailMobilePage from "../PreferenceDetailMobilePage/PreferenceDetailMobilePage";
import location_icon_black from "../../../assets/images/mobile_imgs/location_icon_black.svg";
import leftarrow_black from "../../../assets/images/mobile_imgs/left-black-arrow.svg";
import CustomLoadingComp from "../../../components/CustomLoadingComp/CustomLoadingComp";

const UserProfileMobilePage = () => {
  const dispatch = useDispatch();
  const history = useHistory();

  const [tab1, setTab1] = useState(true);
  const [tab2, setTab2] = useState(false);
  const [tab3, setTab3] = useState(false);
  // eslint-disable-next-line
  const [imageLoading, setImageLoading] = useState(false);

  useEffect(() => {
    if (!localStorage.getItem("access_token")) {
      history.push("/");
    } else {
      dispatch(getUserProfileDetail(history));
    }
    // eslint-disable-next-line
  }, [dispatch]);

  const User_Data = useSelector((state) => {
    return state.userProfile;
  });

  const { userProfile_Data, isLoading } = User_Data;

  const ImageUploadHandeler = (e) => {
    e.preventDefault();
    if (e.target.files[0]) {
      dispatch(updateUserProfileImage(e.target.files[0]));
    }
  };

  return (
    <>
      <section>
        {isLoading ? (
          <React.Fragment>
            <CustomLoadingComp />
          </React.Fragment>
        ) : null}
        {/* <div className="container"> */}
        <div className="user-profile-main-bg">
          <div className="row">
            <div className="col-sm-12 pl-0 pr-0">
              <div className="user-profile-main-img"></div>
              <div className="restaurant-navbar">
                <div
                  className="restaurant-leftslide"
                  type="button"
                  onClick={() => {
                    history.goBack();
                  }}
                >
                  <img
                    src={leftarrow_black}
                    className="img-fluid"
                    loading="lazy"
                    alt="img"
                  />
                </div>
                {/* <div className="restaurant-rigthslide d-flex align-items-center">
                                    <div className="restaurant-favorite-icon">
                                        <img src={editblack_icon} className="img-fluid" />
                                    </div> */}
                {/* <div className="restaurant-share-icon ml-4">
                                        <img src={share_icon} className="img-fluid" />
                                    </div> */}
                {/* </div> */}
              </div>
            </div>
          </div>
        </div>
        {/* <div style={{backgroundColor:'greenyellow',width:'100%',height:200}}></div> */}
        <div
          style={{
            backgroundColor: "white",
            marginTop: -40,
            borderTopLeftRadius: 35,
            borderTopRightRadius: 35,
            position: "relative",
          }}
        >
          <div className="row">
            <div className="col-sm-12">
              <div className="col-sm-12">
                <div style={{ position: "relative", marginTop: -50 }}>
                  <div className="mb-3 position-relative">
                    <div className="user-profile-img userprofile-select">
                      {userProfile_Data &&
                      userProfile_Data.userDetail &&
                      userProfile_Data.userDetail.profileImage ? (
                        <img
                          loading="lazy"
                          onLoad={() => {
                            setImageLoading(true);
                          }}
                          src={`${SERVER_URL}/${userProfile_Data.userDetail.profileImage}`}
                          alt="imh"
                          className="img-fluid img-thumbnil"
                        />
                      ) : (
                        <img
                          src={profileimage}
                          loading="lazy"
                          alt="img"
                          className="img-fluid img-thumbnil"
                        />
                      )}
                      <form>
                        <div className="form-group">
                          <div className="userprofile-btn">
                            <input
                              type="file"
                              accept="image/*"
                              name="uploadedfile"
                              className="form-control-file userprofile-control"
                              onChange={ImageUploadHandeler}
                            />
                          </div>
                        </div>
                      </form>
                    </div>
                  </div>
                  <div className="userprofile-name mb-4 pb-2">
                    {userProfile_Data &&
                    userProfile_Data.userDetail &&
                    userProfile_Data.userDetail.name ? (
                      <h5 className="username-txt text-capitalize brandon-Medium">
                        Hello &nbsp;{userProfile_Data.userDetail.name}
                      </h5>
                    ) : (
                      <h5 className="username-txt brandon-Medium">
                        Unknown User
                      </h5>
                    )}
                    <div className="user-address d-flex align-items-center">
                      <div className="user-address-icon mr-2">
                        <img
                          width="15px"
                          src={location_icon_black}
                          className="img-fluid"
                          loading="lazy"
                          alt="img"
                        />
                      </div>
                      <span className="text-capitalize">
                        {userProfile_Data &&
                          userProfile_Data.userDetail &&
                          userProfile_Data.userDetail.address}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="row">
          <div className="col-sm-12">
            <div className="col-sm-12 mb-3">
              <div className="user-profile-tabs d-flex align-items-center justify-content-between">
                <button
                  onClick={() => {
                    setTab1(true);
                    setTab2(false);
                    setTab3(false);
                  }}
                  className={`${tab1 ? "active" : null}`}
                >
                  Personal Detail
                </button>
                <button
                  onClick={() => {
                    setTab1(false);
                    setTab2(true);
                    setTab3(false);
                  }}
                  className={`${tab2 ? "active" : null}`}
                >
                  Your Favorite
                </button>
                <button
                  onClick={() => {
                    setTab1(false);
                    setTab2(false);
                    setTab3(true);
                  }}
                  className={`${tab3 ? "active" : null}`}
                >
                  Preference
                </button>
              </div>
            </div>
          </div>
        </div>
        <div className="mb-3">
          {tab1 ? (
            <React.Fragment>
              <UserPersonalDetailMobileComp userdata={userProfile_Data} />
            </React.Fragment>
          ) : tab2 ? (
            <React.Fragment>
              {/* <UserPersonalDetailMobileComp  userdata={userProfile_Data}/> */}
            </React.Fragment>
          ) : (
            <React.Fragment>
              <PreferenceDetailMobilePage />
            </React.Fragment>
          )}
        </div>
        {/* </div> */}
      </section>
    </>
  );
};

export default UserProfileMobilePage;
