import React from "react";
import AllRestaurantMobileComp from "../../MobileComponents/AllRestaurantMobileComp/AllRestaurantMobileComp";
import DiscBlockCarouselMobileComp from "../../MobileComponents/DiscBlockCarouselMobileComp/DiscBlockCarouselMobileComp";
import FilterByFeatureMobileComp from "../../MobileComponents/FilterByFeatureMobileComp/FilterByFeatureMobileComp";
import MenuBlockCarouselMobileComp from "../../MobileComponents/MenuBlockCarouselMobileComp/MenuBlockCarouselMobileComp";
import { ReactComponent as Filter } from "../../../assets/images/mobile_imgs/Piggy.svg";
import Filterbtn from "../../../assets/images/mobile_imgs/filterbtn_icon.svg";
import SubMenuModalMobileComp from "../../MobileComponents/SubMenuModalMobileComp/SubMenuModalMobileComp";
import AllergyFilterMobilePage from "../AllergyFilterMobilePage/AllergyFilterMobilePage";
import SearchAutoSuggestionMobilePage from "../SearchAutoSuggestionMobilePage/SearchAutoSuggestionMobilePage";
import MyfilterListExampleCopy from "../../../components/MyfilterListExampleCopy/MyfilterListExampleCopy";
import { SERVER_URL } from "../../../shared/constant";
import profileimage from "../../../assets/images/profileimage.gif";

import "./HomeMobilePage.scss";
import { useDispatch, useSelector } from "react-redux";
import {
  showSignUpPopup,
  showSignInPopup,
  showVerificationPopup,
  showForgotPasswordPopup,
  registrationSuccess,
} from "../../../redux/actions/generalActions";
import { Modal } from "react-bootstrap";
import LogInMobilePage from "../LogInMobilePage/LogInMobilePage";
import SignupMobilePage from "../SignupMobilePage/SignupMobilePage";
import CustomLoadingComp from "../../../components/CustomLoadingComp/CustomLoadingComp";
import ForgotPasswordMobilePage from "../ForgotPasswordMobilePage/ForgotPasswordMobilePage";
import RegistrationSuccessMobileScreen from "../RegistrationSuccessMobileScreen/RegistrationSuccessMobileScreen";
import EmailverificationSuccessMobileScreen from "../EmailverificationSuccessMobileScreen/EmailverificationSuccessMobileScreen";

const HomeMobilePage = () => {
  const dispatch = useDispatch();
  const [submenuModalShow, setSubmenuModalShow] = React.useState(false);
  const [mobileFilterModalShow, setMobileFilterModalShow] =
    React.useState(false);
  const [mobileSearchModalShow, setMobileSearchModalShow] =
    React.useState(false);

  let User_Data = useSelector((state) => {
    return state.userProfile;
  });
  let { userProfile_Data } = User_Data;

  let loading = useSelector((state) => {
    return state.general.isLoading;
  });

  const signUpModal = useSelector((state) => state.general.showSignUpPopup);
  const signInModal = useSelector((state) => state.general.showSignInPopup);
  const forgotPasswordModal = useSelector(
    (state) => state.general.showForgotPasswordPopup
  );
  const registerModal = useSelector(
    (state) => state.general.showSignUpSuccessPopup
  );
  const verificationModal = useSelector(
    (state) => state.general.showVerificationPopup
  );
  // const adminSignUpModal = useSelector((state) => state.restaurantAdmin.showAdminSignUpPopup);

  const token = localStorage.getItem("access_token");

  const preferenceData = useSelector((state) => {
    return state.myPreference.selectedPreference;
  });

  const searchRestaurant_Data = useSelector((state) => {
    return state.restaurantSearch;
  });

  let isLoadingFilter = searchRestaurant_Data
    ? searchRestaurant_Data.isLoading
    : false;

  let { allergendata, dietarydata, lifestyledata, featuredata } =
    preferenceData;

  return (
    <>
      <section className="HomeMobilePage-comp pt-3">
        <React.Fragment>
          {loading || isLoadingFilter ? <CustomLoadingComp /> : null}
        </React.Fragment>
        <div className="col-sm-12">
          <div className="row">
            <div className="col-sm-12">
              <div className="d-flex justify-content-between align-items-center mb-4 location-user-wrapper">
                <div className="location-user-sub-wrapper">
                  {token &&
                  userProfile_Data &&
                  userProfile_Data.role === "user" ? (
                    <React.Fragment>
                      {userProfile_Data &&
                      userProfile_Data.userDetail &&
                      userProfile_Data.userDetail.name ? (
                        <h5 className="section-heading brandon-Medium mb-1 text-capitalize">
                          Hello&nbsp;{userProfile_Data.userDetail.name}
                        </h5>
                      ) : (
                        <h5 className="section-heading brandon-Medium mb-1 text-capitalize">
                          Hello&nbsp;{userProfile_Data.userDetail.email}
                        </h5>
                      )}
                    </React.Fragment>
                  ) : (
                    <React.Fragment>
                      <div>
                        <h5 className="d-block mb-0">Hello Guest</h5>
                      </div>
                    </React.Fragment>
                  )}
                  <div style={{ maxWidth: "250px" }}>
                    <MyfilterListExampleCopy />
                  </div>
                </div>
                {token &&
                userProfile_Data &&
                userProfile_Data.role === "user" ? (
                  <React.Fragment>
                    <div
                      className="userimg-profile"
                      role="button"
                      onClick={() => setSubmenuModalShow(true)}
                    >
                      {userProfile_Data &&
                      userProfile_Data.userDetail &&
                      userProfile_Data.userDetail.profileImage ? (
                        <img
                          src={`${SERVER_URL}/${userProfile_Data.userDetail.profileImage}`}
                          width="50px"
                          className="userprofile-img img-fluid  rounded-circle"
                          alt="logo"
                          loading="lazy"
                        />
                      ) : (
                        <img
                          src={profileimage}
                          width="50px"
                          className="userprofile-img img-fluid  rounded-circle"
                          alt="logo"
                          loading="lazy"
                        />
                      )}
                    </div>
                  </React.Fragment>
                ) : (
                  <React.Fragment>
                    <button
                      onClick={() => {
                        dispatch(showSignInPopup(true));
                      }}
                      className="login-btn rounded"
                    >
                      Login
                    </button>
                  </React.Fragment>
                )}
              </div>
            </div>
          </div>
          <SubMenuModalMobileComp
            show={submenuModalShow}
            onHide={() => setSubmenuModalShow(false)}
          />

          <div className="d-flex justify-content-between align-items-center mb-4">
            <button
              className="mobile_search_button rounded-pill"
              onClick={() => setMobileSearchModalShow(true)}
            >
              <Filter />
              &nbsp;Search for restaurants or recipes
            </button>
            <button
              className="restaurants-recipes-btn position-relative"
              onClick={() => setMobileFilterModalShow(true)}
            >
              <img
                src={Filterbtn}
                className="img-fluid"
                width="25px"
                alt="icon"
                loading="lazy"
              />
              {(allergendata && allergendata.length) +
                (dietarydata && dietarydata.length) +
                (lifestyledata && lifestyledata.length) +
                (featuredata && featuredata.length) >
              0 ? (
                <small className="preference_count">
                  {(allergendata && allergendata.length) +
                    (dietarydata && dietarydata.length) +
                    (lifestyledata && lifestyledata.length) +
                    (featuredata && featuredata.length)}
                </small>
              ) : null}
            </button>
          </div>
          <SearchAutoSuggestionMobilePage
            show={mobileSearchModalShow}
            onHide={() => setMobileSearchModalShow(false)}
          />
          <AllergyFilterMobilePage
            show={mobileFilterModalShow}
            onHide={() => setMobileFilterModalShow(false)}
          />
          <div>
            <FilterByFeatureMobileComp />
          </div>
          <div>
            <h5 className="section-heading brandon-Medium mb-4">
              Find A Restaurant You Will love
            </h5>
            <DiscBlockCarouselMobileComp />
          </div>
          <div>
            <h5 className="section-heading brandon-Medium mb-4">
              Whats New On The Menu?
            </h5>
            {/* <button>Sell All</button> */}
            <MenuBlockCarouselMobileComp />
          </div>

          <div>
            <AllRestaurantMobileComp />
          </div>
        </div>

        <Modal
          centered
          show={signUpModal}
          onHide={() => {
            dispatch(showSignUpPopup(false));
          }}
          backdrop="static"
          keyboard={false}
          className="MobileSignup-modal"
        >
          <Modal.Body className="p-0 position-relative">
            <SignupMobilePage
              gotoLogin={() => {
                dispatch(showSignUpPopup(false));
                dispatch(showSignInPopup(true));
              }}
              onHide={() => {
                dispatch(showSignUpPopup(false));
              }}
              show={signUpModal}
            />
          </Modal.Body>
        </Modal>

        <Modal
          centered
          show={signInModal}
          onHide={() => dispatch(showSignInPopup(false))}
          backdrop="static"
          keyboard={false}
          className="MobileSignInPage-modal"
        >
          <Modal.Body className="p-0 position-relative">
            <LogInMobilePage
              openForgotPass={() => {
                dispatch(showSignInPopup(false));
                dispatch(showForgotPasswordPopup(true));
              }}
              gotoSignup={() => {
                dispatch(showSignUpPopup(true));
                dispatch(showSignInPopup(false));
              }}
              onHide={() => dispatch(showSignInPopup(false))}
              show={signInModal}
            />
          </Modal.Body>
        </Modal>

        <Modal
          centered
          show={forgotPasswordModal}
          onHide={() => dispatch(showForgotPasswordPopup(false))}
          backdrop="static"
          keyboard={false}
          className="MobileForgotPasswordPage-modal"
        >
          <Modal.Body className="p-0 position-relative">
            <ForgotPasswordMobilePage
              gotoLogin={() => {
                dispatch(showForgotPasswordPopup(false));
                dispatch(showSignInPopup(true));
              }}
              onHide={() => dispatch(showForgotPasswordPopup(false))}
              show={forgotPasswordModal}
            />
          </Modal.Body>
        </Modal>

        <Modal
          centered
          show={registerModal}
          onHide={() => dispatch(registrationSuccess(false))}
          backdrop="static"
          keyboard={false}
          className="MobileRegistrationSuccessScreen-modal"
        >
          <Modal.Body className="p-0 position-relative">
            <RegistrationSuccessMobileScreen
              onHide={() => dispatch(registrationSuccess(false))}
              show={registerModal}
            />
          </Modal.Body>
        </Modal>

        {/* <Modal centered show={adminSignUpModal} onHide={()=>dispatch(showAdminSignUpPopup(false))} className="SignUpModalComp-modal">
                    <Modal.Body className="p-0 position-relative">
                        <SignUpModalComp 
                           onHide={()=>dispatch(showAdminSignUpPopup(false))} show={adminSignUpModal} 
                        />
                    </Modal.Body>
                </Modal> */}

        <Modal
          centered
          show={verificationModal}
          onHide={() => {
            dispatch(showVerificationPopup(false));
          }}
          backdrop="static"
          keyboard={false}
          className="MobileEmailverificationSuccessScreen-modal"
        >
          <Modal.Body className="p-0 position-relative">
            <EmailverificationSuccessMobileScreen
              gotoLogin={() => {
                dispatch(showVerificationPopup(false));
                dispatch(showSignInPopup(true));
              }}
              onHide={() => {
                dispatch(showVerificationPopup(false));
              }}
              show={verificationModal}
            />
          </Modal.Body>
        </Modal>
      </section>
    </>
  );
};

export default HomeMobilePage;
