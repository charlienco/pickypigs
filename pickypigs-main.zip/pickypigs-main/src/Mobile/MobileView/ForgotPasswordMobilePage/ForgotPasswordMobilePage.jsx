import React from "react";
import { Field, Form, Formik } from "formik";
import * as Yup from "yup";
import { forgotPassword } from "../../../redux/actions/generalActions";
import { useDispatch, useSelector } from "react-redux";
import "./ForgotPasswordMobilePage.scss";
import signup_logo from "../../../assets/images/mobile_imgs/signup_logo.png";
import CustomLoadingComp from "../../../components/CustomLoadingComp/CustomLoadingComp";

const ForgotPasswordMobilePage = (props) => {
  const dispatch = useDispatch();

  const validationSchemaForForgotPassword = Yup.object().shape({
    email: Yup.string()
      .email("Email must be a valid email")
      .required("Email Required"),
  });

  const handlelForgotPassword = (input) => {
    let obj = {
      email: input.email,
    };
    dispatch(forgotPassword(obj));
  };
  let loading = useSelector((state) => {
    return state.general.isLoading;
  });

  return (
    <React.Fragment>
      <section className="ForgotPasswordMobilePage-comp">
        <div className="logo">
          <img src={signup_logo} loading="lazy" alt="img" />
        </div>
        <div className="row">
          <div className="col-sm-12 mb-3">
            <p className="f-15 text-white">
              <span className="pr-2 d-flex text-center">
                Enter your email address in the for below and we will send you
                further instructions on how to reset your password.
              </span>
            </p>
          </div>
        </div>
        <Formik
          initialValues={{ email: "" }}
          validationSchema={validationSchemaForForgotPassword}
          onSubmit={handlelForgotPassword}
        >
          {({ errors, touched }) => (
            <Form>
              <div className="row">
                <div className="col-sm-12">
                  <div className="form-group">
                    <Field
                      name="email"
                      placeholder="Email"
                      className="form-control signup-input email-input"
                    />
                    {touched.email && errors.email && (
                      <div className="error text-white f-11">
                        {errors.email}
                      </div>
                    )}
                  </div>

                  <div className="form-group">
                    <button
                      className="pinkline-btn signup-btn btn mt-4 w-100 border-radius-25 brandon-Medium"
                      type="submit"
                    >
                      RESET PASSWORD
                    </button>
                  </div>

                  <div className="forgot-block mt-4 text-center">
                    <button
                      type="button"
                      className="forgot-link trans_button text-decoration-none"
                      onClick={() => {
                        props.gotoLogin();
                      }}
                    >
                      <span className="text-white brandon-Medium f-14">
                        Sign in
                      </span>
                    </button>
                  </div>
                  <div className="row">
                    <div className="col-sm-12">
                      <div className="or-txt">
                        <span className="or_left_line"></span>
                        <span className="f-14">or</span>
                        <span className="or_right_line"></span>
                      </div>
                    </div>
                  </div>
                  <div className="forgot-block mb-3 text-center">
                    <button
                      type="button"
                      className="forgot-link trans_button text-decoration-none"
                      onClick={() => {
                        props.onHide();
                      }}
                    >
                      <span className="text-white brandon-Medium f-14">
                        Skip
                      </span>
                    </button>
                  </div>
                </div>
              </div>
            </Form>
          )}
        </Formik>
        <React.Fragment>
          {loading ? <CustomLoadingComp /> : null}
        </React.Fragment>
      </section>
    </React.Fragment>
  );
};

export default ForgotPasswordMobilePage;
