import React from 'react'
import "./RegistrationSuccessMobileScreen.scss"

import Tick from '../../../assets/images/check.svg' 




const RegistrationSuccessMobileScreen = (props) => {

 

    return (
        
        <div className="RegistrationSuccessMobileScreen-comp">
            <div className="d-flex flex-column justify-content-center align-items-center" style={{height:250}}>
                <img src={Tick} className="img-fluid pb-4" width="50px" loading="lazy" alt="img"/>
                <p className="brandon-Bold" >User Registration Successful.</p>
                <p className="f-15 "><span>Check your registered email for verification</span></p>
                <button className="pinkline-btn signup-btn btn w-50 text-uppercase border-radius-25"  onClick={()=>{props.onHide()} }>
                                                Ok
                </button>   
            </div>
        </div>
        
    )
}

export default RegistrationSuccessMobileScreen;
