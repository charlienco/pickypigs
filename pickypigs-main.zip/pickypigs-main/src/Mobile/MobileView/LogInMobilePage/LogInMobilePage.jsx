import React, { useState } from 'react';
import { Field, Form, Formik } from 'formik';
import * as Yup from 'yup';
import { facebookLogin, getLogin, googleLogin } from '../../../redux/actions/generalActions';
import { useDispatch, useSelector } from 'react-redux';
import { useHistory } from 'react-router';
import showpassword from "../../../assets/images/eye_icon.svg";
import { GoogleLogin } from 'react-google-login';
// import FacebookLogin from 'react-facebook-login';
import { FACEBOOK_APP_ID, GOOGLE_CLIENT_ID } from '../../../shared/constant';
import "./LogInMobilePage.scss"
import signup_logo from "../../../assets/images/mobile_imgs/signup_logo.png";
import CustomLoadingComp from '../../../components/CustomLoadingComp/CustomLoadingComp';
import SocialButton from '../../../components/SocialButton';

// eslint-disable-next-line no-useless-escape
const passwordRegExp = RegExp(/^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})/);

const LogInMobilePage = (props) => {

    const dispatch = useDispatch();
    const history = useHistory()
    const [type, setType] = useState("password")
    const [capsStatus, setCapsStatus] = useState(false)

    const validationSchemaForLogin = Yup.object().shape({
        email: Yup.string().email('Email must be a valid email').required('Email Required'),
        password: Yup
            .string()
            .label('Password')
            .required('Password Required')
            .min(8, 'Seems a bit short(Min 8 characters)...')
            .max(24, 'Please try a shorter password(Max 24 characters)...).')
            .matches(passwordRegExp, 'Password should Have 1 Uppercase,1 Lowercase,1 digit,1 special characte'),
    });

    const handlePassword = () => {
        let ele = document.getElementById("password")
        if (type === "password") {
            ele.classList.add("show")
            setType("text")
        } else {
            ele.classList.remove("show")
            setType("password")
        }
    }

    const handleLoginForm = (input, { setStatus, resetForm }) => {
        let obj = {
            email: input.email,
            password: input.password
        }

        dispatch(getLogin(obj, history))
    }

    let loading = useSelector((state) => {
        return state.general.isLoading
    });

    const handleSocialLogin = (user) => {
        if (user._provider === "facebook") {
            let obj = {
                email: user._profile.email,
                facebookId: user._profile.id,
                name: user._profile.name,
                // token: user._token.accessToken,
            };
            dispatch(facebookLogin(obj, history, "signIn"));
        }
        if (user._provider === "google") {
            // console.log(user);
            let obj = {
                email: user._profile.email,
                googleId: user._profile.id,
                name: user._profile.name,
                // token: user._token.accessToken,
            };
            dispatch(googleLogin(obj, history, "signIn"));
        }
    };
    const handleSocialLoginFailure = (err) => {
        console.error(err);
    };
    const googleResponse = response => {
        let obj = {
            email: response.profileObj.email,
            googleId: response.profileObj.id,
            name: response.profileObj.name,
            // token: response._token.accessToken,
        }
        dispatch(googleLogin(obj, history, "signIn"))
    }



    //Show capslock on or off
    const onKeyDown = keyEvent => {
        if (keyEvent.getModifierState("CapsLock")) {
            setCapsStatus(true)
        } else {
            setCapsStatus(false)
        }
    };


    return (
        <React.Fragment>
            <section className="loginmobilepage-comp">
                <div className="logo">
                    <img src={signup_logo} loading="lazy" alt="icon" />
                </div>
                <Formik
                    initialValues={{ email: '', password: '' }}
                    validationSchema={validationSchemaForLogin}
                    onSubmit={handleLoginForm}
                >
                    {({ errors, touched }) => (
                        <Form>
                            <div className="row">
                                <div className="col-sm-12">
                                    <div className="form-group">
                                        <Field name="email" placeholder="Email" className="form-control signup-input email-input" onKeyDown={onKeyDown} />
                                        {touched.email && errors.email &&
                                            <div className="error text-white f-11">{errors.email}</div>}
                                        {capsStatus &&
                                            <div className="error text-white f-11">Caps Lock Is On</div>}

                                    </div>
                                    <div className="form-group position-relative">
                                        <Field type={type} name="password" placeholder="Password" className="form-control signup-input password-input"
                                        />
                                        <div className="showpassword-block" id="password" onClick={() => handlePassword()}>
                                            <img src={showpassword} className="img-fluid" alt="showpassword" loading="lazy" />
                                        </div>
                                        <div className="error text-white f-11">{(touched.password && errors.password && errors.password)}</div>
                                    </div>
                                    <div className="form-group">
                                        <button className="pinkline-btn signup-btn btn mt-4 w-100 border-radius-25 brandon-Medium" type="submit" >
                                            Sign in
                                        </button>
                                    </div>
                                    <div className="forgot-block mt-4 mb-3 text-center">
                                        <button type="button" onClick={() => { props.openForgotPass() }} className="forgot-link trans_button text-decoration-none">
                                            <span className="text-white brandon-Medium f-14">Forgot Password?</span>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </Form>
                    )}
                </Formik>
                <React.Fragment>
                    {loading ?
                        <CustomLoadingComp />
                        :
                        null
                    }
                </React.Fragment>
                <div className="row">
                    <div className="col-sm-12">
                        <div className="or-txt">
                            <span className="or_left_line"></span>
                            <span className="f-14">or</span>
                            <span className="or_right_line"></span>
                        </div>
                    </div>
                </div>
                <div className="row">
                    <div className="col-sm-12 pl-xl-4 pr-xl-4">
                        <div className="socail-login d-flex justify-content-between align-items-center mt-3 pl-5 pr-5">

                            <SocialButton
                                style={{ backgroundColor: "transparent", border: "none" }}
                                provider={"facebook"}
                                appId={FACEBOOK_APP_ID}
                                onLoginSuccess={handleSocialLogin}
                                onLoginFailure={handleSocialLoginFailure}
                            >
                                <div className="btnFacebook socail-btn"></div>
                            </SocialButton>

                            <GoogleLogin
                                clientId={GOOGLE_CLIENT_ID}
                                onSuccess={googleResponse}
                                className="btnGoogle socail-btn"
                                icon={false}
                            >
                                {/* <span>Google</span> */}
                                <span></span>
                            </GoogleLogin>
                        </div>
                    </div>
                </div>
                <div className="text-center ">
                    <button className="trans_button text-white" style={{ textDecoration: 'none' }} onClick={() => { props.gotoSignup() }}>
                        <span>Create an account<br></br>
                            I’m a new Pickypig</span>
                    </button>
                </div>
                <div className="text-center ">
                    <span>Or</span>
                </div>

                <div className="text-center ">
                    <button className="trans_button text-white" style={{ textDecoration: 'none' }} onClick={() => { props.onHide() }}>
                        <span>Skip</span>
                    </button>
                </div>
            </section>
        </React.Fragment>
    )
}

export default LogInMobilePage;