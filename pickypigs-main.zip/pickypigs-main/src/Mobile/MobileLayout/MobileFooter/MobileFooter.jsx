import React from "react";
import './MobileFooter.scss';
import pattern_img from "../../../assets/images/mobile_imgs/pattern.svg";

const MobileFooter = () => {
    return (
        <>
            <section className="position-relative pt-5 pb-5">
                <div className="container">
                    <div className="row">
                        <div className="col-sm-12">
                            <div className="pattern-bottom-mob">
                                <img src={pattern_img} className="img-fluid" loading="lazy" alt="img" />
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <section>
                <div className="container">
                    <p className="f-14 text-center txt-lightgray">© 2020 Picky Pigs.</p>
                </div>
            </section>
        </>
    )
}

export default MobileFooter;