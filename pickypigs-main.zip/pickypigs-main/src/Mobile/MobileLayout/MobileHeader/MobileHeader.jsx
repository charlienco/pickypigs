import React from "react";
import "./MobileHeader.scss";
import logomobile from "../../../assets/images/logo.svg";
import { NavLink, withRouter } from "react-router-dom";
import { Modal } from "react-bootstrap";
import { showContactUsPopup } from "../../../redux/actions/restaurantAdminAction";
import ContactUs from "../../../components/ContactUs";
import { useDispatch, useSelector } from "react-redux";
const MobileHeader = () => {
  const dispatch = useDispatch();
  const contactUsModal = useSelector(
    (state) => state.restaurantAdmin.contactUsModal
  );

  return (
    <>
      <section>
        <div className="row">
          <div className="col-sm-12">
            <NavLink
              to="/"
              style={{ textDecoration: "none", color: "initial" }}
            >
              <div
                className="navmain-logo d-flex align-items-center justify-content-center"
                style={{ padding: 12 }}
              >
                <img
                  src={logomobile}
                  className="img-fluid mr-2"
                  loading="lazy"
                  alt="img"
                />
                <span className="text-white">
                  <b>Picky Pigs</b>
                </span>
              </div>
            </NavLink>
          </div>
          {/* <h1>MobileHeader</h1> */}
          <Modal
            centered
            show={contactUsModal}
            onHide={() => dispatch(showContactUsPopup(false))}
            className="SignUpModalComp-modal partner-modal"
          >
            <Modal.Body className="p-0 position-relative">
              <ContactUs
                onHide={() => dispatch(showContactUsPopup(false))}
                show={contactUsModal}
              />
            </Modal.Body>
          </Modal>
        </div>
      </section>
    </>
  );
};

export default withRouter(MobileHeader);
