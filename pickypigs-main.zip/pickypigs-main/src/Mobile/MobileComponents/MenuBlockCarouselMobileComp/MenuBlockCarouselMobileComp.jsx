import React, { useEffect } from "react";
import Slider from "react-slick";
import MenuBlockMobileComp from "../MenuBlockMobileComp/MenuBlockMobileComp";
import { Link } from "react-router-dom";
import { getRandomDishList } from "../../../redux/actions/homePageAction";
import { useDispatch, useSelector } from "react-redux";
import { DEFAULT_LAT, DEFAULT_LNG } from "../../../shared/constant";
import MobRestaurantSkeletonOne from "../../Skeleton/MobRestaurantSkeletonOne/MobRestaurantSkeletonOne";

const MenuBlockCarouselMobileComp = () => {
  const dispatch = useDispatch();

  const myCordinates = useSelector((state) => {
    return state.googledata;
  });
  let { overalLocation = { lat: DEFAULT_LAT, lng: DEFAULT_LNG } } =
    myCordinates;

  useEffect(() => {
    if (overalLocation && overalLocation.lat && overalLocation.lng) {
      dispatch(
        getRandomDishList({
          userCoordinates: [
            overalLocation && overalLocation.lat ? overalLocation.lat : "",
            overalLocation && overalLocation.lng ? overalLocation.lng : "",
          ],
        })
      );
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [overalLocation]);

  const randomDishData = useSelector((state) => {
    return state.homePage;
  });
  let { isLoading, randomDishsList_Data } = randomDishData;

  var settings = {
    arrows: false,
    centerMode: false,
    slidesToShow: 1.2,
    slidesToScroll: 1,
    infinite: false,
    responsive: [
      {
        breakpoint: 1200,
        settings: {
          slidesToShow: 3.2,
        },
      },
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 3.2,
        },
      },
      {
        breakpoint: 992,
        settings: {
          slidesToShow: 2.2,
        },
      },
      {
        breakpoint: 768,
        settings: {
          slidesToShow: 2.2,
        },
      },
      {
        breakpoint: 600,
        settings: {
          slidesToShow: 1.2,
        },
      },
      {
        breakpoint: 425,
        settings: {
          slidesToShow: 1.2,
        },
      },
    ],
  };
  return (
    <>
      <section>
        <div className="">
          <div className="row">
            {isLoading ? (
              <React.Fragment>
                <div className="col-sm-12">
                  <div className="rl-list-slider">
                    <Slider {...settings}>
                      <div className="pl-0 pr-4 pt-4 pb-4">
                        <MobRestaurantSkeletonOne />
                      </div>
                      <div className="pl-0 pr-4 pt-4 pb-4">
                        <MobRestaurantSkeletonOne />
                      </div>
                    </Slider>
                  </div>
                </div>
              </React.Fragment>
            ) : (
              <React.Fragment>
                {randomDishsList_Data &&
                randomDishsList_Data.dishesList &&
                randomDishsList_Data.dishesList.length > 0 ? (
                  <React.Fragment>
                    {randomDishsList_Data &&
                    randomDishsList_Data.dishesList &&
                    randomDishsList_Data.dishesList.length > 2 ? (
                      <div className="col-sm-12">
                        <div className="rl-list-slider">
                          <Slider {...settings}>
                            {randomDishsList_Data.dishesList &&
                              randomDishsList_Data.dishesList.map(
                                (data, index) => {
                                  return (
                                    <div key={index} className="pr-3">
                                      <Link
                                        to={"/restaurant_dish_info/" + data._id}
                                        style={{
                                          textDecoration: "none",
                                          color: "initial",
                                        }}
                                      >
                                        <MenuBlockMobileComp
                                          dish_name={data.name ? data.name : ""}
                                          dish_image={
                                            data.image ? data.image : ""
                                          }
                                          dish_priceunit={
                                            data.priceUnit ? data.priceUnit : ""
                                          }
                                          dish_price={
                                            data.price ? data.price : "-"
                                          }
                                          dish_description={
                                            data.description
                                              ? data.description
                                              : ""
                                          }
                                          dish_menu={
                                            data.menusDetail
                                              ? data.menusDetail
                                              : []
                                          }
                                          dish_allergy={
                                            data.allergensList
                                              ? data.allergensList
                                              : []
                                          }
                                          dish_new_tag={
                                            data.new ? data.new : false
                                          }
                                          dish_available_tag={
                                            data.available
                                              ? data.available
                                              : false
                                          }
                                        />
                                      </Link>
                                    </div>
                                  );
                                }
                              )}
                          </Slider>
                        </div>
                      </div>
                    ) : (
                      <div className="col-sm-12">
                        <div className="rl-list-slider">
                          {randomDishsList_Data.dishesList &&
                            randomDishsList_Data.dishesList.map(
                              (data, index) => {
                                return (
                                  <div key={index} className="pr-3">
                                    <Link
                                      to={"/restaurant_dish_info/" + data._id}
                                      style={{
                                        textDecoration: "none",
                                        color: "initial",
                                      }}
                                    >
                                      <MenuBlockMobileComp
                                        dish_name={data.name ? data.name : ""}
                                        dish_image={
                                          data.image ? data.image : ""
                                        }
                                        dish_priceunit={
                                          data.priceUnit ? data.priceUnit : ""
                                        }
                                        dish_price={
                                          data.price ? data.price : "-"
                                        }
                                        dish_description={
                                          data.description
                                            ? data.description
                                            : ""
                                        }
                                        dish_menu={
                                          data.menusDetail
                                            ? data.menusDetail
                                            : []
                                        }
                                        dish_allergy={
                                          data.allergensList
                                            ? data.allergensList
                                            : []
                                        }
                                        dish_new_tag={
                                          data.new ? data.new : false
                                        }
                                        dish_available_tag={
                                          data.available
                                            ? data.available
                                            : false
                                        }
                                      />
                                    </Link>
                                  </div>
                                );
                              }
                            )}
                        </div>
                      </div>
                    )}
                  </React.Fragment>
                ) : (
                  <React.Fragment>
                    <p>Something Went Wrong...</p>
                  </React.Fragment>
                )}
              </React.Fragment>
            )}
          </div>
        </div>
      </section>
    </>
  );
};

export default MenuBlockCarouselMobileComp;
