import React from "react";
import "./RestaurantMenuMobileComp.scss";
import MenuAccordianMobileComp from "../MenuAccordianMobileComp/MenuAccordianMobileComp";
import TopPickSliderMobileComp from "../TopPickSliderMobileComp/TopPickSliderMobileComp";
import Slider from "react-slick";
import { NavLink } from "react-router-dom";
import no_Data_Image from "../../../assets/images/no_data_found.png";
import moment from "moment";

const RestaurantMenuMobileComp = ({
  lefttabmenu_data,
  menutab_toppicks,
  all_menudata,
}) => {
  const settings = {
    dots: true,
    infinite: false,
    slidesToShow: 1.2,
    slidesToScroll: 1,
    responsive: [
      {
        breakpoint: 1200,
        settings: {
          slidesToShow: 3.2,
        },
      },
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 3.2,
        },
      },
      {
        breakpoint: 992,
        settings: {
          slidesToShow: 2.2,
        },
      },
      {
        breakpoint: 768,
        settings: {
          slidesToShow: 2.2,
        },
      },
      {
        breakpoint: 600,
        settings: {
          slidesToShow: 1.2,
        },
      },
      {
        breakpoint: 425,
        settings: {
          slidesToShow: 1.2,
        },
      },
    ],
  };
  const selectedMenuData = (all_menudata, id) => {
    return all_menudata && all_menudata.filter((data) => data._id === id);
  };

  var m = moment(new Date());
  var currentTime = m.hour() * 60 + m.minute();

  return (
    <>
      <section>
        <div className="restaurantMenuMobile-content">
          {menutab_toppicks && menutab_toppicks.length > 0 ? (
            <React.Fragment>
              <div className="row flex-column" name="section-1">
                <div className="col-sm-12">
                  <div className="col-sm-12">
                    <h4 className="text-uppercase mb-4 brandon-Bold txt-darkgreen f-14">
                      <b>Top Picks</b>
                    </h4>
                  </div>
                </div>
                {menutab_toppicks && menutab_toppicks.length > 0 ? (
                  <div className="col-sm-12">
                    <div className="col-sm-12 pb-4 mb-2">
                      <React.Fragment>
                        {menutab_toppicks && menutab_toppicks.length >= 2 ? (
                          <React.Fragment>
                            <Slider {...settings}>
                              {menutab_toppicks &&
                                menutab_toppicks.map((data, index) => {
                                  return (
                                    <React.Fragment key={index}>
                                      <div className="">
                                        <NavLink
                                          to={
                                            "/restaurant_dish_info/" + data._id
                                          }
                                          style={{
                                            textDecoration: "none",
                                            color: "initial",
                                          }}
                                        >
                                          <TopPickSliderMobileComp
                                            name={
                                              data.name ? data.name : "Unknown"
                                            }
                                            image={data.image ? data.image : ""}
                                            price={data.price ? data.price : ""}
                                            priceUnit={
                                              data.priceUnit
                                                ? data.priceUnit
                                                : ""
                                            }
                                            // dish_allergy={data.allergensList?data.allergensList:[]}
                                            dish_new_tag={
                                              data.new ? data.new : false
                                            }
                                            dish_available_tag={
                                              data.available
                                                ? data.available
                                                : false
                                            }
                                          />
                                        </NavLink>
                                      </div>
                                    </React.Fragment>
                                  );
                                })}
                            </Slider>
                          </React.Fragment>
                        ) : (
                          <React.Fragment>
                            <div className="row">
                              {menutab_toppicks &&
                                menutab_toppicks.map((data, index) => {
                                  return (
                                    <React.Fragment key={index}>
                                      <div className="col-sm-12">
                                        <NavLink
                                          to={
                                            "/restaurant_dish_info/" + data._id
                                          }
                                          style={{
                                            textDecoration: "none",
                                            color: "initial",
                                          }}
                                        >
                                          <TopPickSliderMobileComp
                                            name={
                                              data.name ? data.name : "Unknown"
                                            }
                                            image={data.image ? data.image : ""}
                                            price={data.price ? data.price : ""}
                                            priceUnit={
                                              data.priceUnit
                                                ? data.priceUnit
                                                : ""
                                            }
                                            dish_new_tag={
                                              data.new ? data.new : false
                                            }
                                            dish_available_tag={
                                              data.available
                                                ? data.available
                                                : false
                                            }
                                          />
                                        </NavLink>
                                      </div>
                                    </React.Fragment>
                                  );
                                })}
                            </div>
                          </React.Fragment>
                        )}
                      </React.Fragment>
                    </div>
                  </div>
                ) : // <img src={no_Data_Image} className="img-fluid" alt="img" loading="lazy"/>
                null}
              </div>

              <div className="row">
                <div className="col-sm-12">
                  <div className="col-sm-12 pb-2">
                    <div
                      className="mt-3 mb-4"
                      style={{
                        borderBottom: "2px #d9d9d9",
                        borderBottomStyle: "dotted",
                      }}
                    ></div>
                  </div>
                </div>
              </div>
            </React.Fragment>
          ) : null}

          {/* <div>
                                            <p>Recommended</p>
                                            <MenuRecommMobileComp/>
                                        </div> */}
          {lefttabmenu_data && lefttabmenu_data.length > 0 ? (
            <React.Fragment>
              {lefttabmenu_data &&
                lefttabmenu_data.map((data, index) => {
                  return (
                    <React.Fragment key={index}>
                      {/* <div className="row">
                                            <div className="col-sm-12">
                                                <div className="col-sm-12">
                                                    <h4 className="brandon-Bold txt-darkgreen text-uppercase f-14">{data.menuName ? data.menuName : ''}</h4>
                                                </div>
                                            </div>
                                        </div> */}
                      <MenuAccordianMobileComp
                        menuname={data.menuName ? data.menuName : "Other"}
                        menuid={data._id}
                        value={selectedMenuData(all_menudata, data._id)}
                        currentTime={currentTime}
                      />
                    </React.Fragment>
                  );
                })}
            </React.Fragment>
          ) : null}
          <div>
            {menutab_toppicks && menutab_toppicks.length > 0 ? null : (
              <React.Fragment>
                {lefttabmenu_data && lefttabmenu_data.length > 0 ? null : (
                  <img src={no_Data_Image} className="img-fluid" alt="img" />
                )}
              </React.Fragment>
            )}
          </div>
        </div>
      </section>
    </>
  );
};

export default RestaurantMenuMobileComp;
