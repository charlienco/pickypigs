import React from "react";
import { Button, Modal } from 'react-bootstrap';
import allergenicon from "../../../assets/images/dishinfo_img/allergen-icon.svg";
// import rightarrow from "../../../assets/images/dishinfo_img/right-arrow.svg";
import closewhite_icon from "../../../assets/images/mobile_imgs/close-white-icon.svg";
import { SERVER_URL } from '../../../shared/constant'
import './AllergyInformationdMobileModal.scss';
import {OverlayTrigger,Tooltip} from "react-bootstrap";

const AllergyInformationdMobileModal = (props) => {
    return (
        <>
            <section >
                <div className="">
                    <Modal
                        {...props}
                        size="lg"
                        aria-labelledby="contained-modal-title-vcenter"
                        centered
                        className="AllergyInformationdMobileModal-modal"
                    >
                        <div className="allergyinformationdmobilemodal-wrapper">
                            <Modal.Header className="border-bottom-0 align-items-center">
                                <Modal.Title className="w-100">
                                    <div className="d-flex align-items-center mb-0 rsd-icontext-content">
                                        <div className="d-flex align-items-center w-100 position-relative">
                                            <img src={allergenicon} alt="" className="img-fluid mr-2 position-absolute" />
                                            <div className="d-flex align-items-center w-100 justify-content-between rsd-allergiesinfomodal-sub">
                                                <span className="pl-4 ml-2 text-left rsd-allergiesinfomodal-name"><b>Allergen In serving</b></span>

                                            </div>
                                        </div>
                                    </div>
                                </Modal.Title>
                            </Modal.Header>
                            <Modal.Body>
                                <div>
                                    <hr className="mt-0 mb-2 hr-botted-style"></hr>
                                </div>

                                <div className="table-responsive rscategory-detail">
                                    <table className="table">
                                        <tbody>
                                            {props.allergydata && props.allergydata.length > 0 ?
                                                <React.Fragment>
                                                    {props.allergydata && props.allergydata.map((data, index) => {
                                                        return (
                                                            <React.Fragment key={index}>
                                                                <tr>
                                                                    <td  className="fw-400 text-right pl-0 pr-0 pt-1 pb-1 border-top-0 whatmeu-types d-flex justify-content-between align-items-center">
                                                                        <b>{data.name ? data.name : "Unknown"}</b>
                                                                        {data && data.image ?
                                                                            <OverlayTrigger placement="bottom" overlay={<Tooltip id={`tooltip-${index}`}>{data.name?data.name:"Unknown"}</Tooltip>} >
                                                                                <div className="whatmenu-list d-flex justify-content-center align-items-center">
                                                                                    <img src={`${SERVER_URL}/${data.image}`} className="img-fluid allergy_icon_image" alt="img"  />
                                                                                </div>
                                                                            </OverlayTrigger>
                                                                            :
                                                                            <OverlayTrigger placement="bottom" overlay={<Tooltip id={`tooltip-${index}`}>{data.name?data.name:"Unknown"}</Tooltip>} >
                                                                                <div className="whatmenu-list d-flex justify-content-center align-items-center">
                                                                                    <img src={allergenicon} className="img-fluid allergy_icon_image" alt="img"  />
                                                                                </div>
                                                                            </OverlayTrigger>
                                                                        }
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td  className="txt-lightgray fw-400 pl-0 pr-0 border-top-0 pt-1 pb-1 text-left">Description</td>
                                                                </tr>
                                                                <tr>
                                                                    <td  className="fw-400 pl-0 pr-0 border-top-0 pt-1 pb-1 text-left allergen-description">{data.description ? data.description : null}</td>
                                                                </tr>
                                                                <div>
                                                                    <hr className="mt-3 mb-2 hr-botted-style"></hr>
                                                                </div>
                                                            </React.Fragment>
                                                        )
                                                    })}
                                                </React.Fragment>
                                                :
                                                <React.Fragment>
                                                    <tr>
                                                        <td  className="fw-400 pl-0 pr-0 border-top-0 pt-1 pb-1 text-left">No Data Available</td>
                                                    </tr>
                                                    <div>
                                                        <hr className="mt-3 mb-2 hr-botted-style"></hr>
                                                    </div>
                                                </React.Fragment>

                                            }

                                        </tbody>
                                    </table>
                                </div>
                                {/* <div>
                        <hr className="mt-0 mb-0"></hr>
                    </div> */}
                                <p className="contributes-detailtxt txt-lightgray">
                                    * The % Daily Value (DV) tells you how much a nutrient in a serving of food contributes to a daily diet. 2,000 calories a day is used for general nutrition advice.
                    </p>
                            </Modal.Body>
                            {/* <Modal.Footer>
                        <Button onClick={props.onHide}>Close</Button>
                    </Modal.Footer> */}
                            <div className="w-100 text-center" style={{ position: 'absolute', bottom: '-5rem' }}>
                                <Button className="modal-close-btn" onClick={props.onHide}>
                                    <img src={closewhite_icon} className="img-fluid" alt="closewhiteicon"/>
                                </Button>
                            </div>
                        </div>
                    </Modal>
                </div>
            </section >
        </>
    )
}

export default AllergyInformationdMobileModal;