import React from "react";
import { Modal } from "react-bootstrap";
import { useDispatch } from "react-redux";
import { Link, useHistory } from "react-router-dom";
import preference_icon from "../../../assets/images/mobile_imgs/preference_icon.svg";
import account_icon from "../../../assets/images/mobile_imgs/account_icon.svg";
import logout_icon from "../../../assets/images/mobile_imgs/logout.svg";
import { logoutUser } from "../../../redux/actions/generalActions";
import "./SubMenuModalMobileComp.scss";

const SubMenuModalMobileComp = (props) => {
  const dispatch = useDispatch();
  const history = useHistory();
  return (
    <>
      <Modal
        {...props}
        size="lg"
        aria-labelledby="contained-modal-title-vcenter"
        className="subMenuModalMobileComp-modal "
        // style={{ bottom:0,flexDirection:'row',alignItems:'flex-end',display:'flex'}}
      >
        {/* <Modal.Header closeButton>
                        <Modal.Title id="contained-modal-title-vcenter">
                        Modal heading
                        </Modal.Title>
                    </Modal.Header> */}
        <Modal.Body style={{}}>
          <div className="subMenuModalMobileComp-comp">
            <div className="subMenuModal_link_button mb-5">
              <Link to="/preference_mobile" className="">
                <span>Preference</span>
                <img
                  width="20px"
                  src={preference_icon}
                  className="img-fluid"
                  loading="lazy"
                  alt="img"
                />
                {/* <Location /> */}
              </Link>
            </div>
            <div className="subMenuModal_link_button mb-5">
              <Link to="/user_detail" className="">
                <span>Account</span>
                <img
                  width="20px"
                  src={account_icon}
                  className="img-fluid"
                  loading="lazy"
                  alt="img"
                />
                {/* <Location /> */}
              </Link>
            </div>
            <div className="subMenuModal_link_button mb-5">
              <button
                className="submenu-logout-btn  d-flex align-items-center justify-content-between w-100 p-0"
                onClick={() => {
                  dispatch(logoutUser(history));
                  props.onHide();
                }}
              >
                <span>LogOut</span>
                <img
                  width="20px"
                  src={logout_icon}
                  className="img-fluid"
                  loading="lazy"
                  alt="img"
                />
              </button>

              {/* <Location /> */}
            </div>
          </div>
        </Modal.Body>
        {/* <Modal.Footer>
                        <Button onClick={props.onHide}>Close</Button>
                    </Modal.Footer> */}
      </Modal>
    </>
  );
};

export default SubMenuModalMobileComp;
