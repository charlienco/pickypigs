import React, { useContext, useState } from "react";
// import walleticon from "../../../assets/images/restaurant-dish/wallet-icon.svg";
import dinner_icon from "../../../assets/images/mobile_imgs/dinner_icon.svg";
// import disc_1 from "../../../assets/images/restaurant/r1.png";
// import disc_2 from "../../../assets/images/restaurant/r2.png";
// import disc_3 from "../../../assets/images/restaurant/r3.png";
// import disc_4 from "../../../assets/images/restaurant/r4.png";

import "./MenuAccordianMobileComp.scss";
import { Accordion, Card } from "react-bootstrap";
import { useAccordionToggle } from "react-bootstrap/AccordionToggle";
import AccordionContext from "react-bootstrap/AccordionContext";
import { NavLink } from "react-router-dom";
import Dummy_Image from "../../../assets/images/restaurant_default.jpg";
import { SERVER_URL } from "../../../shared/constant";
import { OverlayTrigger, Tooltip } from "react-bootstrap";
import moment from "moment";

function ContextAwareToggle({ children, eventKey, callback }) {
  const currentEventKey = useContext(AccordionContext);
  const decoratedOnClick = useAccordionToggle(
    eventKey,
    () => callback && callback(eventKey)
  );

  const isCurrentEventKey = currentEventKey === eventKey;

  return (
    <button
      className="text-uppercase d-flex btn-block f-14"
      style={{
        textAlign: "left",
        backgroundColor: isCurrentEventKey ? "pink" : "lavender",
        color: isCurrentEventKey ? "#2e482b" : "black",
      }}
      onClick={decoratedOnClick}
    >
      {children}
      <div
        className={`accordian-arrow ml-auto ${
          isCurrentEventKey ? "active" : null
        }`}
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="14.063"
          height="8.031"
          viewBox="0 0 14.063 8.031"
        >
          <path
            id="Path_389"
            data-name="Path 389"
            d="M-7-4.687h0l5.438-5.219a.313.313,0,0,1,.5,0l.969.938a.313.313,0,0,1,0,.5L-6.75-2.094A.338.338,0,0,1-7-2a.338.338,0,0,1-.25-.094l-6.656-6.375a.312.312,0,0,1,0-.5l.969-.937a.313.313,0,0,1,.5,0Z"
            transform="translate(14.031 10.031)"
            fill="#232323"
          />
        </svg>
      </div>
    </button>
  );
}

const MenuAccordianMobileComp = ({ menuname, value, currentTime, menuid }) => {
  // eslint-disable-next-line
  const [selectedTab, setSelectedTab] = useState(0);
  let menuFromTime = moment.duration(value[0].timeFrom).asMinutes();

  let menuToTime = moment.duration(value[0].timeTo).asMinutes();

  return (
    <>
      <section>
        <div className="col-sm-12">
          <section className="menuAccordianMobile-content">
            <Accordion
              defaultActiveKey="0"
              className="menuAccordianMobile-accordian"
            >
              <div className="row">
                <div className="col-sm-12">
                  <div className="col-sm-12">
                    <div className="rs-infoblock d-flex align-items-center pb-0">
                      <div className="rs-infoicon mr-3">
                        <img
                          src={dinner_icon}
                          className="img-fluid"
                          alt="Dinner Icon"
                        />
                      </div>
                      <div className="rs-infosubwrap pt-1">
                        <p className="brandon-Medium mb-0">
                          {menuname}
                          <span
                            class={
                              menuFromTime <= currentTime &&
                              currentTime <= menuToTime
                                ? "active-status-mob"
                                : "deactivate-status-mob"
                            }
                          ></span>
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="row">
                <div className="col-sm-12">
                  <div className="col-sm-12">
                    {value && value.length > 0 ? (
                      <React.Fragment>
                        {value &&
                          value[0].categories &&
                          value[0].categories.map((data, index) => {
                            return (
                              <React.Fragment key={index}>
                                <Card>
                                  <React.Fragment>
                                    {index ? (
                                      <div className="custom_dotted_border"></div>
                                    ) : null}
                                  </React.Fragment>
                                  <Accordion.Toggle
                                    as={Card.Header}
                                    onClick={() => {
                                      setSelectedTab(0);
                                    }}
                                    eventKey={`${index}`}
                                    className="txt-darkgreen flex-wrap align-items-center brandon-Bold card-header d-flex justify-content-between"
                                  >
                                    <ContextAwareToggle eventKey={`${index}`}>
                                      {data.name ? data.name : "Unknown"}
                                    </ContextAwareToggle>
                                  </Accordion.Toggle>
                                  <Accordion.Collapse eventKey={`${index}`}>
                                    {data &&
                                    data.subcategories &&
                                    data.subcategories.length > 0 ? (
                                      <React.Fragment>
                                        <Card.Body>
                                          <React.Fragment>
                                            {data &&
                                              data.subcategories &&
                                              data.subcategories
                                                .filter(
                                                  (mydata) => mydata._id == null
                                                )
                                                .map((data2, index2) => {
                                                  return (
                                                    <React.Fragment
                                                      key={index2}
                                                    >
                                                      {data2 &&
                                                      data2.dishes &&
                                                      data2.dishes.length >
                                                        0 ? (
                                                        <React.Fragment>
                                                          <div className="row">
                                                            {data2 &&
                                                              data2.dishes &&
                                                              data2.dishes.map(
                                                                (
                                                                  data3,
                                                                  index3
                                                                ) => {
                                                                  return (
                                                                    <React.Fragment
                                                                      key={
                                                                        index3
                                                                      }
                                                                    >
                                                                      <div className="col-sm-12">
                                                                        <NavLink
                                                                          to={
                                                                            "/restaurant_dish_info/" +
                                                                            data3._id
                                                                          }
                                                                          style={{
                                                                            textDecoration:
                                                                              "none",
                                                                            color:
                                                                              "initial",
                                                                          }}
                                                                        >
                                                                          <div className="d-flex mb-3">
                                                                            <span
                                                                              class={
                                                                                menuFromTime <=
                                                                                  currentTime &&
                                                                                currentTime <=
                                                                                  menuToTime
                                                                                  ? "active-status-mob"
                                                                                  : "deactivate-status-mob"
                                                                              }
                                                                            ></span>
                                                                            <div className="mr-3 dishimg-block">
                                                                              {data3.image ? (
                                                                                <img
                                                                                  src={`${SERVER_URL}/${data3.image}`}
                                                                                  className={`img-fluid ${
                                                                                    data3.available
                                                                                      ? null
                                                                                      : "gray_shadow"
                                                                                  }`}
                                                                                  alt={
                                                                                    data3.name
                                                                                      ? data3.name
                                                                                      : "Not Available"
                                                                                  }
                                                                                />
                                                                              ) : (
                                                                                <img
                                                                                  src={
                                                                                    Dummy_Image
                                                                                  }
                                                                                  className={`img-fluid ${
                                                                                    data3.available
                                                                                      ? null
                                                                                      : "gray_shadow"
                                                                                  }`}
                                                                                  alt={
                                                                                    data3.name
                                                                                      ? data3.name
                                                                                      : "Not Available"
                                                                                  }
                                                                                />
                                                                              )}
                                                                              {data3.available &&
                                                                              data3.available ? null : (
                                                                                <label className="available-label">
                                                                                  Pigged
                                                                                  Out
                                                                                </label>
                                                                              )}
                                                                            </div>
                                                                            <div className="dish-details">
                                                                              <div>
                                                                                <div className="pt-0">
                                                                                  <div
                                                                                    className={`d-flex justify-content-between align-items-center ${
                                                                                      data3.available
                                                                                        ? null
                                                                                        : "gray_shadow"
                                                                                    }`}
                                                                                  >
                                                                                    <div className="d-flex justify-content-between align-items-center">
                                                                                      <p className="dish-title disn_name mb-0 mt-0">
                                                                                        {data3.name
                                                                                          ? data3.name
                                                                                          : "Not Available"}
                                                                                      </p>
                                                                                      <div>
                                                                                        {data3.new &&
                                                                                        data3.new ? (
                                                                                          <label className="newdish-label">
                                                                                            New
                                                                                          </label>
                                                                                        ) : null}
                                                                                      </div>
                                                                                    </div>
                                                                                  </div>
                                                                                  <div className="dish-price position-relative">
                                                                                    <p className="mb-0 mt-0">
                                                                                      {data3.priceUnit
                                                                                        ? data3.priceUnit
                                                                                        : "$"}
                                                                                      &nbsp;
                                                                                      {data3.price
                                                                                        ? parseFloat(
                                                                                            data3.price
                                                                                          ).toFixed(
                                                                                            2
                                                                                          )
                                                                                        : "-"}
                                                                                    </p>
                                                                                  </div>
                                                                                  {/* {data3.available&&data3.available?null:<label className="available-label">Pigged Out</label>} */}
                                                                                  {/* <div className="pt-2 mt-2">
                                                                                                                                                            <p className="dish-info">{data3.description?data3.description:"No Description"}</p>
                                                                                                                                                    </div> */}
                                                                                  <div className="">
                                                                                    <p className="txt-lightgray mb-0 d-flex flex-wrap align-items-center mt-1 dish-tag">
                                                                                      {data3.customisable && (
                                                                                        <span className="cuisine-label">
                                                                                          Customizable
                                                                                        </span>
                                                                                      )}
                                                                                      {data3 &&
                                                                                      data3.allergenList &&
                                                                                      data3
                                                                                        .allergenList
                                                                                        .length >
                                                                                        0 ? (
                                                                                        <React.Fragment>
                                                                                          {data3 &&
                                                                                            data3.allergenList &&
                                                                                            data3.allergenList
                                                                                              .slice(
                                                                                                0,
                                                                                                1
                                                                                              )
                                                                                              .map(
                                                                                                (
                                                                                                  allergy,
                                                                                                  index
                                                                                                ) => {
                                                                                                  return (
                                                                                                    <React.Fragment
                                                                                                      key={
                                                                                                        index
                                                                                                      }
                                                                                                    >
                                                                                                      <OverlayTrigger
                                                                                                        placement="bottom"
                                                                                                        overlay={
                                                                                                          <Tooltip
                                                                                                            id={`tooltip-${index}`}
                                                                                                          >
                                                                                                            {
                                                                                                              allergy.name
                                                                                                            }
                                                                                                          </Tooltip>
                                                                                                        }
                                                                                                      >
                                                                                                        <div className="mob_preference_icon d-flex justify-content-center align-items-center">
                                                                                                          <img
                                                                                                            src={`${SERVER_URL}/${allergy.image}`}
                                                                                                            className="img-fluid "
                                                                                                            alt="img"
                                                                                                          />
                                                                                                        </div>
                                                                                                      </OverlayTrigger>
                                                                                                    </React.Fragment>
                                                                                                  );
                                                                                                }
                                                                                              )}
                                                                                        </React.Fragment>
                                                                                      ) : null}

                                                                                      {data3 &&
                                                                                      data3.dietaryList &&
                                                                                      data3
                                                                                        .dietaryList
                                                                                        .length >
                                                                                        0 ? (
                                                                                        <React.Fragment>
                                                                                          {data3 &&
                                                                                            data3.dietaryList &&
                                                                                            data3.dietaryList
                                                                                              .slice(
                                                                                                0,
                                                                                                1
                                                                                              )
                                                                                              .map(
                                                                                                (
                                                                                                  dietry,
                                                                                                  index
                                                                                                ) => {
                                                                                                  return (
                                                                                                    <React.Fragment
                                                                                                      key={
                                                                                                        index
                                                                                                      }
                                                                                                    >
                                                                                                      <OverlayTrigger
                                                                                                        placement="bottom"
                                                                                                        overlay={
                                                                                                          <Tooltip
                                                                                                            id={`tooltip-${index}`}
                                                                                                          >
                                                                                                            {
                                                                                                              dietry.name
                                                                                                            }
                                                                                                          </Tooltip>
                                                                                                        }
                                                                                                      >
                                                                                                        <div className="mob_preference_icon d-flex justify-content-center align-items-center">
                                                                                                          <img
                                                                                                            src={`${SERVER_URL}/${dietry.image}`}
                                                                                                            className="img-fluid "
                                                                                                            alt="img"
                                                                                                          />
                                                                                                        </div>
                                                                                                      </OverlayTrigger>
                                                                                                    </React.Fragment>
                                                                                                  );
                                                                                                }
                                                                                              )}
                                                                                        </React.Fragment>
                                                                                      ) : null}
                                                                                      {(data3 &&
                                                                                      data3.allergenList &&
                                                                                      data3
                                                                                        .allergenList
                                                                                        .length >=
                                                                                        1
                                                                                        ? data3
                                                                                            .allergenList
                                                                                            .length -
                                                                                          1
                                                                                        : 0) +
                                                                                        (data3 &&
                                                                                        data3.dietaryList &&
                                                                                        data3
                                                                                          .dietaryList
                                                                                          .length >=
                                                                                          1
                                                                                          ? data3
                                                                                              .dietaryList
                                                                                              .length -
                                                                                            1
                                                                                          : 0) >
                                                                                      0 ? (
                                                                                        <OverlayTrigger
                                                                                          placement="bottom"
                                                                                          overlay={
                                                                                            <Tooltip
                                                                                              id={`tooltipOne`}
                                                                                            >
                                                                                              {(
                                                                                                data3 &&
                                                                                                data3.allergenList &&
                                                                                                data3.allergenList.slice(
                                                                                                  1
                                                                                                )
                                                                                              )
                                                                                                .concat(
                                                                                                  data3 &&
                                                                                                    data3.dietaryList &&
                                                                                                    data3.dietaryList.slice(
                                                                                                      1
                                                                                                    )
                                                                                                )
                                                                                                .map(
                                                                                                  (
                                                                                                    data2,
                                                                                                    index2
                                                                                                  ) => {
                                                                                                    return (
                                                                                                      <React.Fragment
                                                                                                        key={
                                                                                                          index2
                                                                                                        }
                                                                                                      >
                                                                                                        {index2
                                                                                                          ? ", "
                                                                                                          : ""}
                                                                                                        {
                                                                                                          data2.name
                                                                                                        }
                                                                                                      </React.Fragment>
                                                                                                    );
                                                                                                  }
                                                                                                )}
                                                                                            </Tooltip>
                                                                                          }
                                                                                        >
                                                                                          <div className="mob_preference_more d-flex justify-content-center align-items-center">
                                                                                            <small>
                                                                                              +
                                                                                              {(data3 &&
                                                                                              data3.allergenList &&
                                                                                              data3
                                                                                                .allergenList
                                                                                                .length >=
                                                                                                1
                                                                                                ? data3
                                                                                                    .allergenList
                                                                                                    .length -
                                                                                                  1
                                                                                                : 0) +
                                                                                                (data3 &&
                                                                                                data3.dietaryList &&
                                                                                                data3
                                                                                                  .dietaryList
                                                                                                  .length >=
                                                                                                  1
                                                                                                  ? data3
                                                                                                      .dietaryList
                                                                                                      .length -
                                                                                                    1
                                                                                                  : 0)}{" "}
                                                                                              <br></br>
                                                                                              More
                                                                                            </small>
                                                                                          </div>
                                                                                        </OverlayTrigger>
                                                                                      ) : null}
                                                                                    </p>
                                                                                  </div>
                                                                                </div>
                                                                              </div>
                                                                              {/* <div className="d-block">
                                                                                                                                            <hr className="mt-0 mb-0"></hr>
                                                                                                                                        </div> */}
                                                                            </div>
                                                                          </div>
                                                                        </NavLink>
                                                                      </div>
                                                                    </React.Fragment>
                                                                  );
                                                                }
                                                              )}
                                                          </div>
                                                        </React.Fragment>
                                                      ) : (
                                                        <p>no Dish Available</p>
                                                      )}
                                                    </React.Fragment>
                                                  );
                                                })}
                                          </React.Fragment>

                                          <React.Fragment>
                                            {/* <div className="d-flex sub-cate">
                                                                                        {data && data.subcategories && data.subcategories.map((data2, index2) => {
                                                                                            return (
                                                                                                <React.Fragment key={index2}>
                                                                                                    <button onClick={() => { setSelectedTab(index2); }} className={`rstab-btn mr-5 ${selectedTab == index2 ? 'active' : null}`}  >{data2.name}</button>
                                                                                                </React.Fragment>
                                                                                            )
                                                                                        })}
                                                                                    </div> */}
                                            {data &&
                                              data.subcategories &&
                                              data.subcategories
                                                .filter(
                                                  (mydata) =>
                                                    mydata._id !== null
                                                )
                                                .map((data2, index2) => {
                                                  return (
                                                    <React.Fragment
                                                      key={index2}
                                                    >
                                                      {data2 &&
                                                      data2.dishes &&
                                                      data2.dishes.length >
                                                        0 ? (
                                                        <React.Fragment>
                                                          <div className="row">
                                                            <p
                                                              className="brandon-Regular ml-3 mb-2 txt-lightgray"
                                                              style={{
                                                                textTransform:
                                                                  "capitalize",
                                                              }}
                                                            >
                                                              {data2.name
                                                                ? data2.name
                                                                : " "}
                                                            </p>
                                                            {data2 &&
                                                              data2.dishes &&
                                                              data2.dishes.map(
                                                                (
                                                                  data3,
                                                                  index3
                                                                ) => {
                                                                  return (
                                                                    <React.Fragment
                                                                      key={
                                                                        index3
                                                                      }
                                                                    >
                                                                      <div className="col-sm-12">
                                                                        <NavLink
                                                                          to={
                                                                            "/restaurant_dish_info/" +
                                                                            data3._id
                                                                          }
                                                                          style={{
                                                                            textDecoration:
                                                                              "none",
                                                                            color:
                                                                              "initial",
                                                                          }}
                                                                        >
                                                                          <div className="d-flex mb-3">
                                                                            <span
                                                                              class={
                                                                                menuFromTime <=
                                                                                  currentTime &&
                                                                                currentTime <=
                                                                                  menuToTime
                                                                                  ? "active-status-mob"
                                                                                  : "deactivate-status-mob"
                                                                              }
                                                                            ></span>

                                                                            <div className="mr-3 dishimg-block">
                                                                              {data3.image ? (
                                                                                <img
                                                                                  src={`${SERVER_URL}/${data3.image}`}
                                                                                  className={`img-fluid ${
                                                                                    data3.available
                                                                                      ? null
                                                                                      : "gray_shadow"
                                                                                  }`}
                                                                                  alt={
                                                                                    data3.name
                                                                                      ? data3.name
                                                                                      : "Not Available"
                                                                                  }
                                                                                />
                                                                              ) : (
                                                                                <img
                                                                                  src={
                                                                                    Dummy_Image
                                                                                  }
                                                                                  className={`img-fluid ${
                                                                                    data3.available
                                                                                      ? null
                                                                                      : "gray_shadow"
                                                                                  }`}
                                                                                  alt={
                                                                                    data3.name
                                                                                      ? data3.name
                                                                                      : "Not Available"
                                                                                  }
                                                                                />
                                                                              )}
                                                                              {data3.available &&
                                                                              data3.available ? null : (
                                                                                <label className="available-label">
                                                                                  Pigged
                                                                                  Out
                                                                                </label>
                                                                              )}
                                                                            </div>
                                                                            <div className="dish-details">
                                                                              <div className="pt-0">
                                                                                <div
                                                                                  className={`d-flex justify-content-between align-items-center ${
                                                                                    data3.available
                                                                                      ? null
                                                                                      : "gray_shadow"
                                                                                  }`}
                                                                                >
                                                                                  <div className="d-flex justify-content-between align-items-start">
                                                                                    <p className="dish-title disn_name mb-0 mt-0">
                                                                                      {data3.name
                                                                                        ? data3.name
                                                                                        : "Not Available"}
                                                                                    </p>
                                                                                    <div>
                                                                                      {data3.new &&
                                                                                      data3.new ? (
                                                                                        <label className="newdish-label">
                                                                                          New
                                                                                        </label>
                                                                                      ) : null}
                                                                                    </div>
                                                                                  </div>
                                                                                </div>
                                                                                <div className="dish-price position-relative">
                                                                                  <p className="mb-0 mt-0">
                                                                                    {data3.priceUnit
                                                                                      ? data3.priceUnit
                                                                                      : "$"}
                                                                                    &nbsp;
                                                                                    {data3.price
                                                                                      ? parseFloat(
                                                                                          data3.price
                                                                                        ).toFixed(
                                                                                          2
                                                                                        )
                                                                                      : "-"}
                                                                                  </p>
                                                                                </div>
                                                                                {/* {data3.available&&data3.available?null:<label className="available-label">Pigged Out</label>} */}
                                                                                {/* <div className="pt-2 mt-2">
                                                                                                                                                <p className="dish-info">{data3.description?data3.description:"No Description"}</p>
                                                                                                                                            </div> */}
                                                                                <div className="">
                                                                                  <p className="txt-lightgray mb-0 d-flex flex-wrap align-items-center mt-1 dish-tag">
                                                                                    {data3.customisable && (
                                                                                      <span className="cuisine-label">
                                                                                        Customizable
                                                                                      </span>
                                                                                    )}
                                                                                    {data3 &&
                                                                                    data3.allergenList &&
                                                                                    data3
                                                                                      .allergenList
                                                                                      .length >
                                                                                      0 ? (
                                                                                      <React.Fragment>
                                                                                        {data3 &&
                                                                                          data3.allergenList &&
                                                                                          data3.allergenList
                                                                                            .slice(
                                                                                              0,
                                                                                              1
                                                                                            )
                                                                                            .map(
                                                                                              (
                                                                                                allergy,
                                                                                                index
                                                                                              ) => {
                                                                                                return (
                                                                                                  <React.Fragment
                                                                                                    key={
                                                                                                      index
                                                                                                    }
                                                                                                  >
                                                                                                    <OverlayTrigger
                                                                                                      placement="bottom"
                                                                                                      overlay={
                                                                                                        <Tooltip
                                                                                                          id={`tooltip-${index}`}
                                                                                                        >
                                                                                                          {
                                                                                                            allergy.name
                                                                                                          }
                                                                                                        </Tooltip>
                                                                                                      }
                                                                                                    >
                                                                                                      <div className="mob_preference_icon d-flex justify-content-center align-items-center">
                                                                                                        <img
                                                                                                          src={`${SERVER_URL}/${allergy.image}`}
                                                                                                          className="img-fluid "
                                                                                                          alt="img"
                                                                                                        />
                                                                                                      </div>
                                                                                                    </OverlayTrigger>
                                                                                                  </React.Fragment>
                                                                                                );
                                                                                              }
                                                                                            )}
                                                                                      </React.Fragment>
                                                                                    ) : null}

                                                                                    {data3 &&
                                                                                    data3.dietaryList &&
                                                                                    data3
                                                                                      .dietaryList
                                                                                      .length >
                                                                                      0 ? (
                                                                                      <React.Fragment>
                                                                                        {data3 &&
                                                                                          data3.dietaryList &&
                                                                                          data3.dietaryList
                                                                                            .slice(
                                                                                              0,
                                                                                              1
                                                                                            )
                                                                                            .map(
                                                                                              (
                                                                                                dietry,
                                                                                                index
                                                                                              ) => {
                                                                                                return (
                                                                                                  <React.Fragment
                                                                                                    key={
                                                                                                      index
                                                                                                    }
                                                                                                  >
                                                                                                    <OverlayTrigger
                                                                                                      placement="bottom"
                                                                                                      overlay={
                                                                                                        <Tooltip
                                                                                                          id={`tooltip-${index}`}
                                                                                                        >
                                                                                                          {
                                                                                                            dietry.name
                                                                                                          }
                                                                                                        </Tooltip>
                                                                                                      }
                                                                                                    >
                                                                                                      <div className="mob_preference_icon d-flex justify-content-center align-items-center">
                                                                                                        <img
                                                                                                          src={`${SERVER_URL}/${dietry.image}`}
                                                                                                          className="img-fluid "
                                                                                                          alt="img"
                                                                                                        />
                                                                                                      </div>
                                                                                                    </OverlayTrigger>
                                                                                                  </React.Fragment>
                                                                                                );
                                                                                              }
                                                                                            )}
                                                                                      </React.Fragment>
                                                                                    ) : null}
                                                                                    {(data3 &&
                                                                                    data3.allergenList &&
                                                                                    data3
                                                                                      .allergenList
                                                                                      .length >=
                                                                                      1
                                                                                      ? data3
                                                                                          .allergenList
                                                                                          .length -
                                                                                        1
                                                                                      : 0) +
                                                                                      (data3 &&
                                                                                      data3.dietaryList &&
                                                                                      data3
                                                                                        .dietaryList
                                                                                        .length >=
                                                                                        1
                                                                                        ? data3
                                                                                            .dietaryList
                                                                                            .length -
                                                                                          1
                                                                                        : 0) >
                                                                                    0 ? (
                                                                                      <OverlayTrigger
                                                                                        placement="bottom"
                                                                                        overlay={
                                                                                          <Tooltip
                                                                                            id={`tooltipOne`}
                                                                                          >
                                                                                            {(
                                                                                              data3 &&
                                                                                              data3.allergenList &&
                                                                                              data3.allergenList.slice(
                                                                                                1
                                                                                              )
                                                                                            )
                                                                                              .concat(
                                                                                                data3 &&
                                                                                                  data3.dietaryList &&
                                                                                                  data3.dietaryList.slice(
                                                                                                    1
                                                                                                  )
                                                                                              )
                                                                                              .map(
                                                                                                (
                                                                                                  data2,
                                                                                                  index2
                                                                                                ) => {
                                                                                                  return (
                                                                                                    <React.Fragment
                                                                                                      key={
                                                                                                        index2
                                                                                                      }
                                                                                                    >
                                                                                                      {index2
                                                                                                        ? ", "
                                                                                                        : ""}
                                                                                                      {
                                                                                                        data2.name
                                                                                                      }
                                                                                                    </React.Fragment>
                                                                                                  );
                                                                                                }
                                                                                              )}
                                                                                          </Tooltip>
                                                                                        }
                                                                                      >
                                                                                        <div className="mob_preference_more d-flex justify-content-center align-items-center">
                                                                                          <small>
                                                                                            +
                                                                                            {(data3 &&
                                                                                            data3.allergenList &&
                                                                                            data3
                                                                                              .allergenList
                                                                                              .length >=
                                                                                              1
                                                                                              ? data3
                                                                                                  .allergenList
                                                                                                  .length -
                                                                                                1
                                                                                              : 0) +
                                                                                              (data3 &&
                                                                                              data3.dietaryList &&
                                                                                              data3
                                                                                                .dietaryList
                                                                                                .length >=
                                                                                                1
                                                                                                ? data3
                                                                                                    .dietaryList
                                                                                                    .length -
                                                                                                  1
                                                                                                : 0)}{" "}
                                                                                            <br></br>
                                                                                            More
                                                                                          </small>
                                                                                        </div>
                                                                                      </OverlayTrigger>
                                                                                    ) : null}
                                                                                  </p>
                                                                                </div>
                                                                              </div>
                                                                            </div>
                                                                          </div>
                                                                        </NavLink>
                                                                      </div>
                                                                    </React.Fragment>
                                                                  );
                                                                }
                                                              )}
                                                          </div>
                                                        </React.Fragment>
                                                      ) : (
                                                        <p>no Dish Available</p>
                                                      )}
                                                    </React.Fragment>
                                                  );
                                                })}
                                          </React.Fragment>
                                        </Card.Body>
                                      </React.Fragment>
                                    ) : (
                                      <p>no Sub Categories</p>
                                    )}
                                  </Accordion.Collapse>
                                </Card>
                              </React.Fragment>
                            );
                          })}
                      </React.Fragment>
                    ) : (
                      <p>no Categories</p>
                    )}
                  </div>
                </div>
              </div>
            </Accordion>
          </section>
        </div>
      </section>
    </>
  );
};

export default MenuAccordianMobileComp;
