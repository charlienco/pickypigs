import React from "react";
import SingleGalleryMobileComp from "../SingleGalleryMobileComp/SingleGalleryMobileComp";
import house_icon from "../../../assets/images/mobile_imgs/house_icon.svg";
import dinner_icon from "../../../assets/images/mobile_imgs/dinner_icon_dark.svg";

import "./RestaurantGalleeryMobileComp.scss";

const RestaurantGalleeryMobileComp = (props) => {
  return (
    <>
      <section>
        <div className="">
          <div className="row">
            <div className="col-12 mb-3">
              <SingleGalleryMobileComp
                food={props.food}
                icon={house_icon}
                heading={"Restaurant Ambience"}
              />
            </div>
          </div>
          <div className="row">
            <div className="col-12 mb-3">
              <SingleGalleryMobileComp
                food={props.ambience}
                icon={dinner_icon}
                heading={"Foods"}
              />
            </div>
          </div>
          {/* <div className="row">
                    <div className="col-12 mb-3">
                        <SingleGalleryMobileComp icon={Diningtable} heading={"Videos"}/>
                    </div>
                </div> */}
        </div>
      </section>
    </>
  );
};

export default RestaurantGalleeryMobileComp;
