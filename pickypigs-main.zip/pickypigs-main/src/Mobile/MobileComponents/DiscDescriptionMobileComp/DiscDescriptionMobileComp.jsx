import React from "react";
// import restaurant_img from "../../../assets/images/restaurant/r4.png";
// import whatmenuicon1 from "../../../assets/images/micon1.svg";
// import whatmenuicon2 from "../../../assets/images/micon2.svg";
// import whatmenuicon3 from "../../../assets/images/micon3.svg";
import "./DiscDescriptionMobileComp.scss";
import { SERVER_URL } from "../../../shared/constant";
import dishimg1 from "../../../assets/images/dummy_img.jpg";
import leftarrow_white from "../../../assets/images/mobile_imgs/left-white-arrow.svg";
import { Link, useHistory } from "react-router-dom";

import OverlayTrigger from "react-bootstrap/OverlayTrigger";
import Tooltip from "react-bootstrap/Tooltip";

const DiscDescriptionMobileComp = (props) => {
  const history = useHistory();

  return (
    <>
      <section className="DiscDescriptionMobileComp-comp">
        <div style={{ position: "relative" }} className="row">
          <div className="col-sm-12 position-relative pl-0 pr-0">
            <div className="dishinfo-img">
              {props.itemimage && props.itemimage ? (
                <img
                  src={`${SERVER_URL}/${props.itemimage}`}
                  alt="Restaurant_image"
                  className="img-fluid w-100"
                />
              ) : (
                <img
                  src={dishimg1}
                  alt="Restaurant_image"
                  className="img-fluid w-100"
                />
              )}
              {props.dish_new_tag && props.dish_new_tag ? (
                <label className="newdish-label">New</label>
              ) : null}
            </div>
          </div>

          <div className="restaurant-navbar">
            <div
              className="restaurant-leftslide"
              type="button"
              onClick={() => {
                history.goBack();
              }}
            >
              <img
                src={leftarrow_white}
                alt="leftarrow_white"
                className="img-fluid"
              />
            </div>
            <div className="restaurant-rigthslide d-flex align-items-center">
              {/* <div className="restaurant-favorite-icon">
                                <img src={favorite_icon} className="img-fluid" />
                            </div>
                            <div className="restaurant-share-icon ml-4">
                                <img src={share_icon} className="img-fluid" />
                            </div> */}
            </div>
          </div>

          <div
            style={{ position: "absolute", bottom: "3.5rem" }}
            className="d-flex justify-content-between flex-column  w-100"
          >
            <div className="col-sm-12">
              <div className="row">
                <div className="col-sm-12">
                  <div className="col-sm-12">
                    <div className="restaurant-mob-details">
                      <h4 className="text-white">{props.name}</h4>
                      <p className="text-white d-flex align-items-center mb-1">
                        Price : {props.priceunit ? props.priceunit : "$"}
                        {props.price
                          ? parseFloat(props.price).toFixed(2)
                          : "Na"}
                      </p>
                      {/* <p className="text-white d-flex align-items-center mb-0">
                                               <span >Lunch</span><span className="d-inline-block mr-2 ml-2">.</span><span className="d-inline-block mr-2">Dinner</span>
                                            </p> */}
                      {/*Breadcrumb Start*/}
                      <div className="breadcrumb-wrapper">
                        <nav aria-label="breadcrumb">
                          <ol className="breadcrumb-mob">
                            <li
                              className="breadcrumb-item text-capitalize"
                              aria-current="page"
                            >
                              <Link to={"/restaurant/" + props.restaurantId}>
                                {props.restaurantName && props.restaurantName
                                  ? props.restaurantName && props.restaurantName
                                  : "Unknown"}
                              </Link>
                            </li>
                          </ol>
                        </nav>
                      </div>
                      {/*Breadcrumb Ends*/}
                    </div>
                  </div>
                </div>
              </div>
            </div>
            {/* <div className="dish_desc_rounde"></div> */}
          </div>
        </div>
        <div>
          <div className="row mb-3">
            <div className="col-sm-12">
              <div className="restaurant-mob-intro pt-4 pb-2">
                <div className="col-sm-12">
                  <p className="txt-lightgray f-14 mb-0">{props.description}</p>
                </div>
              </div>
            </div>
          </div>
          <div className="row">
            <div className="col-sm-12">
              <div className="col-sm-12">
                <div className="whatmeu-types d-flex flex-wrap">
                  {props.allergydetail && props.allergydetail.length > 0 ? (
                    <React.Fragment>
                      {props.allergydetail &&
                        props.allergydetail.map((data, index) => {
                          return (
                            <React.Fragment key={index}>
                              <OverlayTrigger
                                placement="bottom"
                                overlay={
                                  <Tooltip id={`tooltip-${index}`}>
                                    {data.name}
                                  </Tooltip>
                                }
                              >
                                <div className="whatmenu-list mr-3 mb-3 d-flex justify-content-center align-items-center">
                                  <img
                                    src={`${SERVER_URL}/${data.image}`}
                                    className="img-fluid allergy_icon_image"
                                    alt="img"
                                  />
                                </div>
                              </OverlayTrigger>
                            </React.Fragment>
                          );
                        })}
                    </React.Fragment>
                  ) : null}
                  {props.diateryDetail && props.diateryDetail.length > 0 ? (
                    <React.Fragment>
                      {props.diateryDetail &&
                        props.diateryDetail.map((data, index) => {
                          return (
                            <React.Fragment key={index}>
                              <OverlayTrigger
                                placement="bottom"
                                overlay={
                                  <Tooltip id={`tooltip-${index}`}>
                                    {data.name}
                                  </Tooltip>
                                }
                              >
                                {/* <div className="whatmenu-text mr-3 mb-3 d-flex justify-content-center align-items-center" >
                                                                    <p className="">{data.name}</p>
                                                                </div> */}
                                <div className="whatmenu-list mr-3 mb-3 d-flex justify-content-center align-items-center">
                                  <img
                                    src={`${SERVER_URL}/${data.image}`}
                                    className="img-fluid allergy_icon_image"
                                    alt="img"
                                  />
                                </div>
                              </OverlayTrigger>
                            </React.Fragment>
                          );
                        })}
                    </React.Fragment>
                  ) : null}
                  {props.lifestyleDetail && props.lifestyleDetail.length > 0 ? (
                    <React.Fragment>
                      {props.lifestyleDetail &&
                        props.lifestyleDetail.map((data, index) => {
                          return (
                            <React.Fragment key={index}>
                              <OverlayTrigger
                                placement="bottom"
                                overlay={
                                  <Tooltip id={`tooltip-${index}`}>
                                    {data.name}
                                  </Tooltip>
                                }
                              >
                                {/* <div className="whatmenu-text mr-3 mb-3 d-flex justify-content-center align-items-center" >
                                                                    <p className="">{data.name}</p>
                                                                </div> */}
                                <div className="whatmenu-list mr-3 mb-3 d-flex justify-content-center align-items-center">
                                  <img
                                    src={`${SERVER_URL}/${data.image}`}
                                    className="img-fluid allergy_icon_image"
                                    alt="img"
                                  />
                                </div>
                              </OverlayTrigger>
                            </React.Fragment>
                          );
                        })}
                    </React.Fragment>
                  ) : null}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default DiscDescriptionMobileComp;
