import React from "react";
import img1 from "../../../assets/images/restaurant/r2.png";
import graystar from "../../../assets/images/mobile_imgs/gray-star.svg";
import './SingleReviewMobileComp.scss';

const SingleReviewMobileComp = () => {
    return (
        <>
            <section>
                <div className="row">
                    <div className="col-sm-12">
                        <div className="col-sm-12">
                            <div className="singleReviewMobile-content">
                                <div className="rs-infoblock">
                                    <div>
                                        <div className="media">
                                            <div className="rs-review-mob-tab-img mr-3">
                                                <img src={img1} className="img-fluid rounded-circle" alt="user_img" loading="lazy"  />
                                            </div>
                                            <div className="media-body">
                                                <h5 className="mt-0">Joe</h5>
                                                <p className="d-flex align-items-center">
                                                    <img src={graystar} width="100px" className="img-fluid mr-2" loading="lazy" alt="img"/>
                                                    <span className="txt-lightgray f-14">4/5</span>
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                    <p className="rs-review-intro txt-lightgray f-14">Lorem ipsum, dolor sit amet consectetur adipisicing elit. Numquam nesciunt optio voluptatum nihil atque? Quasi odio ut saepe non neque.</p>
                                    <div className="border-top rs-review-time">
                                        <p className="pt-3 f-11 mb-0">30 Minutes ago</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </>
    )
}

export default SingleReviewMobileComp;