import React from "react";

import { SERVER_URL } from "../../../shared/constant";
import Dummy_Image from "../../../assets/images/restaurant_default.jpg"
// import Dummy_Icon from "../../../assets/images/dummy_icon.svg"
import './TopPickSliderMobileComp.scss';



// let defaultIcon=[{name:"Unknown",image:Dummy_Icon}]

const TopPickSliderMobileComp=({name,price,priceUnit,image,dish_new_tag,dish_available_tag})=>{
   
    return(
        <>
        <section>
            <div className="">
               
                             <div >
                                    <div className="top-picks-wrapper mr-3" style={{position:'relative'}}>
                                        {image?
                                            <img src={`${SERVER_URL}/${image}`} alt={name?name:'disc_img'} className={`img-fluid w-100 ${dish_available_tag?null:"gray_shadow"}`} loading="lazy"/>
                                        :
                                            <img src={Dummy_Image} alt={name?name:'disc_img'} className={`img-fluid w-100 ${dish_available_tag?null:"gray_shadow"}`} loading="lazy"/>
                                        }
                                        {dish_new_tag&&dish_new_tag?
                                            <label className={`newdish-label ${dish_available_tag?null:"gray_shadow"}`}>New</label>
                                        :
                                            null
                                        }
                                        {dish_available_tag&&dish_available_tag?
                                            null
                                        :
                                            <label className="available-label">Pigged Out</label>
                                        }
                                        <div className="pl-3 pr-3" style={{position:'absolute',bottom:15}}>
                                            <h3 className="top-picks-name mb-1">{name?name:'Unknown'}</h3>
                                            <p className="top-picks-product-name mb-0">{priceUnit?priceUnit:'$'} {price?parseFloat(price).toFixed(2):'00.00'}</p>
                                        </div>
                                        {/* <div className="whatmeu-types d-flex flex-wrap">
                                            {dish_allergy&&dish_allergy.length>0?
                                                <React.Fragment>
                                                    {dish_allergy && dish_allergy.length>3?
                                                        <React.Fragment>
                                                            {dish_allergy && dish_allergy.slice(0,3).map((data, index) => {
                                                                return (
                                                                    <React.Fragment key={index}>
                                                                        <div className="whatmenu-list mr-3 mb-2 d-flex justify-content-center align-items-center">
                                                                            <img src={`${SERVER_URL}/${data.image}`} alt={"icon"} className="img-fluid" title={data.name?data.name:'unknown'} />
                                                                        </div>
                                                                    </React.Fragment>
                                                                )
                                                            })}
                                                            <div className="whatmenu-list mr-3 mb-2 d-flex justify-content-center align-items-center">
                                                                <small style={{textAlign:"center",fontSize:10,flexWrap:"wrap"}}>+{dish_allergy && dish_allergy.length-3} More</small>
                                                            </div>
                                                        </React.Fragment>
                                                    :
                                                        <React.Fragment>
                                                            {dish_allergy && dish_allergy.map((data, index) => {
                                                                return (
                                                                    <React.Fragment key={index}>
                                                                        <div className="whatmenu-list mr-3 mb-2 d-flex justify-content-center align-items-center">
                                                                            <img src={`${SERVER_URL}/${data.image}`} alt={"icon"} className="img-fluid" title={data.name?data.name:'unknown'} />
                                                                        </div>
                                                                    </React.Fragment>
                                                                )
                                                            })}
                                                        </React.Fragment>
                                                    }
                                                
                                                </React.Fragment>
                                                :
                                                <React.Fragment>
                                                    {defaultIcon&&defaultIcon.map((data,index)=>{
                                                        return(
                                                            <React.Fragment key={index}>
                                                                <div className="whatmenu-list mr-3 mb-2 d-flex justify-content-center align-items-center">
                                                                    <img src={data.image} alt={"icon"} className="img-fluid" title={data.name} />
                                                                </div>
                                                            </React.Fragment>
                                                        )
                                                    })}
                                                </React.Fragment>
                                            }
                                        </div> */}
                                    </div>    
                             </div>
                      
            </div>
            {/* <br></br>
            <br></br>
            <br></br> */}
        </section>
        </>
    )
}

export default TopPickSliderMobileComp;