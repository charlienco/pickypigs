import React, { useState } from "react";
import moment from "moment";
import TextField from "@material-ui/core/TextField";
import { Field, Form, Formik } from "formik";
import * as Yup from "yup";
import showpassword from "../../../assets/images/eye_icon.svg";
import { useDispatch } from "react-redux";
import { updateUserProfileDetail } from "../../../redux/actions/userProfileAction";
import user_icon from "../../../assets/images/mobile_imgs/icon_input_name_dark.svg";
import lock_icon from "../../../assets/images/mobile_imgs/lock_icon_dark.svg";
import email_icon from "../../../assets/images/mobile_imgs/email_icon_black.svg";
import phone_icon from "../../../assets/images/mobile_imgs/phone_icon_dark.svg";
import location_icon from "../../../assets/images/mobile_imgs/location_icon_dark.svg";
import calendar_icon from "../../../assets/images/mobile_imgs/calendar_dark.svg";
import gende_icon from "../../../assets/images/mobile_imgs/gende_icon.svg";
import "./UserPersonalDetailMobileComp.scss";
import editblack_icon from "../../../assets/images/mobile_imgs/edit-black-icon.svg";

const passwordRegExp = RegExp(
  // eslint-disable-next-line
  /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,24})/
);
const numbRegs = RegExp(/^[0-9]*$/);

const UserPersonalDetailMobileComp = (props) => {
  const dispatch = useDispatch();
  let { accountType, email, userDetail } = props.userdata;
  const [type, setType] = useState("password");
  const [editForm, setEditForm] = useState(true);
  const handleCancleEdit = (e) => {
    setEditForm(true);
  };

  const initialValues = {
    name: userDetail && userDetail.name ? userDetail && userDetail.name : "",
    password: editForm ? "password" : "",
    dob: userDetail && userDetail.dob ? userDetail && userDetail.dob : "",
    gender:
      userDetail && userDetail.gender ? userDetail && userDetail.gender : "",
    email: email ? email : "",
    address:
      userDetail && userDetail.address ? userDetail && userDetail.address : "",
    phone: userDetail && userDetail.phone ? userDetail && userDetail.phone : "",
  };

  const validationSchema = Yup.object().shape({
    name: Yup.string().required("Name is required"),
    password: Yup.string()
      .label("Password")
      .min(8, "Seems a bit short(Min 8 characters)...")
      .max(24, "Please try a shorter password(Max 24 characters)...).")
      .matches(
        passwordRegExp,
        "Password should Have 1 Uppercase,1 Lowercase,1 digit,1 special characte"
      ),
    dob: Yup.date().nullable().required("Date Is Required"),
    gender: Yup.string().required("Please Select a Gender"),
    email: Yup.string()
      .email("Email must be a valid email")
      .required("Email Required"),
    address: Yup.string().required("Address is required"),
    phone: Yup.string()
      .required("Phone Number is a required field")
      // .min(10, "Min 10 Digits")
      // .max(10, "Max 10 Digits")
      .matches(numbRegs, "Invalid Phone Number"),
  });

  const handlePassword = () => {
    if (type === "password") {
      setType("text");
    } else {
      setType("password");
    }
  };

  const onSubmit = (fields) => {
    dispatch(updateUserProfileDetail(fields));
    setEditForm(true);
  };

  return (
    <>
      <section>
        <React.Fragment>
          {/* {User_DataLoading?
                        <React.Fragment>
                            <CustomLoadingComp/>
                        </React.Fragment>
                        :
                        null
                    } */}
          <Formik
            enableReinitialize={true}
            initialValues={initialValues}
            validationSchema={validationSchema}
            onSubmit={onSubmit}
          >
            {({
              errors,
              touched,
              isSubmitting,
              setFieldValue,
              handleChange,
              values,
            }) => {
              return (
                <Form>
                  <div className="userPersonalDetailMobileComp-content">
                    <div className="col-sm-12 pl-0 pr-0">
                      <div className="row">
                        <div className="col-sm-12 pl-0 pr-0">
                          <div className="userform-btn-main d-flex justify-content-end pl-4 pr-4">
                            {editForm ? (
                              <button
                                className="btn d-inline-flex align-items-center justify-content-center mb-3 edituser-profileform-btn"
                                type="button"
                                onClick={() => {
                                  setEditForm(false);
                                }}
                              >
                                <img
                                  src={editblack_icon}
                                  className="img_fluid"
                                  alt="img"
                                  loading="lazy"
                                />
                              </button>
                            ) : (
                              <div className="d-flex justify-content-center mb-3 align-items-center w-100 userform-btn-bottom">
                                <button
                                  className="lightgray-btn btn cancel-btn mr-4"
                                  type="reset"
                                  onClick={handleCancleEdit}
                                >
                                  Cancel
                                </button>
                                <button
                                  className="theme-pink-btn apply-btn brandon-Bold"
                                  type="submit"
                                >
                                  Save
                                </button>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="col-sm-12">
                      <div className="">
                        <div className="rs-infoblock">
                          <div className="border-bottom d-flex position-relative">
                            <div className="rs-infoicon mr-3">
                              <img
                                src={user_icon}
                                className="img-fluid"
                                alt="Full name"
                                loading="lazy"
                              />
                            </div>
                            <div className="rs-infosubwrap pt-3 pb-3">
                              <p className="brandon-Medium text-uppercase mb-0">
                                Full name
                              </p>
                              {editForm ? (
                                <p className="form-control-plaintext">
                                  {userDetail && userDetail.name
                                    ? userDetail.name
                                    : "Name Not Available"}
                                </p>
                              ) : (
                                <React.Fragment>
                                  <Field
                                    name="name"
                                    placeholder="Enter Name here"
                                    className="form-control-inputtext form-control"
                                  />
                                  {touched.name && errors.name && (
                                    <div className="error pink-txt f-11">
                                      {errors.name}
                                    </div>
                                  )}
                                </React.Fragment>
                              )}
                            </div>
                          </div>
                          {accountType && accountType === "email" && (
                            <div className="border-bottom d-flex position-relative">
                              <div className="rs-infoicon mr-3">
                                <img
                                  src={lock_icon}
                                  className="img-fluid"
                                  alt="Password"
                                  loading="lazy"
                                />
                              </div>
                              <div className="rs-infosubwrap pt-3 pb-3 password-input-wrapper">
                                <p className="brandon-Medium text-uppercase mb-0">
                                  Password
                                </p>
                                <div className="password-input position-relative">
                                  {editForm ? (
                                    <Field
                                      type="password"
                                      name="password"
                                      readOnly={true}
                                      className="form-control-plaintext"
                                      value="Password"
                                    />
                                  ) : (
                                    <React.Fragment>
                                      <Field
                                        type={type}
                                        name="password"
                                        placeholder="Password"
                                        className="form-control-inputtext form-control"
                                      />
                                      {!editForm && (
                                        <div
                                          className="showpassword-block"
                                          id="password"
                                          onClick={() => handlePassword()}
                                        >
                                          <img
                                            src={showpassword}
                                            className="img-fluid"
                                            alt="showpassword"
                                            loading="lazy"
                                          />
                                        </div>
                                      )}
                                      {touched.password && errors.password && (
                                        <div className="error pink-txt f-11">
                                          {errors.password}
                                        </div>
                                      )}
                                    </React.Fragment>
                                  )}
                                </div>
                              </div>
                            </div>
                          )}

                          <div className="border-bottom d-flex position-relative">
                            <div className="rs-infoicon mr-3">
                              <img
                                src={calendar_icon}
                                className="img-fluid"
                                alt="Date of Birth"
                                loading="lazy"
                              />
                            </div>
                            <div className="rs-infosubwrap pt-3 pb-3 dob-input-wrapper">
                              <p className="brandon-Medium text-uppercase mb-0">
                                Date of Birth
                              </p>
                              {editForm ? (
                                <p className="form-control-plaintext">
                                  {userDetail && userDetail.dob
                                    ? moment(
                                        userDetail && userDetail.dob
                                      ).format("DD MMMM YYYY")
                                    : "DOB Not Available"}
                                </p>
                              ) : (
                                <React.Fragment>
                                  <TextField
                                    id="date"
                                    type="date"
                                    onChange={(e) =>
                                      setFieldValue("dob", e.target.value)
                                    }
                                    className="dob-input-control form-control datepicker-control d-flex align-items-center justify-content-center"
                                    name="dob"
                                    value={moment(values.dob).format(
                                      "YYYY-MM-DD"
                                    )}
                                    InputLabelProps={{ shrink: true }}
                                  />
                                  {touched.dob && errors.dob && (
                                    <div className="error pink-txt f-11">
                                      {errors.dob}
                                    </div>
                                  )}
                                </React.Fragment>
                              )}
                            </div>
                          </div>

                          <div className="border-bottom d-flex position-relative">
                            <div className="rs-infoicon mr-3">
                              <img
                                src={gende_icon}
                                className="img-fluid"
                                alt="Gender"
                                loading="lazy"
                              />
                            </div>
                            <div className="rs-infosubwrap pt-3 pb-3">
                              <p className="brandon-Medium text-uppercase mb-0">
                                Gender
                              </p>
                              {editForm ? (
                                <p className="form-control-plaintext text-capitalize">
                                  {userDetail && userDetail.gender
                                    ? userDetail.gender
                                    : "Gender Not Available"}
                                </p>
                              ) : (
                                <React.Fragment>
                                  <Field
                                    as="select"
                                    name="gender"
                                    className="form-control-inputtext form-control text-capitalize"
                                  >
                                    <option value="">Select</option>
                                    <option value="male">male</option>
                                    <option value="female">female</option>
                                    <option value="Other">Other</option>
                                  </Field>
                                  {touched.gender && errors.gender && (
                                    <div className="error pink-txt f-11">
                                      {errors.gender}
                                    </div>
                                  )}
                                </React.Fragment>
                              )}
                            </div>
                          </div>

                          <div className="border-bottom d-flex position-relative">
                            <div className="rs-infoicon mr-3">
                              <img
                                src={email_icon}
                                className="img-fluid"
                                alt="Email"
                                loading="lazy"
                              />
                            </div>
                            <div className="rs-infosubwrap pt-3 pb-3">
                              <p className="brandon-Medium text-uppercase mb-0">
                                Email
                              </p>
                              <Field
                                name="email"
                                type="email"
                                readOnly={true}
                                placeholder="Enter Name here"
                                className="form-control-plaintext"
                              />
                            </div>
                          </div>

                          <div className="border-bottom d-flex position-relative">
                            <div className="rs-infoicon mr-3">
                              <img
                                src={phone_icon}
                                className="img-fluid"
                                alt="Phone number"
                                loading="lazy"
                              />
                            </div>
                            <div className="rs-infosubwrap pt-3 pb-3">
                              <p className="brandon-Medium text-uppercase mb-0">
                                Phone number
                              </p>
                              {editForm ? (
                                userDetail && userDetail.phone ? (
                                  <p className="form-control-plaintext text-capitalize">
                                    {userDetail && userDetail.phone}
                                  </p>
                                ) : (
                                  <p className="form-control-plaintext text-capitalize">
                                    Not- Available
                                  </p>
                                )
                              ) : (
                                <React.Fragment>
                                  <Field
                                    name="phone"
                                    placeholder="Enter Phone Number here"
                                    className="form-control-inputtext form-control "
                                  />
                                  {touched.phone && errors.phone && (
                                    <div className="error pink-txt f-11">
                                      {errors.phone}
                                    </div>
                                  )}
                                </React.Fragment>
                              )}
                            </div>
                          </div>

                          <div className="border-bottom d-flex position-relative">
                            <div className="rs-infoicon mr-3">
                              <img
                                src={location_icon}
                                className="img-fluid"
                                alt="Address"
                                loading="lazy"
                              />
                            </div>
                            <div className="rs-infosubwrap pt-3 pb-3">
                              <p className="brandon-Medium text-uppercase mb-0">
                                Address
                              </p>
                              {editForm ? (
                                <p className="form-control-plaintext text-capitalize">
                                  {userDetail && userDetail.address}
                                </p>
                              ) : (
                                <React.Fragment>
                                  <Field
                                    component="textarea"
                                    rows="1"
                                    className="form-control-inputtext form-control"
                                    name="address"
                                    placeholder="Your address"
                                  />
                                  {touched.address && errors.address && (
                                    <div className="error pink-txt f-11">
                                      {errors.address}
                                    </div>
                                  )}
                                </React.Fragment>
                              )}
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </Form>
              );
            }}
          </Formik>
        </React.Fragment>
      </section>
    </>
  );
};

export default UserPersonalDetailMobileComp;
