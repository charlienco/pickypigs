import React from "react";
import { Button, Modal } from "react-bootstrap";
import Ingredientsicon from "../../../assets/images/dishinfo_img/Ingredients-icon.svg";
import closewhite_icon from "../../../assets/images/mobile_imgs/close-white-icon.svg";
import "./IngredientsDetailMobileModal.scss";

const IngredientsDetailMobileModal = (props) => {
  // const ingredient = [{ "serving": 36.9, "ingredient": "raw broccoli", "allergies": "", "amend": "no" }, { "serving": 12.9, "ingredient": "cheese", "allergies": "dairy", "amend": "yes" }, { "serving": 15.5, "ingredient": "potatoes", "allergies": "", "amend": "yes" }, { "serving": 20.5, "ingredient": "lenties", "allergies": "", "amend": "yes" }, { "serving": 15.5, "ingredient": "olives", "allergies": "", "amend": "yes" }, { "serving": 50.5, "ingredient": "peanuts", "allergies": "peanuts", "amend": "yes" }, { "serving": 15.5, "ingredient": "housing dressing", "allergies": "", "amend": "yes" }]
  const { onHide, show } = props;

  return (
    <>
      <section>
        <div className="">
          <Modal
            show={show}
            size="lg"
            aria-labelledby="contained-modal-title-vcenter"
            centered
          >
            {/* <Modal.Header closeButton>
                        <Modal.Title id="contained-modal-title-vcenter">
                        Modal heading
                        </Modal.Title>
                    </Modal.Header> */}
            <div className="ingredientsdetailmobilemodal-main-wrapper">
              <Modal.Body>
                <div className="IngredientsDetailMobileModal-wrapper h-100">
                  <div className="row">
                    <div className="col-sm-12">
                      <div className="d-flex align-items-start position-relative">
                        <div className="position-absolute">
                          <img
                            src={Ingredientsicon}
                            alt=""
                            className="img-fluid "
                          />
                        </div>
                        <h4 className="pl-4 ml-3 mb-0 txt-darkgreen mb-0">
                          Ingredients
                        </h4>
                      </div>
                    </div>
                  </div>

                  <div className="row">
                    <div className="col-sm-12">
                      <hr className="hr-botted-style mb-0" />
                    </div>
                  </div>

                  <div className="table-responsive ingredients-table">
                    <table className="table mb-0">
                      <thead>
                        <tr>
                          <th scope="col" className="txt-lightgray fw-400">
                            Serving
                          </th>
                          <th scope="col" className="txt-lightgray fw-400">
                            Ingredient
                          </th>
                          <th scope="col" className="txt-lightgray fw-400">
                            Allergies
                          </th>
                          <th
                            scope="col"
                            width="50px"
                            className="txt-lightgray fw-400"
                          >
                            Amend
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                        {props.ingredient && props.ingredient.length > 0 ? (
                          <React.Fragment>
                            {props.ingredient &&
                              props.ingredient.map((data, index) => {
                                return (
                                  <tr key={index}>
                                    <th scope="row">{data.qty} %</th>
                                    <td>{data.item}</td>
                                    <td>
                                      {data.allergeiesList &&
                                      data.allergeiesList.length > 0 ? (
                                        <React.Fragment>
                                          {data.allergeiesList &&
                                            data.allergeiesList.map(
                                              (data2, index2) => {
                                                return (
                                                  <React.Fragment key={index2}>
                                                    {(index2 ? " , " : "") +
                                                      data2.name}
                                                  </React.Fragment>
                                                );
                                              }
                                            )}
                                        </React.Fragment>
                                      ) : (
                                        <React.Fragment>-na-</React.Fragment>
                                      )}
                                    </td>
                                    <td>{data.customisable ? "Yes" : "No"}</td>
                                  </tr>
                                );
                              })}
                          </React.Fragment>
                        ) : (
                          <React.Fragment>
                            <tr>
                              <td colSpan="4" className="text-center">
                                No Data Available
                              </td>
                            </tr>
                          </React.Fragment>
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              </Modal.Body>
              {/* <Modal.Footer>
                        <Button onClick={props.onHide}>Close</Button>
                    </Modal.Footer> */}
              <div
                className="w-100 text-center"
                style={{ position: "absolute", bottom: "-5rem" }}
              >
                <Button className="modal-close-btn" onClick={onHide}>
                  <img
                    src={closewhite_icon}
                    alt="closewhite_icon"
                    className="img-fluid"
                  />
                </Button>
              </div>
            </div>
          </Modal>
        </div>
      </section>
    </>
  );
};

export default IngredientsDetailMobileModal;
