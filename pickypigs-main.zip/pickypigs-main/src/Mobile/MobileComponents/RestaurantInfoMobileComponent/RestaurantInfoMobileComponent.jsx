import React from "react";
import './RestaurantInfoMobileComponent.scss';
import Diningtable from "../../../assets/images/restaurant-dish/diningtable.svg";
import Cuisineicon from "../../../assets/images/restaurant-dish/cuisine-icon.svg";
import infoicon from "../../../assets/images/restaurant-dish/info-icon.svg";
import checkgray from "../../../assets/images/restaurant-dish/check-gray.svg";
import walleticon from "../../../assets/images/restaurant-dish/wallet-icon.svg";
import websiteicon from "../../../assets/images/restaurant-dish/website-icon.svg";
import phoneicon from "../../../assets/images/restaurant-dish/phone-icon.svg";
// import mapimg from "../../../assets/images/restaurant-dish/map-img.jpg";
import shareicon from "../../../assets/images/restaurant-dish/share-icon.svg";
import getdirection from "../../../assets/images/restaurant-dish/getdirection.svg";
import OpentimeMobileComp from "../OpentimeMobileComp/OpentimeMobileComp";
import { DEFAULT_LAT, DEFAULT_LNG } from '../../../shared/constant'
import Cookies from "js-cookie"
import { useSelector } from "react-redux";
import { FacebookShareButton } from "react-share";
import socialshareicon from "../../../assets/images/share.svg";
import location_icon from "../../../assets/images/mobile_imgs/location_icon_dark.svg";

const RestaurantInfoMobileComponent = ({ rest_about, rest_address, rest_cuisine, rest_other, rest_cost, rest_website, rest_contact, rest_booking, rest_social, rest_applies, restaurant_time }) => {

    const myCordinates = useSelector((state) => {
        return state.googledata
    });
    let { overalLocation = { lat: DEFAULT_LAT, lng: DEFAULT_LNG } } = myCordinates;
    const myCookLat = Cookies.get('lat')
    const myCookLng = Cookies.get('lng')

    const handelOpenWebsite = (url) => {
        if (!url.match(/^https?:\/\//i)) {
            url = 'http://' + url;
        }
        return window.open(url, "_blank");
    }
    return (
        <>
            <section >
                <div className="restaurantDiscInfoMobile-content">
                    <div className="col-sm-12">
                        <div className="row">
                            <div className="col-sm-12 mb-3">
                                <div className="rs-infoblock d-flex flex-column">
                                    <OpentimeMobileComp restaurant_time={restaurant_time} />
                                    <div className="d-block w-100">
                                        {/* <div className="rs-infoicon mr-3">
                                            <img src={location} className="img-fluid" alt="Diningtable" loading="lazy"/>
                                        </div> */}
                                        <div className="rs-infosubwrap pt-1 pl-0">
                                            <p className="brandon-Medium text-capitalize mb-2 txt-lightgray f-14">Address</p>
                                        </div>
                                    </div>
                                    {rest_address && rest_address.addLocationMap ?

                                        <div className="map-wrapper mb-1 mt-2" >
                                            {rest_address && rest_address.map && rest_address.map.coordinates && rest_address.map.coordinates.length > 0 ?
                                               // eslint-disable-next-line jsx-a11y/iframe-has-title
                                               <iframe
                                                    className="map-wrapper"
                                                    style={{ border: 'none' }}
                                                    src={`https://maps.google.com/maps?q=${rest_address && rest_address.map && rest_address.map.coordinates[0]},${rest_address && rest_address.map && rest_address.map.coordinates[1]}&z=16&output=embed`}
                                                    height="450"
                                                    width="100%"
                                                >
                                                </iframe>
                                                :
                                                <p className="txt-lightgray mb-2">Coordinates not Available</p>
                                            }

                                            {/* <img src={mapimg} className="img-fluid" alt="mapimg" loading="lazy"/> */}
                                        </div>
                                        :
                                        <p className="txt-lightgray mb-2">Map not Available</p>
                                    }
                                    {rest_address && rest_address.googleAddress ?
                                        <p className="address-label mt-2 mb-4 pt-1"><br></br>
                                            <img src={location_icon} className="img-fluid" alt="img" loading="lazy"/>
                                            <span className="f-14">{rest_address.googleAddress}</span>
                                        </p>
                                        :
                                        <p className="txt-lightgray mb-2">Address not Available</p>


                                    }

                                    <div className="location-wrapper d-flex justify-content-between align-items-center">
                                    {rest_address && rest_address.shareLocationOption && rest_address.shareLocationOption ?
                                        <React.Fragment>
                                            <div className="share-location location-btn">
                                                <FacebookShareButton url={`https://www.google.com/maps?q=${rest_address && rest_address.googleAddress ? rest_address.googleAddress : "7, VIP Rd, Laxmi Nagar, Udhna, Surat, Gujarat 395007, India"}`} className="d-inline-flex align-items-center pink-txt">
                                                    <span className="d-inline-flex align-items-center pink-txt">
                                                        <img src={shareicon} className="img-fluid mr-3" alt="walleticon" loading="lazy"/>
                                                        <span className="f-14">Share Location</span>
                                                    </span>
                                                </FacebookShareButton>


                                            </div>
                                        </React.Fragment>
                                        :
                                        <small className="d-flex justify-centent-center align-items-center" style={{filter:"opacity(0.5)"}}><img src={shareicon} width="14px" className="img-fluid mr-1" alt="walleticon" /> <span className="f-14">Share Location</span></small>
                                    }
                                    <div className="location-borderstyle"></div>
                                    {rest_address && rest_address.getDirectionOption && rest_address.getDirectionOption ?
                                        <React.Fragment>
                                            {rest_address && rest_address.map && rest_address.map.coordinates && rest_address.map.coordinates.length >= 2 ?
                                                <div className="get-directions location-btn d-flex justify-content-end pr-2">
                                                    {/* eslint-disable-next-line  react/jsx-no-target-blank */ }
                                                    <a href={`https://www.google.com/maps/dir/${overalLocation && overalLocation.lat ? overalLocation.lat : myCookLat},${overalLocation && overalLocation.lng ? overalLocation.lng : myCookLng}/${rest_address && rest_address.map && rest_address.map.coordinates[0]},${rest_address && rest_address.map && rest_address.map.coordinates[1]}`} target="_blank" className="d-inline-flex align-items-center pink-txt justify-content-end">
                                                        <img src={getdirection} className="img-fluid mr-3" alt="walleticon" loading="lazy"/>
                                                        <span className="f-14">Get Directions</span>
                                                    </a>
                                                </div>
                                                :
                                                <small className="f-14">Coordinates Not available</small>
                                            }
                                        </React.Fragment>

                                        :
                                        <small className="txt-pink d-flex justify-centent-center align-items-center" style={{filter:"opacity(0.5)"}}><img src={getdirection} className="img-fluid mr-1" alt="walleticon" /><span className="f-14">Get Directions</span></small>
                                    }
                                </div>




                                <div className="sharesocial-link">
                                    <div className="sharesocial-title">
                                        <img src={socialshareicon} alt="socialshareicon" className="img-fluid" loading="lazy"/>
                                        <h6 className="mb-0">Social</h6>
                                    </div>
                                    {rest_social && rest_social.isAvailable ?
                                        <React.Fragment>
                                            <div className="sharesocial-linkbtn">
                                                <p className="brandon-Medium mb-0">Facebook</p>
                                                {rest_social && rest_social.isFacebook ?
                                                    <React.Fragment>
                                                        {rest_social && rest_social.facebookUrl && rest_social.facebookUrl.length > 0 ?
                                                            <React.Fragment>
                                                                {rest_social && rest_social.facebookUrl && rest_social.facebookUrl.map((data, index) => {
                                                                    return (
                                                                        <React.Fragment key={index}>
                                                                            <span type="button" onClick={() => { handelOpenWebsite(data ? data : "www.facebook.com") }} className="pink-txt only_one_line_text" >{data ? data : "www.facebook.com"}</span>
                                                                            {/* <span className="txt-lightgray">{data?data:"www.facebook.com"}</span> */}
                                                                        </React.Fragment>
                                                                    )
                                                                })}
                                                            </React.Fragment>
                                                            :
                                                            <p className="txt-lightgray mb-2">Not Available</p>
                                                        }
                                                    </React.Fragment>
                                                    :
                                                    <p className="txt-lightgray mb-2">Not Available</p>
                                                }
                                            </div>
                                            <div className="sharesocial-linkbtn">
                                                <p className="brandon-Medium mb-0 mt-2">Twitter</p>
                                                {rest_social && rest_social.isTwitter ?
                                                    <React.Fragment>
                                                        {rest_social && rest_social.twitterUrl && rest_social.twitterUrl.length > 0 ?
                                                            <React.Fragment>
                                                                {rest_social && rest_social.twitterUrl && rest_social.twitterUrl.map((data, index) => {
                                                                    return (
                                                                        <React.Fragment key={index}>
                                                                            <span type="button" onClick={() => { handelOpenWebsite(data ? data : "www.twitter.com") }} className="pink-txt only_one_line_text" >{data ? data : "www.twitter.com"}</span>
                                                                            {/* <span className="txt-lightgray">{data?data:"www.twitter.com"}</span> */}
                                                                        </React.Fragment>
                                                                    )
                                                                })}
                                                            </React.Fragment>
                                                            :
                                                            <p className="txt-lightgray mb-2">Not Available</p>
                                                        }
                                                    </React.Fragment>
                                                    :
                                                    <p className="txt-lightgray mb-2">Not Available</p>
                                                }
                                            </div>
                                            <div className="sharesocial-linkbtn">
                                                <p className="brandon-Medium mb-0 mt-2">Instagram</p>
                                                {rest_social && rest_social.isInstagram ?
                                                    <React.Fragment>
                                                        {rest_social && rest_social.instagramUrl && rest_social.instagramUrl.length > 0 ?
                                                            <React.Fragment>
                                                                {rest_social && rest_social.instagramUrl && rest_social.instagramUrl.map((data, index) => {
                                                                    return (
                                                                        <React.Fragment key={index}>
                                                                            <span type="button" onClick={() => { handelOpenWebsite(data ? data : "www.instagram.com") }} className="pink-txt only_one_line_text" >{data ? data : "www.instagram.com"}</span>
                                                                            {/* <span className="txt-lightgray">{data?data:"www.instagram.com"}</span> */}
                                                                        </React.Fragment>
                                                                    )
                                                                })}
                                                            </React.Fragment>
                                                            :
                                                            <p className="txt-lightgray mb-2">Not Available</p>
                                                        }
                                                    </React.Fragment>
                                                    :
                                                    <p className="txt-lightgray mb-2">Not Available</p>
                                                }
                                            </div>

                                        </React.Fragment>
                                        :
                                        <p className="txt-lightgray mb-2">Not Available</p>
                                    }


                                </div>
                            </div>
                        </div>
                    </div>

                    <div className="row">
                        <div className="col-sm-12 mb-3">
                            <div className="rs-infoblock d-flex">
                                <div className="rs-infoicon mr-3">
                                    <img src={Diningtable} className="img-fluid" alt="Diningtable" loading="lazy"/>
                                </div>
                                <div className="rs-infosubwrap pt-1">
                                    <p className="brandon-Medium text-capitalize mb-2">Book a table</p>
                                    {rest_booking && rest_booking.isAvailable ?
                                        <React.Fragment>
                                            <p className="txt-lightgray mb-2">Reserve your table</p>

                                            {rest_booking && rest_booking.isWebsite ?
                                                <React.Fragment>
                                                    {rest_booking && rest_booking.websiteUrl && rest_booking.websiteUrl.length > 0 ?
                                                        <React.Fragment>
                                                            <p className="mb-1">Website:</p>
                                                            {rest_booking && rest_booking.websiteUrl && rest_booking.websiteUrl.map((data, index) => {
                                                                return (
                                                                    <React.Fragment key={index}>
                                                                        <p type="button" onClick={() => { handelOpenWebsite(data ? data : 'https://www.google.com/') }} className="pink-txt mb-1 only_one_line_text" >{data ? data : 'Na'}</p>
                                                                    </React.Fragment>
                                                                )
                                                            })}
                                                        </React.Fragment>
                                                        :
                                                        null
                                                    }

                                                </React.Fragment>
                                                :
                                                null
                                            }

                                            {rest_booking && rest_booking.isEmail ?
                                                <React.Fragment>
                                                    {rest_booking && rest_booking.email && rest_booking.email.length > 0 ?
                                                        <React.Fragment>
                                                            <p className="mb-1 mt-2">Email:</p>
                                                            {rest_booking && rest_booking.email && rest_booking.email.map((data, index) => {
                                                                return (
                                                                    <React.Fragment key={index}>
                                                                        {/* <p className="txt-lightgray mb-1 text-wrap text-break">{data?data:'Na'}</p> */}
                                                                        <a href={`mailto:${data ? data : 'Na'}`} className="pink-txt mb-1 text-wrap text-break d-block ">{data ? data : 'Na'}</a>
                                                                    </React.Fragment>
                                                                )
                                                            })}
                                                        </React.Fragment>
                                                        :
                                                        null
                                                    }

                                                </React.Fragment>
                                                :
                                                null
                                            }

                                            {rest_booking && rest_booking.isCall ?
                                                <React.Fragment>
                                                    {rest_booking && rest_booking.phoneNumber && rest_booking.phoneNumber.length > 0 ?
                                                        <React.Fragment>
                                                            <p className="mb-1 mt-2">Phone:</p>
                                                            {rest_booking && rest_booking.phoneNumber && rest_booking.phoneNumber.map((data, index) => {
                                                                return (
                                                                    <React.Fragment key={index}>
                                                                        <p className="txt-lightgray mb-1 text-wrap text-break">{data ? data : 'Na'}</p>
                                                                    </React.Fragment>
                                                                )
                                                            })}
                                                        </React.Fragment>
                                                        :
                                                        null
                                                    }

                                                </React.Fragment>
                                                :
                                                null
                                            }
                                        </React.Fragment>
                                        :
                                        <p className="txt-lightgray mb-2">Not Available</p>
                                    }
                                </div>
                            </div>
                        </div>
                    </div>


                    <div className="row">
                        <div className="col-sm-12 mb-3">
                            <div className="rs-infoblock d-flex flex-column">
                                <div className="rs-infoicon mr-3">
                                    <img src={websiteicon} className="img-fluid" alt="websiteicon" loading="lazy"/>
                                </div>
                                <div className="rs-infosubwrap pt-1">
                                    <p className="brandon-Medium text-capitalize mb-2">Website</p>
                                    {rest_website && rest_website.isAddToProfilePage ?
                                        <React.Fragment>
                                            {rest_website && rest_website.websiteUrl && rest_website.websiteUrl.length > 0 ?
                                                <React.Fragment>
                                                    {rest_website && rest_website.websiteUrl && rest_website.websiteUrl.length > 0 ?
                                                        <React.Fragment>
                                                            {rest_website && rest_website.websiteUrl && rest_website.websiteUrl.map((data, index) => {
                                                                return (
                                                                    <React.Fragment key={index}>
                                                                        <p type="button" onClick={() => { handelOpenWebsite(data ? data : 'https://www.google.com/') }} className="pink-txt mb-1  only_one_line_text" >{data ? data : 'Na'}</p>
                                                                    </React.Fragment>
                                                                )
                                                            })}

                                                        </React.Fragment>
                                                        :
                                                        <p className="txt-lightgray mb-1 d-flex flex-wrap align-items-center">
                                                            <span className="txt-lightgray">Not Available</span>
                                                        </p>
                                                    }

                                                </React.Fragment>
                                                :
                                                <p className="txt-lightgray mb-1 d-flex flex-wrap align-items-center">
                                                    <span className="txt-lightgray">Not Available</span>
                                                </p>
                                            }

                                        </React.Fragment>
                                        :
                                        <p className="txt-lightgray mb-1 d-flex flex-wrap align-items-center">
                                            <span className="txt-lightgray">Not Available</span>
                                        </p>
                                    }

                                </div>
                                <div className="d-block">
                                    <hr />
                                </div>
                                <div className="mt-1 pt-1">
                                    {/* <div className="rs-infoicon mr-3">
                                            <img src={phoneicon} className="img-fluid" alt="phoneicon" loading="lazy"/>
                                        </div> */}
                                    <div className="mt-1 pt-1">
                                        <div className="rs-infoicon mr-3">
                                            <img src={phoneicon} className="img-fluid" alt="phoneicon" loading="lazy"/>
                                        </div>
                                        <div className="rs-infosubwrap pt-1">
                                            <p className="brandon-Medium text-capitalize mb-2 pb-1">Contact</p>
                                            <p className="mb-1">Email:</p>
                                            {rest_contact && rest_contact.email ?
                                                <a href={`mailto:${rest_contact.email}`} className="pink-txt mb-1 text-wrap text-break d-block">{rest_contact.email}</a>
                                                :
                                                <span className="txt-lightgray mb-1">Not Available</span>
                                            }

                                            <p className="mb-1 mt-2">Mobile:</p>
                                            {rest_contact && rest_contact.mobileNumber ?
                                                <span className="txt-lightgray mb-1 text-break" >{rest_contact.mobileNumber}</span>
                                                :
                                                <span className="txt-lightgray mb-1">Not Available</span>
                                            }

                                            <p className="mb-1 mt-2">Phone:</p>
                                            {rest_contact && rest_contact.phoneNumber ?
                                                <span className="txt-lightgray mb-1 text-break">{rest_contact.phoneNumber}</span>
                                                :
                                                <span className="txt-lightgray mb-1">Not Available</span>
                                            }
                                            {/* {rest_booking&&rest_booking.isCall?
                                                    <React.Fragment>
                                                        <p className="txt-lightgray mb-2 d-flex flex-wrap align-items-start position-relative">
                                                            <span className="txt-lightgray mopo-number position-absolute">Mo:</span>
                                                            {rest_contact&&rest_contact.mobileNumber?
                                                                <span className="pl-5 mb-2">{rest_contact.mobileNumber}</span>
                                                            :
                                                                <span className="pl-5 mb-2">Not Available</span>
                                                            }
                                                        </p>
                                                        <p className="txt-lightgray mb-0 d-flex flex-wrap align-items-start position-relative">
                                                            <span className="txt-lightgray mopo-number position-absolute">Ph:</span>
                                                          
                                                            {rest_booking&&rest_booking.isCall?
                                                                <React.Fragment>
                                                                    {rest_booking&&rest_booking.phoneNumber&&rest_booking.phoneNumber.length>0?
                                                                        <React.Fragment>
                                                                            {rest_booking&&rest_booking.phoneNumber&&rest_booking.phoneNumber.map((data,index)=>{
                                                                                return(
                                                                                    <React.Fragment key={index}>
                                                                                        <span className="pl-5 mb-2">+44 {data?data:'-'}</span>
                                                                                    </React.Fragment>
                                                                                )
                                                                            })}
                                                                        </React.Fragment>
                                                                        :
                                                                        <span className="pl-5 mb-2">Not Available</span>
                                                                }
                                                                </React.Fragment>
                                                            :
                                                                null
                                                            }
                                                        
                                                        </p>
                                                    </React.Fragment>
                                                :
                                                    <p className="txt-lightgray mb-2">Reserve your table</p>
                                                } */}
                                        </div>
                                    </div>


                                </div>
                            </div>
                        </div>
                    </div>

                    <div className="row">
                        <div className="col-sm-12 mb-3">
                            <div className="rs-infoblock d-flex flex-column">
                                <div>
                                    <div className="rs-infoicon mr-3">
                                        <img src={Cuisineicon} className="img-fluid" alt="Cuisine" loading="lazy"/>
                                    </div>
                                    <div className="rs-infosubwrap pt-1">
                                        <p className="brandon-Medium text-capitalize mb-2">Cuisine</p>
                                        {rest_cuisine && rest_cuisine.length > 0 ?
                                            <React.Fragment>
                                                <p className="txt-lightgray mb-2 d-flex flex-wrap align-items-center mt-3">
                                                    {rest_cuisine && rest_cuisine.map((data, index) => {
                                                        return (
                                                            <React.Fragment key={index}>
                                                                <span className="cuisine-label text-capitalize">{data.name ? data.name : 'Na'}</span>
                                                            </React.Fragment>
                                                        )
                                                    })}
                                                </p>
                                            </React.Fragment>
                                            :
                                            <React.Fragment>
                                                <p className="txt-lightgray mb-2">Not Available</p>
                                            </React.Fragment>
                                        }

                                    </div>
                                </div>
                                <div className="d-block">
                                    <hr />
                                </div>
                                <div className="mt-1 pt-1">
                                    <div className="rs-infoicon mr-3">
                                        <img src={infoicon} className="img-fluid" alt="infoicon" loading="lazy"/>
                                    </div>
                                    <div className="rs-infosubwrap pt-1">
                                        <p className="brandon-Medium text-capitalize mb-2">Other info</p>
                                        <ul className="otherinfo-list pt-1 pl-0 mb-0">
                                            {rest_other && rest_other.length > 0 ?
                                                <React.Fragment>
                                                    {rest_other && rest_other.map((data, index) => {
                                                        return (
                                                            <React.Fragment key={index}>
                                                                <li className="otherinfo-li postion-relative d-flex align-items-center mt-1 mb-2">
                                                                    <img width="15px" src={checkgray} className="img-fluid position-absolute" alt="checkgray" loading="lazy" />
                                                                    <span className="pl-4 txt-lightgray text-capitalize f-14">{data.name ? data.name : 'Unknown'}</span>
                                                                </li>
                                                            </React.Fragment>
                                                        )
                                                    })}
                                                    {rest_applies && rest_applies.length > 0 ?
                                                        <React.Fragment>
                                                            {rest_applies && rest_applies.map((data, index) => {
                                                                return (
                                                                    <React.Fragment key={index}>
                                                                        {data && data ?
                                                                            <li className="otherinfo-li postion-relative d-flex align-items-center mt-1 mb-2">
                                                                                <img width="15px" src={checkgray} className="img-fluid position-absolute" alt="checkgray" loading="lazy"/>
                                                                                <span className="pl-4 txt-lightgray text-capitalize">{data ? data : ''}</span>
                                                                            </li>
                                                                            :
                                                                            null
                                                                        }
                                                                    </React.Fragment>
                                                                )
                                                            })}
                                                        </React.Fragment>
                                                        :
                                                        null
                                                    }
                                                </React.Fragment>
                                                :
                                                <React.Fragment>
                                                    <li className="otherinfo-li postion-relative d-flex align-items-center mt-1 mb-2">
                                                        <span className="txt-lightgray">Not Available</span>
                                                    </li>
                                                </React.Fragment>
                                            }
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className="row">
                        <div className="col-sm-12 mb-3">
                            <div className="rs-infoblock d-flex flex-column">
                                <div className="rs-infoicon mr-3">
                                    <img src={walleticon} className="img-fluid" alt="walleticon" loading="lazy"/>
                                </div>
                                <div className="rs-infosubwrap pt-1">
                                    <p className="brandon-Medium text-capitalize mb-2 pb-1">Avg.Cost</p>
                                    {rest_cost ?
                                        <React.Fragment>
                                            {rest_cost && rest_cost.averageCostOfTwoPerson ?
                                                <p className="txt-lightgray mb-1 pb-1 f-14">${rest_cost.averageCostOfTwoPerson} for two people (approx.)</p>
                                                :
                                                <p className="txt-lightgray mb-1 pb-1 f-14">Average Cost not available.</p>

                                            }
                                            {rest_cost && rest_cost.inclusiveTaxesAndCharges ?
                                                <p className="txt-lightgray mb-1 pb-1 f-14">Excl. taxes and charges if any.</p>
                                                :
                                                null
                                            }
                                            {rest_cost && rest_cost.cardAccept ?
                                                <p className="txt-lightgray mb-1 pb-1 f-14">Card accepted.</p>
                                                :
                                                null
                                            }
                                            {rest_cost && rest_cost.cashAccept ?
                                                <p className="txt-lightgray mb-1 pb-1 f-14">Cash accepted.</p>
                                                :
                                                null
                                            }
                                        </React.Fragment>
                                        :
                                        <p className="txt-lightgray mb-2">Not Available</p>

                                    }
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* <div className="row">
                        <div className="col-sm-12 mb-3">
                            <div className="rs-infoblock d-flex flex-column">
                                <p>Have You Been To This Restaurant</p>
                                <div>
                                                
                                </div>
                                <p>How Would You like to rate the Restaurant</p>
                                <div className="location-wrapper d-flex justify-content-between align-items-center">
                                    <div className="share-location location-btn">
                                        <a href="#" className="d-inline-flex align-items-center pink-txt">
                                            <img src={shareicon} className="img-fluid mr-3" alt="walleticon" />
                                            <span>Share Location</span>
                                        </a>
                                    </div>
                                    <div className="location-borderstyle"></div>
                                    <div className="get-directions location-btn d-flex justify-content-end pr-2">
                                        <a href="https://www.google.com/maps/dir/21.2072044,72.7522558/21.1593458,72.7522558" target="_blank" className="d-inline-flex align-items-center pink-txt justify-content-end">
                                            <img src={getdirection} className="img-fluid mr-3" alt="walleticon" />
                                            <span>Get Directions</span>
                                        </a>
                                    </div>
                                </div>
                                
                            </div>
                        </div>
                    </div> */}

                </div>
                </div>
        </section>

        </>
    )
}

export default RestaurantInfoMobileComponent;
