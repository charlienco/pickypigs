import React from "react";
// import whatmenuicon1 from "../../../assets/images/micon1.svg";
// import whatmenuicon2 from "../../../assets/images/micon2.svg";
// import whatmenuicon3 from "../../../assets/images/micon3.svg";
import locationgray_icon from "../../../assets/images/location-gray.svg";
// import favorite_icon from "../../../assets/images/mobile_imgs/heart-icon.svg";
// import share_icon from "../../../assets/images/mobile_imgs/share-icon.svg";
import leftarrow_white from "../../../assets/images/mobile_imgs/left-white-arrow.svg";
import { SERVER_URL } from "../../../shared/constant";
import Dummy_Image from "../../../assets/images/restaurant_default.jpg";
import "./RestaurantDetailMobileComp.scss";
import { useHistory } from "react-router-dom";
import {  OverlayTrigger, Tooltip } from "react-bootstrap";
import { showContactUsPopup } from "../../../redux/actions/restaurantAdminAction";
import { useDispatch, useSelector } from "react-redux";
import CustomLoadingComp from "../../../components/CustomLoadingComp/CustomLoadingComp";

export const RestaurantDetailMobileComp = ({
  rest_about,
  restaurant_image,
  restaurant_distance,
  restaurant_name,
  restaurant_cuisine,
  restaurant_feature,
}) => {
  const history = useHistory();
  const dispatch = useDispatch();
  const isLoading = useSelector((state) => state.general.isLoginLoading);

  return (
    <>
      {isLoading ? <CustomLoadingComp /> : null}

      <section className="RestaurantDetailMobileComp-comp">
        <div style={{ position: "relative" }} className="row">
          <div className="col-sm-12  pl-0 pr-0">
            <div className="restaurant-main-img">
              {restaurant_image ? (
                <img
                  src={`${SERVER_URL}/${restaurant_image}`}
                  alt={restaurant_name ? restaurant_name : "Restaurant_image"}
                  className="img-fluid w-100"
                  loading="lazy"
                />
              ) : (
                <img
                  src={Dummy_Image}
                  alt={restaurant_name ? restaurant_name : "Restaurant_image"}
                  className="img-fluid w-100"
                  loading="lazy"
                />
              )}
            </div>
          </div>
          <div className="restaurant-navbar">
            <div
              className="restaurant-leftslide"
              type="button"
              onClick={() => {
                history.goBack();
              }}
            >
              <img
                src={leftarrow_white}
                className="img-fluid"
                alt="icon"
                loading="lazy"
              />
            </div>
            <div className="restaurant-rigthslide d-flex align-items-center">
              {/* <div className="restaurant-favorite-icon">
                                <img src={favorite_icon} className="img-fluid" loading="lazy"/>
                            </div>
                            <div className="restaurant-share-icon ml-4">
                                <img src={share_icon} className="img-fluid" loading="lazy"/>
                            </div> */}
            </div>
          </div>
          <div
            style={{ position: "absolute", bottom: "3.5rem" }}
            className="d-flex justify-content-between flex-column  w-100"
          >
            <div className="col-sm-12">
              <div className="row">
                <div className="col-sm-12">
                  <div className="col-sm-12">
                    <div className="restaurant-mob-details">
                      <h4 className="text-white text-capitalize">
                        {restaurant_name && restaurant_name
                          ? restaurant_name
                          : "Unknown"}
                      </h4>
                      {/* <p className="text-white">{restaurant_location&&restaurant_location?restaurant_location:'Na'}</p> */}
                      <p className="text-white d-flex align-items-center">
                        <span className="position-relative location-icon">
                          <img
                            src={locationgray_icon}
                            alt={"locationgray_icon"}
                            className="img-fluid mr-2"
                            loading="lazy"
                          />
                        </span>
                        {restaurant_distance &&
                        restaurant_distance &&
                        restaurant_distance !== "null" ? (
                          <span className="rsdediction-km">
                            {" "}
                            {restaurant_distance} from you{" "}
                          </span>
                        ) : (
                          <span className="rsdediction-km"> Not Availabe </span>
                        )}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            {/* <div className="dish_desc_rounde"></div> */}
          </div>
        </div>

        <div className="row">
          <div className="col-sm-12">
            <div className="restaurant-mob-intro pt-4 pb-2">
              <div className="col-sm-12">
                <p className="txt-lightgray f-14 mb-0">{rest_about}</p>
              </div>
            </div>
          </div>
        </div>
        <div className="row">
          <div className="col-sm-12">
            <div className="col-sm-12">
              {restaurant_cuisine && restaurant_cuisine.length > 0 ? (
                <React.Fragment>
                  <p className="txt-lightgray mb-3 text-capitalize f-14">
                    <span>
                      {restaurant_cuisine &&
                        restaurant_cuisine.map((data, index) => {
                          return (
                            <React.Fragment key={index}>
                              {index ? ", " : ""}
                              {data.name ? data.name : "Na"}
                            </React.Fragment>
                          );
                        })}
                    </span>
                  </p>
                </React.Fragment>
              ) : (
                <React.Fragment>
                  <p className="txt-lightgray mb-3 f-14">
                    <span>-</span>
                  </p>
                </React.Fragment>
              )}
            </div>
          </div>
        </div>
        <div className="row">
          <div className="col-sm-12">
            <div className="col-sm-12">
              <div className="foodtypes-wrap d-flex flex-wrap">
                {restaurant_feature && restaurant_feature.length > 0 ? (
                  <React.Fragment>
                    {restaurant_feature &&
                      restaurant_feature.map((data, index) => {
                        return (
                          <React.Fragment key={index}>
                            <OverlayTrigger
                              placement="bottom"
                              overlay={
                                <Tooltip id={`tooltip-${index}`}>
                                  {data.name ? data.name : "Unknown"}
                                </Tooltip>
                              }
                            >
                              <div className="food-types mr-3 mb-2 d-flex justify-content-center align-items-center">
                                <img
                                  src={`${SERVER_URL}/${data.image}`}
                                  alt={"icon"}
                                  className="img-fluid"
                                  loading="lazy"
                                />
                              </div>
                            </OverlayTrigger>
                          </React.Fragment>
                        );
                      })}
                  </React.Fragment>
                ) : null}
              </div>
              <div className="form-group text-center">
                {/*  eslint-disable-next-line */}
              <a href="javascript:void(0)" className="add-update-restaurant text-center" onClick={() =>dispatch(showContactUsPopup(true))}>
              Have you seen your restaurant on Picky Pigs and want to update it?
              </a>
                {/* <button
                  onClick={() => dispatch(showContactUsPopup(true))}
                  className="min-width-270 restdet-addupdate-btn pinkline-btn signup-btn btn mt-4 text-uppercase rounded-pill"
                >
                  Add/Update Restaurant
                </button> */}
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};
