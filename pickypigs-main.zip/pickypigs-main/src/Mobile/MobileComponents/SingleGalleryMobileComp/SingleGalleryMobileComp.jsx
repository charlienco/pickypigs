import React from "react";
import { SERVER_URL } from "../../../shared/constant";
import no_Data_Image from "../../../assets/images/no_data_found.png";
import "./SingleGalleryMobileComp.scss";

const SingleGalleryMobileComp = (props) => {
  return (
    <>
      <section>
        <div className="row">
          <div className="col-sm-12">
            <div className="col-sm-12">
              <div className="singleGalleryMobile-content">
                <div className="rs-infoblock">
                  <div className="d-flex justify-content-between align-items-center flex-wrap rs-gallery-heading-wrapper">
                    <div className="d-flex align-items-center rs-gallery-heading">
                      <img
                        src={props.icon}
                        className="img-fluid mr-3"
                        alt="Diningtable"
                        loading="lazy"
                      />
                      <span className="f-14">{props.heading}</span>
                    </div>
                    <button className="sell-all">Sell All</button>
                  </div>
                  <div className="border-bottom mt-2 mb-2 border-bottom-style"></div>
                  <div className="col-sm-12 pl-1 pr-1 mt-3">
                    <div className="row">
                      {props.food && props.food.length > 0 ? (
                        <React.Fragment>
                          {props.food &&
                            props.food.slice(0, 1).map((data, index) => {
                              return (
                                <div
                                  className="col-6 col-sm-4 col-md-4 col-lg-3 col-xl-2 pl-0 pr-0 gallery-imgblock"
                                  key={index}
                                >
                                  <div className="rsdish-gallery">
                                    <img
                                      src={`${SERVER_URL}/${data.url}`}
                                      alt="img"
                                      className="img-fluid"
                                      loading="lazy"
                                    />
                                  </div>
                                </div>
                              );
                            })}
                          <div className="col-6 pl-0 pr-0">
                            <div className="d-flex flex-wrap">
                              {props.food &&
                                props.food.slice(1, 5).map((data, index) => {
                                  return (
                                    <div key={index} className="">
                                      <div
                                        className={`rsdish-gallery-small position-relative ${
                                          index === 3 ? "more-dish" : null
                                        }`}
                                      >
                                        <img
                                          src={`${SERVER_URL}/${data.url}`}
                                          className="img-fluid"
                                          alt="img"
                                          loading="lazy"
                                        />

                                        {index === 3 ? (
                                          props.food &&
                                          props.food.length > 5 ? (
                                            <span className="text-white position-absolute brandon-Medium">
                                              +{" "}
                                              {props.food &&
                                                props.food.length - 5}
                                            </span>
                                          ) : null
                                        ) : null}
                                      </div>
                                    </div>
                                  );
                                })}
                            </div>
                          </div>
                        </React.Fragment>
                      ) : (
                        <React.Fragment>
                          <div className="w-100 d-flex align-items-center justify-content-center">
                            <img
                              src={no_Data_Image}
                              className="img-fluid"
                              loading="lazy"
                              alt="img"
                            />
                          </div>
                        </React.Fragment>
                      )}
                      {/* <div  className="col-6 pl-0 pr-0">
                                <div className="d-flex flex-wrap">
                                    <div className="">
                                        <div className="rsdish-gallery-small">
                                            <img src={disc_1} className="img-fluid" alt="img" />
                                        </div>
                                    </div>
                                    <div className="">
                                        <div className="rsdish-gallery-small">
                                            <img src={disc_3} className="img-fluid" alt="img" />
                                        </div>
                                    </div>
                                    <div className="">
                                        <div className="rsdish-gallery-small">
                                            <img src={disc_4} className="img-fluid" alt="img" />
                                        </div>
                                    </div>
                                    <div className="">
                                        <div className="rsdish-gallery-small">
                                            <img src={disc_5} className="img-fluid" alt="img" />
                                        </div>
                                    </div>
                                </div>
                            </div> */}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default SingleGalleryMobileComp;
