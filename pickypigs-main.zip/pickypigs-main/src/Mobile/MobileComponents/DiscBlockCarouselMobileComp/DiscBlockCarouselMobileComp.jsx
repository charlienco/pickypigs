import React, { useEffect, useState } from "react";

import { Link } from 'react-router-dom'
import Slider from 'react-slick';
import DiscBlockMobileComp from "../DiscBlockMobileComp/DiscBlockMobileComp";
import { DEFAULT_LAT, DEFAULT_LNG } from "../../../shared/constant";
import { useDispatch, useSelector } from "react-redux";
import { getRandomRestaurantsList } from "../../../redux/actions/homePageAction";
import MobRestaurantSkeletonOne from "../../Skeleton/MobRestaurantSkeletonOne/MobRestaurantSkeletonOne";

const DiscBlockCarouselMobileComp = () => {
    const dispatch = useDispatch();
    const [activeSlide, setActiveSlide] = useState(0);

    //Accessing location_data from redux store Start
    const myCordinates = useSelector((state) => {
        return state.googledata
    });
    let { overalLocation = { lat: DEFAULT_LAT, lng: DEFAULT_LNG } } = myCordinates;

    useEffect(() => {
        if (overalLocation && overalLocation.lat && overalLocation.lng) {
            dispatch(getRandomRestaurantsList({ userCoordinates: [overalLocation && overalLocation.lat ? overalLocation.lat : '', overalLocation && overalLocation.lng ? overalLocation.lng : ''], start: 0, length: 8 }))
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [overalLocation]);



    const randomRestaurantData = useSelector((state) => {
        return state.homePage
    });
    let { isLoading, randomRestaurantsList_Data } = randomRestaurantData;
   

    var settings = {
        arrows: false,
        centerMode: false,
        infinite: false,
        slidesToShow: 1.3,
        slidesToScroll: 1,
        afterChange: (current, next) => setActiveSlide(current),
        responsive:[
            {
                breakpoint: 1200,
                settings: {
                    slidesToShow: 3.3,
                }
            },
            {
                breakpoint: 1024,
                settings: {
                    slidesToShow: 3.3,
                }
            },
            {
                breakpoint: 992,
                settings: {
                    slidesToShow: 2.3,
                }
            },
            {
                breakpoint: 768,
                settings: {
                    slidesToShow: 2.3,
                }
            },
            {
                breakpoint: 600,
                settings: {
                    slidesToShow: 1.3,
                }
            },
            {
                breakpoint: 425,
                settings: {
                    slidesToShow: 1.3,
                }
            },
        ]
    };

    return (
        <>
            <section >
                <div className="row">
                    {isLoading ?
                            <React.Fragment>
                                <div className="col-sm-12">
                                    <div className="rl-list-slider">
                                        <Slider {...settings}>
                                            <div className="pl-0 pr-4 pt-4 pb-4" >
                                                <MobRestaurantSkeletonOne/>
                                            </div>
                                            <div className="pl-0 pr-4 pt-4 pb-4" >
                                                <MobRestaurantSkeletonOne/>
                                            </div>
                                        </Slider>
                                    </div>
                                </div>
                            </React.Fragment>
                        :
                        <React.Fragment>
                            {randomRestaurantsList_Data && randomRestaurantsList_Data.data && randomRestaurantsList_Data.data.length > 0 ?
                                <React.Fragment>
                                    {randomRestaurantsList_Data && randomRestaurantsList_Data.data && randomRestaurantsList_Data.data.length > 2 ?
                                        <div className="col-sm-12">
                                            <div className="rl-list-slider">
                                                <Slider {...settings}>
                                                    {randomRestaurantsList_Data.data && randomRestaurantsList_Data.data.map((data, index) => {
                                                        return (
                                                            <div key={index} >
                                                                <Link to={'/restaurant/' + data._id} style={{ textDecoration: 'none', color: 'initial' }}>
                                                                    <DiscBlockMobileComp
                                                                        scale={index === activeSlide ? null : "scale"}
                                                                        restaurant_name={data.name ? data.name : ''}
                                                                        restaurant_pic={data.restaurantProfilePhoto ? data.restaurantProfilePhoto : ''}
                                                                        kmvalue={data.distance && data.distance.text ? data.distance.text : ""}
                                                                        rating={4.5}
                                                                        restaurantfeature={data.restaurantFeaturesOptionsList ? data.restaurantFeaturesOptionsList : []}
                                                                    />
                                                                </Link>
                                                            </div>
                                                        )
                                                    })}
                                                </Slider>
                                            </div>
                                        </div>
                                        :
                                        <div className="col-sm-12">
                                            <div className="rl-list-slider">
                                                {randomRestaurantsList_Data.data && randomRestaurantsList_Data.data.map((data, index) => {
                                                    return (
                                                        <div key={index} >
                                                            <Link to={'/restaurant/' + data._id} style={{ textDecoration: 'none', color: 'initial' }}>
                                                                <DiscBlockMobileComp
                                                                    scale={null}
                                                                    restaurant_name={data.name ? data.name : ''}
                                                                    restaurant_pic={data.restaurantProfilePhoto ? data.restaurantProfilePhoto : ''}
                                                                    kmvalue={data.distance && data.distance.text ? data.distance.text : ""}
                                                                    rating={4.5}
                                                                    restaurantfeature={data.restaurantFeaturesOptionsList ? data.restaurantFeaturesOptionsList : []}
                                                                />
                                                            </Link>
                                                        </div>
                                                    )
                                                })}
                                            </div>
                                        </div>
                                    }

                                </React.Fragment>
                                :
                                <React.Fragment>
                                    <p>Something Went Wrong...</p>
                                </React.Fragment>
                            }

                        </React.Fragment>
                    }
                </div>
            </section>
        </>
    )
}

export default DiscBlockCarouselMobileComp;