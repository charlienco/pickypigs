import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import RestaurantFilterBlockMobileComp from "../RestaurantFilterBlockMobileComp/RestaurantFilterBlockMobileComp";
import "./AllRestaurantMobileComp.scss";
import { Link } from "react-router-dom";
import { DEFAULT_LAT, DEFAULT_LNG } from "../../../shared/constant";
import no_Data_Image from "../../../assets/images/no_data_found.png";
import {
  getFourRestaurantsData,
  getSearchedRestaurantsList,
} from "../../../redux/actions/restaurantSearchPageAction";
import AllRestaurantMobileSkeleton from "../../Skeleton/AllRestaurantMobileSkeleton/AllRestaurantMobileSkeleton";
import { updateAllRestaurantSort } from "../../../redux/actions/generalActions";

const AllRestaurantMobileComp = () => {
  const dispatch = useDispatch();
  let restaurantSortBy = useSelector((state) => {
    return state.general.restaurantSortBy;
  });

  const [restroVisible, setRestroVisible] = useState(3);
  const [shortBy, setShortBy] = useState(restaurantSortBy || "relevance");

  const [allergen, setAllergen] = useState([]);
  const [lifestyle, setLifestyle] = useState([]);
  const [dietary, setDietary] = useState([]);
  const [features, setfeatures] = useState([]);
  const [myDistance, setMyDistance] = useState(0);
  const [myNearby, setMyNearby] = useState(false);

  useEffect(() => {
    if (restaurantSortBy !== '') {
      setShortBy(restaurantSortBy)
    }
  }, [restaurantSortBy])

  const preferenceData = useSelector((state) => {
    return state.myPreference.selectedPreference;
  });
  let {
    allergendata,
    dietarydata,
    lifestyledata,
    featuredata,
    nearby,
    distance,
  } = preferenceData;

  useEffect(() => {
    setAllergen(allergendata ? allergendata : allergen);
    setDietary(dietarydata ? dietarydata : dietary);
    setLifestyle(lifestyledata ? lifestyledata : lifestyle);
    setfeatures(featuredata ? featuredata : features);
    setMyDistance(distance ? distance : myDistance);
    setMyNearby(nearby);
    // eslint-disable-next-line
  }, [preferenceData]);
  
  const searchRestaurant_Data = useSelector((state) => {
    return state.restaurantSearch;
  });

  let {
    isLoading,
    fourMoreRustLoading,
    searchedRestaurantsList_Data,
    fourRestroData,
  } = searchRestaurant_Data;

  const myCordinates = useSelector((state) => {
    return state.googledata;
  });
  let { overalLocation = { lat: DEFAULT_LAT, lng: DEFAULT_LNG } } =
    myCordinates;

  useEffect(() => {
    if (
      overalLocation &&
      overalLocation.lat &&
      overalLocation.lng &&
      allergen === preferenceData.allergendata &&
      dietary === preferenceData.dietarydata &&
      lifestyle === preferenceData.lifestyledata &&
      features === preferenceData.featuredata
    ) {
      // console.log('Dm hsadere=>', myLocation, "==>", location_data)
      dispatch(
        getSearchedRestaurantsList({
          userCoordinates: [
            overalLocation && overalLocation.lat
              ? overalLocation.lat
              : DEFAULT_LAT,
            overalLocation && overalLocation.lng
              ? overalLocation.lng
              : DEFAULT_LNG,
          ],
          styleOfmenu: "",
          search: "",
          sort: shortBy,
          features: features && features.length > 0 ? features : [],
          allergen: allergen && allergen.length > 0 ? allergen : [],
          dietary: dietary && dietary.length > 0 ? dietary : [],
          lifestyle: lifestyle && lifestyle.length > 0 ? lifestyle : [],
          distance: myNearby ? 0 : myDistance * 1000,
          start: 0,
          length: 3,
        })
      );
      setRestroVisible(3);
    }
    // eslint-disable-next-line
  }, [
    overalLocation,
    shortBy,
    allergen,
    dietary,
    lifestyle,
    features,
    myDistance,
    myNearby,
  ]);

  //load more Restro Start
  const loadMoreRestro = () => {
    setRestroVisible(restroVisible + 3);
    dispatch(
      getFourRestaurantsData({
        userCoordinates: [
          overalLocation && overalLocation.lat
            ? overalLocation.lat
            : DEFAULT_LAT,
          overalLocation && overalLocation.lng
            ? overalLocation.lng
            : DEFAULT_LNG,
        ],
        styleOfmenu: "",
        search: "",
        sort: shortBy,
        features: features && features.length > 0 ? features : [],
        allergen: allergen && allergen.length > 0 ? allergen : [],
        dietary: dietary && dietary.length > 0 ? dietary : [],
        lifestyle: lifestyle && lifestyle.length > 0 ? lifestyle : [],
        distance: myNearby ? 0 : myDistance * 1000,
        start: restroVisible,
        length: 3,
      })
    );
  };
  //load more Restro Ends

  return (
    <>
      <section>
        <div className="">
          <div className="d-flex justify-content-between align-items-center mb-4">
            <div id="main-content-resturants">
              <p className="brandon-Medium mb-0 restaurants-count txt-lightgray f-14">
                {searchedRestaurantsList_Data &&
                searchedRestaurantsList_Data.totalRecords
                  ? searchedRestaurantsList_Data.totalRecords
                  : "0"}
                &nbsp;Restaurants
              </p>
            </div>
            <div className="d-flex align-items-center">
              <p className="mb-0 mr-1 f-14 txt-lightgray">Sort&nbsp;by</p>
              <select
                className="custom-select shortby-select"
                value={shortBy}
                onChange={(e) => {
                  dispatch(updateAllRestaurantSort(e.target.value))
                  // setShortBy(e.target.value);
                }}
              >
                <option value="relevance">Relevance</option>
                <option value="popularity">popularity</option>
                {/* <option value="distance">Distance</option> */}
                <option value="pricel2h">Low Price</option>
                <option value="priceh2l">High Price</option>
                {/* <option value="rating" >Top Rated</option> */}
              </select>
            </div>
          </div>
          <React.Fragment>
            <div className="row ">
              <div className="col-sm-12 mb-3">
                {isLoading ? (
                  <React.Fragment>
                    <AllRestaurantMobileSkeleton />
                    <AllRestaurantMobileSkeleton />
                  </React.Fragment>
                ) : (
                  <React.Fragment>
                    {searchedRestaurantsList_Data &&
                    searchedRestaurantsList_Data.data &&
                    searchedRestaurantsList_Data.data.length > 0 ? (
                      <React.Fragment>
                        {searchedRestaurantsList_Data.data &&
                          searchedRestaurantsList_Data.data.map(
                            (data, index) => {
                              return (
                                <React.Fragment key={index}>
                                  <Link
                                    to={"/restaurant/" + data._id}
                                    style={{
                                      textDecoration: "none",
                                      color: "initial",
                                    }}
                                  >
                                    <RestaurantFilterBlockMobileComp
                                      myId={data._id ? data._id : ""}
                                      restaurant_name={
                                        data.name ? data.name : ""
                                      }
                                      restaurant_info={
                                        data.about ? data.about : ""
                                      }
                                      restaurant_pic={
                                        data.restaurantProfilePhoto
                                          ? data.restaurantProfilePhoto
                                          : ""
                                      }
                                      kmvalue={
                                        data.distance && data.distance.text
                                          ? data.distance.text
                                          : ""
                                      }
                                      rating={4.5}
                                      restaurantfeature={
                                        data.restaurantFeaturesOptionsList
                                          ? data.restaurantFeaturesOptionsList
                                          : []
                                      }
                                    />
                                  </Link>
                                </React.Fragment>
                              );
                            }
                          )}

                        <React.Fragment>
                          {fourRestroData && fourRestroData.length > 0 ? (
                            <React.Fragment>
                              {fourRestroData &&
                                fourRestroData.map((data, index) => {
                                  return (
                                    <React.Fragment key={index}>
                                      <Link
                                        to={"/restaurant/" + data._id}
                                        style={{
                                          textDecoration: "none",
                                          color: "initial",
                                        }}
                                      >
                                        <RestaurantFilterBlockMobileComp
                                          myId={data._id ? data._id : ""}
                                          restaurant_name={
                                            data.name ? data.name : ""
                                          }
                                          restaurant_info={
                                            data.about ? data.about : ""
                                          }
                                          restaurant_pic={
                                            data.restaurantProfilePhoto
                                              ? data.restaurantProfilePhoto
                                              : ""
                                          }
                                          kmvalue={
                                            data.distance && data.distance.text
                                              ? data.distance.text
                                              : ""
                                          }
                                          rating={4.5}
                                          restaurantfeature={
                                            data.restaurantFeaturesOptionsList
                                              ? data.restaurantFeaturesOptionsList
                                              : []
                                          }
                                        />
                                      </Link>
                                    </React.Fragment>
                                  );
                                })}
                            </React.Fragment>
                          ) : null}
                          {fourMoreRustLoading ? (
                            <React.Fragment>
                              <AllRestaurantMobileSkeleton />
                            </React.Fragment>
                          ) : null}
                        </React.Fragment>

                        {searchedRestaurantsList_Data &&
                        searchedRestaurantsList_Data.totalRecords <=
                          restroVisible ? null : (
                          <div className="">
                            <button
                              onClick={loadMoreRestro.bind(this)}
                              className="btn filter-morebtn w-100 theme-pink-btn"
                            >
                              <h5 className="brandon-Bold text-white mb-0">
                                <b>
                                  +
                                  {searchedRestaurantsList_Data &&
                                    searchedRestaurantsList_Data.totalRecords &&
                                    searchedRestaurantsList_Data.totalRecords -
                                      restroVisible}{" "}
                                  MORE
                                </b>
                              </h5>
                            </button>
                          </div>
                        )}
                      </React.Fragment>
                    ) : (
                      <React.Fragment>
                        <div className="w-100 d-flex align-items-center justify-content-center ">
                          <img
                            src={no_Data_Image}
                            className="img-fluid"
                            alt="img"
                          />
                        </div>
                      </React.Fragment>
                    )}
                  </React.Fragment>
                )}
              </div>
            </div>
          </React.Fragment>
        </div>
      </section>
    </>
  );
};

export default AllRestaurantMobileComp;
