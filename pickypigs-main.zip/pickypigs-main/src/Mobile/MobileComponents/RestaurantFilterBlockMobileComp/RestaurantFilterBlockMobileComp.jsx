import React from "react";
// import img1 from "../../../assets/images/restaurant/r2.png";
// import accessible_icon from "../../../assets/images/accessible.svg"
import locationgray_icon from "../../../assets/images/location-gray.svg";
// import nonveg from "../../../assets/images/non-veg.svg"
import rightarrow from "../../../assets/images/mobile_imgs/right-arrow.svg";
// import veg from "../../../assets/images/veg.svg"
import "./RestaurantFilterBlockMobileComp.scss";
import { SERVER_URL } from "../../../shared/constant";
import Dummy_Image from "../../../assets/images/restaurant_default.jpg";
import { OverlayTrigger, Tooltip } from "react-bootstrap";

const RestaurantFilterBlockMobileComp = ({
  myId,
  restaurant_name,
  restaurant_pic,
  kmvalue,
  rating,
  restaurantfeature,
  restaurant_info,
}) => {
  return (
    <>
      <section>
        <div className="filterBlockMobile-content">
          <div className="rs-infoblock">
            <div className="media  mb-3">
              {restaurant_pic ? (
                <img
                  src={`${SERVER_URL}/${restaurant_pic}`}
                  className="img-fluid rounded mr-3 rs-mob-img"
                  width="80px"
                  height="80px"
                  alt={restaurant_name ? restaurant_name : "unknown"}
                  loading="lazy"
                />
              ) : (
                <img
                  src={Dummy_Image}
                  className="img-fluid rounded mr-3 rs-mob-img"
                  width="80px"
                  height="80px"
                  alt={restaurant_name ? restaurant_name : "unknown"}
                  loading="lazy"
                />
              )}
              <div className="media-body">
                <div className="d-flex justify-content-between align-items-baseline">
                  <div className="restaurant-details brandon-Medium">
                    <div className="restaurant-mob-label d-flex justify-content-between align-items-center mb-2">
                      {restaurant_name ? (
                        <p className="mb-0 text-capitalize">
                          {restaurant_name}
                        </p>
                      ) : (
                        <p className="mb-2">Unknown</p>
                      )}
                      {/* <div className="restaurant-view">
                                            <svg width="13px" height="13px" className="mr-1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 11.095 10.556">
                                                <path id="Path_381" data-name="Path 381" d="M7-2.681,3.57-.588,4.5-4.5,1.456-7.112l4-.322L7-11.144l1.54,3.71,4.011.322L9.5-4.5,10.43-.588Z" transform="translate(-1.456 11.144)" fill="#fff"></path>
                                            </svg>
                                            <span className="view-txt brandon-Medium">{rating}</span>
                                        </div> */}
                    </div>
                    <p className="restaurant-mob-location txt-lightgray f-14 d-flex flex-wrap align-items-center mb-2">
                      <span className="position-relative location-icon">
                        <img
                          src={locationgray_icon}
                          alt={"locationgray_icon"}
                          className="img-fluid mr-2"
                          loading="lazy"
                        />
                      </span>
                      <span className="restaurant-location-address">
                        {kmvalue === "null"
                          ? "Not Available"
                          : `${kmvalue} from you `}
                      </span>
                    </p>
                  </div>
                </div>
              </div>
            </div>
            <div className="foodtypes-wrap d-flex flex-wrap mb-2">
              {restaurantfeature && restaurantfeature.length > 0 ? (
                <React.Fragment>
                  {restaurantfeature && restaurantfeature.length > 5 ? (
                    <React.Fragment>
                      {restaurantfeature &&
                        restaurantfeature.slice(0, 4).map((data, index) => {
                          return (
                            <React.Fragment key={index}>
                              <OverlayTrigger
                                placement="bottom"
                                overlay={
                                  <Tooltip id={`tooltip-${index}`}>
                                    {data.name ? data.name : "Unknown"}
                                  </Tooltip>
                                }
                              >
                                <div className="food-types mr-3 mb-2 d-flex justify-content-center align-items-center">
                                  <img
                                    src={`${SERVER_URL}/${data.image}`}
                                    alt={"icon"}
                                    className="img-fluid"
                                    loading="lazy"
                                  />
                                </div>
                              </OverlayTrigger>
                            </React.Fragment>
                          );
                        })}
                      <OverlayTrigger
                        placement="bottom"
                        overlay={
                          <Tooltip id={`tooltipOne`}>
                            {restaurantfeature &&
                              restaurantfeature
                                .slice(3)
                                .map((data2, index2) => {
                                  return (
                                    <React.Fragment key={index2}>
                                      {index2 ? ", " : ""}
                                      {data2.name}
                                    </React.Fragment>
                                  );
                                })}
                          </Tooltip>
                        }
                      >
                        <div className="food-types mr-3 mb-2 d-flex justify-content-center align-items-center">
                          <small
                            className="txt-lightgray"
                            style={{ textAlign: "center", fontSize: 9 }}
                          >
                            +{restaurantfeature && restaurantfeature.length - 4}{" "}
                            More
                          </small>
                        </div>
                      </OverlayTrigger>
                    </React.Fragment>
                  ) : (
                    <React.Fragment>
                      {restaurantfeature &&
                        restaurantfeature.map((data, index) => {
                          return (
                            <React.Fragment key={index}>
                              <OverlayTrigger
                                placement="bottom"
                                overlay={
                                  <Tooltip id={`tooltipTwo-${index}`}>
                                    {data.name ? data.name : "Unknown"}
                                  </Tooltip>
                                }
                              >
                                <div className="food-types mr-3 mb-2 d-flex justify-content-center align-items-center">
                                  <img
                                    src={`${SERVER_URL}/${data.image}`}
                                    alt={"icon"}
                                    className="img-fluid"
                                    loading="lazy"
                                  />
                                </div>
                              </OverlayTrigger>
                            </React.Fragment>
                          );
                        })}
                    </React.Fragment>
                  )}
                </React.Fragment>
              ) : null}
            </div>

            <div className="foodtypes-details txt-lightgray f-14">
              {restaurant_info ? <p>{restaurant_info}</p> : <p>Na</p>}
            </div>
            <div className="border-top mt-2 mb-2"></div>
            <div className="restaurant-view-walk d-flex justify-content-between align-items-center">
              {/* <p className="m-0 f-14">5 Mins Walk</p> */}
              <p className="m-0 f-14"></p>
              <div className="d-flex align-items-center">
                <span className="mr-2 f-14">View Detail</span>
                <img
                  width="6px"
                  src={rightarrow}
                  className="img-fluid"
                  loading="lazy"
                  alt="img"
                />
              </div>
              {/* <Link className="f-14" to={'/restaurant/' + myId}>
                                <span className="mr-2">View Detail</span>
                                <img width="6px" src={rightarrow} className="img-fluid" loading="lazy" alt="img"/>
                            </Link> */}
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default RestaurantFilterBlockMobileComp;
