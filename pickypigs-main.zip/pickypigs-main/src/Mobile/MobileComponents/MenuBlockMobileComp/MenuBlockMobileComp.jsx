import React from 'react'
// import accessible_icon from "../../../assets/images/accessible.svg"
// import locationgray_icon from "../../../assets/images/location-gray.svg"
// import nonveg from "../../../assets/images/non-veg.svg"
// import veg from "../../../assets/images/veg.svg"
import "./MenuBlockMobileComp.scss"
// import restaurant_P1 from "../../../assets/images/restaurant/r1.png"
import { SERVER_URL } from '../../../shared/constant'
// import favorite_icon from "../../../assets/images/mobile_imgs/heart-icon.svg"
// import Dummy_Icon from "../../../assets/images/dummy_icon.svg"
import Dummy_Image from "../../../assets/images/restaurant_default.jpg"
import {OverlayTrigger,Tooltip} from "react-bootstrap";


// let defaultIcon=[{name:"Unknown",image:Dummy_Icon}]

const MenuBlockMobileComp = ({dish_name,dish_image,dish_priceunit,dish_price,dish_menu,dish_description,dish_allergy,dish_new_tag,dish_available_tag}) => {
    return (
            <div className="restaurantMenuBlockMobile-wrapper mb-4 pb-2">
                <div>
                    <div className="restaurant-img position-relative">
                            {dish_image?
                                <img src={`${SERVER_URL}/${dish_image}`} className={`img-fluid w-100 ${dish_available_tag?null:"gray_shadow"}`} alt={"restaurant_P1"} />
                            :
                                <img src={Dummy_Image} className={`img-fluid w-100 ${dish_available_tag? null: "gray_shadow"}`} alt={"restaurant_P1"} />
                            }
                            {dish_new_tag&&dish_new_tag?
                                <label className={`newdish-label ${dish_available_tag?null:"gray_shadow"}`}>New</label>
                                // <label className="newdish-favorite">
                                //     <img src={favorite_icon} className="img-fluid" />
                                // </label>
                            :
                                null
                            }
                            {dish_available_tag&&dish_available_tag?
                                null
                            :
                                <label className="available-label">Pigged Out</label>
                            }
                        <div className={`restaurant-details brandon-Medium ${dish_available_tag?null:"gray_shadow"}`}>
                            <div className="d-flex justify-content-between align-items-baseline">
                                <p className="mb-0 text-white position-relative favorite-dish-name text-capitalize">{dish_name?dish_name:'Unknown'}</p>
                                {/* <div className="restaurant-view">
                                    <svg width="13px" height="13px" className="mr-1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 11.095 10.556">
                                        <path id="Path_381" data-name="Path 381" d="M7-2.681,3.57-.588,4.5-4.5,1.456-7.112l4-.322L7-11.144l1.54,3.71,4.011.322L9.5-4.5,10.43-.588Z" transform="translate(-1.456 11.144)" fill="#fff"></path>
                                    </svg>
                                    <span className="view-txt text-white brandon-Medium">{rating}</span>
                                </div> */}
                            </div>
                            <div className="whatmenu-price f-14 d-flex justify-content-between pt-1 pb-2 position-relative">
                                <span className="text-white">{dish_priceunit?dish_priceunit:'$'} {dish_price?parseFloat(dish_price).toFixed(2):'00.00'}</span>
                                {/* <div className="whatmenu-daydetail text-white">
                                    <ul className="list-style-none pl-0 d-flex flex-wrap align-items-center mb-2">
                                        <li className="ml-xs-0"></li>
                                        {dish_menu&&dish_menu.length>0?
                                            <React.Fragment>
                                                {dish_menu&&dish_menu.map((data,index)=>{
                                                    return(
                                                        <React.Fragment key={index}>
                                                            {index?<li className="dot-icon ml-2"></li>:''}
                                                            <li className="ml-2 ml-xs-0 text-capitalize">{data.name}</li>
                                                        </React.Fragment>
                                                    )
                                                })}
                                            </React.Fragment>
                                        :
                                            <React.Fragment>
                                                <li className="ml-xs-0"></li>
                                                <li className="ml-2 ml-xs-0 text-capitalize">Na</li>
                                            </React.Fragment>
                                        }
                                        
                                    </ul>
                                </div> */}
                            </div>
                            <div className="whatmeu-types d-flex flex-wrap">
                                {dish_allergy&&dish_allergy.length>0?
                                    <React.Fragment>
                                        {dish_allergy && dish_allergy.length>4?
                                            <React.Fragment>
                                                {dish_allergy && dish_allergy.slice(0,3).map((data, index) => {
                                                    return (
                                                        <React.Fragment key={index}>
                                                            <OverlayTrigger placement="bottom" overlay={<Tooltip id={`tooltip-${index}`}>{data.name?data.name:"Unknown"}</Tooltip>} >
                                                                <div className="whatmenu-list mr-3 mb-2 d-flex justify-content-center align-items-center">
                                                                    <img src={`${SERVER_URL}/${data.image}`} alt={"icon"} className="img-fluid"  />
                                                                </div>
                                                            </OverlayTrigger>
                                                        </React.Fragment>
                                                    )
                                                })}
                                                <OverlayTrigger placement="bottom" overlay={<Tooltip id={`tooltipOne`}>{dish_allergy && dish_allergy.slice(3).map((data2,index2)=>{return(<React.Fragment key={index2}>{index2 ? ", " : ''}{data2.name}</React.Fragment>)})}</Tooltip>} >
                                                    <div className="whatmenu-list mr-3 mb-2 d-flex justify-content-center align-items-center">
                                                        <small style={{textAlign:"center",fontSize:10,flexWrap:"wrap"}}>+{dish_allergy && dish_allergy.length-3} More</small>
                                                    </div>
                                                </OverlayTrigger>
                                            </React.Fragment>
                                        :
                                            <React.Fragment>
                                                {dish_allergy && dish_allergy.map((data, index) => {
                                                    return (
                                                        <React.Fragment key={index}>
                                                            <OverlayTrigger placement="bottom" overlay={<Tooltip id={`tooltipTwo-${index}`}>{data.name?data.name:"Unknown"}</Tooltip>} >
                                                                <div className="whatmenu-list mr-3 mb-2 d-flex justify-content-center align-items-center">
                                                                    <img src={`${SERVER_URL}/${data.image}`} alt={"icon"} className="img-fluid"  />
                                                                </div>
                                                            </OverlayTrigger>
                                                        </React.Fragment>
                                                    )
                                                })}
                                            </React.Fragment>
                                        }
                                    
                                    </React.Fragment>
                                    :
                                    null
                                }
                               
                            </div>
                            
                        </div>
                    </div>
                    
                </div>
            </div>
    )
}

export default MenuBlockMobileComp
