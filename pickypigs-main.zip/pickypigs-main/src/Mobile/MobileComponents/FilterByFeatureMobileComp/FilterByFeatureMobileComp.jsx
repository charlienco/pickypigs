import React, { useEffect, useState } from "react";
import Slider from "react-slick";
import "./FilterByFeatureMobileComp.scss";
import { getFastBarData } from "../../../redux/actions/allergyAction";
import { useDispatch, useSelector } from "react-redux";
import { SERVER_URL } from "../../../shared/constant";
import { updatePreferenceFilter } from "../../../redux/actions/globalPreferenceFilterAction";

function FilterByFeatureMobileComp() {
  let settings = {
    arrows: false,
    // centerMode: false,
    infinite: false,
    swipeToSlide: true,
    slidesToShow: 12,
    slidesToScroll: 1,
    variableWidth: true,
    responsive: [
      {
        breakpoint: 1200,
        settings: {
          slidesToShow: 10,
        },
      },
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 9,
        },
      },
      {
        breakpoint: 992,
        settings: {
          slidesToShow: 8,
        },
      },
      {
        breakpoint: 768,
        settings: {
          slidesToShow: 6,
        },
      },
      {
        breakpoint: 600,
        settings: {
          slidesToShow: 5,
        },
      },
      {
        breakpoint: 425,
        settings: {
          slidesToShow: 4,
        },
      },
      {
        breakpoint: 320,
        settings: {
          slidesToShow: 3,
        },
      },
    ],
  };
  const dispatch = useDispatch();

  const [makingFalse, setMakingFalse] = React.useState(false);

  let [features, setFeatures] = useState([]);
  let [allergens, setAllergens] = useState([]);
  let [dietarys, setDietarys] = useState([]);
  let [lifestyles, setlifestyles] = useState([]);

  useEffect(() => {
    dispatch(getFastBarData());
    // eslint-disable-next-line
  }, []);

  let allAllergy_data = useSelector((state) => {
    return state.allergy;
  });

  let { fastbar_Data } = allAllergy_data;

  const handleFeatures = (e) => {
    e.preventDefault();
    // console.log("ssss")
    const selectedFeature = fastbar_Data.data.find(element => element._id === e.target.id);
    if (selectedFeature.type === "allergen") {
      if (allergens.indexOf(e.target.id) !== -1) {
        let Index = allergens.indexOf(e.target.id);
        if (Index > -1) {
          setAllergens(
            allergens.filter((myallergens) => myallergens !== e.target.id)
          );
        }
      } else {
        setAllergens([...allergens, e.target.id]);
      }
    }
    if (selectedFeature.type === "dietary") {
      if (dietarys.indexOf(e.target.id) !== -1) {
        let Index = dietarys.indexOf(e.target.id);
        if (Index > -1) {
          setDietarys(
            dietarys.filter((mydietarys) => mydietarys !== e.target.id)
          );
        }
      } else {
        setDietarys([...dietarys, e.target.id]);
      }
    }
    if (selectedFeature.type === "lifestyle") {
      if (lifestyles.indexOf(e.target.id) !== -1) {
        let Index = lifestyles.indexOf(e.target.id);
        if (Index > -1) {
          setlifestyles(
            lifestyles.filter((mylifestyles) => mylifestyles !== e.target.id)
          );
        }
      } else {
        setlifestyles([...lifestyles, e.target.id]);
      }
    }
    if (selectedFeature.type === "features") {
      if (features.indexOf(e.target.id) !== -1) {
        let Index = features.indexOf(e.target.id);
        if (Index > -1) {
          setFeatures(
            features.filter((myfeatures) => myfeatures !== e.target.id)
          );
        }
      } else {
        setFeatures([...features, e.target.id]);
      }
    }
  };

  const handleFeatureRedirection = () => {
    // if (features && features.length > 0) {
    //   dispatch(updatePreferenceFilter("featuredata", features));
    //   setMakingFalse(true);
    //   const mainContentDiv = document.getElementById("main-content-resturants");
    //   if (mainContentDiv)
    //     mainContentDiv.scrollIntoView({
    //       behavior: "smooth",
    //       block: "start",
    //       //   inline: "start",
    //     });
    // }


    // if (features && features.length > 0) {
    dispatch(updatePreferenceFilter("featuredata", features));
    // }
    // if (allergens && allergens.length > 0) {
    dispatch(updatePreferenceFilter("allergendata", allergens));
    // }
    // if (dietarys && dietarys.length > 0) {
    dispatch(updatePreferenceFilter("dietarydata", dietarys));
    // }
    // if (lifestyles && lifestyles.length > 0) {
    dispatch(updatePreferenceFilter("lifestyledata", lifestyles));
    // }

    if ((allergens && allergens.length > 0) || (dietarys && dietarys.length > 0) || (lifestyles && lifestyles.length > 0) || (features && features.length > 0)) {
      setMakingFalse(true);
      const mainContentDiv = document.getElementById("main-content-resturants");
      if (mainContentDiv) {
        mainContentDiv.scrollIntoView({
          behavior: "smooth",
          block: "start",
          //   inline: "start",
        });
      }
    }
  };
  useEffect(() => {
    if (makingFalse === true) {
      setMakingFalse(false);
      //   history.push("/allrestaurant");
    }
    // eslint-disable-next-line
  }, [makingFalse === true]);

  return (
    <div className="filterFitureMobile-container">
      <Slider {...settings} className="filterfeature-wrapper">
        {fastbar_Data &&
          fastbar_Data.data &&
          fastbar_Data.data.map((data, index) => {
            return (
              <React.Fragment key={index}>
                <button
                  id={data._id}
                  onClick={handleFeatures}
                  className={`btn filter-subwrapper ${
                    // features.indexOf(data._id) !== -1 && "active"
                    (data.type === "allergen") ? allergens.indexOf(data._id) !== -1 && "active" : (data.type === "dietary") ? dietarys.indexOf(data._id) !== -1 && "active" : (data.type === "lifestyle") ? lifestyles.indexOf(data._id) !== -1 && "active" : features.indexOf(data._id) !== -1 && "active"
                    }`}
                >
                  <div
                    id={data._id}
                    className="filter-icon"
                    onClick={handleFeatures}
                  >
                    <img
                      id={data._id}
                      src={`${SERVER_URL}/${data.image}`}
                      className="img-fluid"
                      alt="img"
                      loading="lazy"
                    />
                  </div>
                  <p
                    id={data._id}
                    onClick={handleFeatures}
                    className="mt-2 text-dark text-link f-14 brandon-Medium text-capitalize m-0"
                  >
                    {data.name ? data.name : ""}
                  </p>
                </button>
              </React.Fragment>
            );
          })}
      </Slider>
      {
        // features && features.length > 0 ? (
        ((allergens && allergens.length > 0) || (dietarys && dietarys.length > 0) || (lifestyles && lifestyles.length > 0) || (features && features.length > 0)) ? (
          <span className="d-flex justify-content-end mb-5">
            <button
              type="button"
              onClick={() => {
                handleFeatureRedirection();
              }}
              className="theme-pink-btn text-white"
              style={{ width: 40, height: 40, position: "absolute", bottom: -35 }}
            >
              Go
            </button>
          </span>
        ) : null}
    </div>
  );
}

export default FilterByFeatureMobileComp;
