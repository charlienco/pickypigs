import React,{useState} from "react";
import clockicon from "../../../assets/images/restaurant-dish/clock-icon.svg";
import moment from 'moment';
import { Button, Collapse } from "react-bootstrap";
import './OpentimeMobileComp.scss';


const OpentimeMobileComp=({restaurant_time})=>{
    const [open, setOpen] = useState(false);
    let myDay=moment().format('dddd');
    let myTime=moment();
    // const restaurantTime1=`${moment().format('MMMM Do YYYY')}, 7:00 am`;
    // const restaurantTime2=`${moment().format('MMMM Do YYYY')}, 9:00 am`;
    // const restaurantTime3=`${moment().format('MMMM Do YYYY')}, 12:30 am`;
    // const restaurantTime4=`${moment().format('MMMM Do YYYY')}, 11:30 pm`;

    const compareData=(open,close,now)=>{
        // (moment(open, 'MMMM Do YYYY, h:mm a').isValid() && now.isAfter(moment(open, 'MMMM Do YYYY, h:mm a')) )&&(moment(close, 'MMMM Do YYYY, h:mm a').isValid() && now.isBefore(moment(close, 'MMMM Do YYYY, h:mm a')) )?"Open now":">Closed now"
        if (
            moment(open, 'MMMM Do YYYY, h:mm a').isValid() &&
            now.isAfter(moment(open, 'MMMM Do YYYY, h:mm a'))
          ) {
            console.log('open =>');
            if (
              moment(close, 'MMMM Do YYYY, h:mm a').isValid() &&
              now.isBefore(moment(close, 'MMMM Do YYYY, h:mm a'))
            ) {
              return 'Open Now';
            } else {
              console.log('else......');
              return 'Closed Now';
            }
          } else {
            if (
              moment(open, 'MMMM Do YYYY, h:mm a').isValid() &&
              now.isBefore(moment(close, 'MMMM Do YYYY, h:mm a'))
            ) {
              return 'Opening Soon';
            }
            return 'Closed Today';
          }
    }

    function tConv24(time24) {
        var ts = time24;
        var H = +ts.substr(0, 2);
        var h = (H % 12) || 12;
        h = (h < 10)?("0"+h):h;  // leading 0 at the left for 1 digit hours
        var ampm = H < 12 ? " AM" : " PM";
        ts = h + ts.substr(2, 3) + ampm;
        return ts;
      };

      function tConvsmaill24(time24) {
        var ts = time24;
        var H = +ts.substr(0, 2);
        var h = (H % 12) || 12;
        h = (h < 10)?("0"+h):h;  // leading 0 at the left for 1 digit hours
        var ampm = H < 12 ? " am" : " pm";
        ts = h + ts.substr(2, 3) + ampm;
        return ts;
      };
    return(
        <>
        <section className="openTimeMobile-content">
        <div className="rs-opendropdown w-100 position-relative">
                            <Button onClick={() => setOpen(!open)} aria-controls="example-collapse-text" aria-expanded={open} className={`d-flex rs-opendropdown-btn w-100 ${open?"active":null}`}>
                                <div className="rs-timeimg mr-3">
                                    <img width="20px" src={clockicon} alt={"clockicon"} className="img-fluid" loading="lazy"/>
                                </div>
                                
                                <div className={`text-left ${open ? "" : null}`}>
                                    {restaurant_time&&restaurant_time.time&&restaurant_time.time.length>0?
                                        <React.Fragment>
                                            {restaurant_time&&restaurant_time.time&&restaurant_time.time.map((data,index)=>{
                                                return(
                                                    <React.Fragment key={index}>
                                                        {myDay===data.day?
                                                            <React.Fragment>
                                                                {data&&data.isSelected&&data.isSelected?
                                                                    <React.Fragment>
                                                                        {data&&data.timeList&&data.timeList.length>0?
                                                                            <React.Fragment>
                                                                                {restaurant_time&&restaurant_time.isMultiTime&&restaurant_time.isMultiTime?
                                                                                    <p className="mb-1 text-dark">
                                                                                        {compareData( `${moment().format('MMMM Do YYYY')}, ${data&&data.timeList&&data.timeList[0]&&data.timeList[0].startTime&&tConvsmaill24(data.timeList[0].startTime)}` , `${moment().format('MMMM Do YYYY')}, ${data&&data.timeList&&data.timeList[1]&&data.timeList[1].endTime&&tConvsmaill24(data.timeList[1].endTime)}` , myTime)}
                                                                                    </p>
                                                                                :    
                                                                                    <p className="mb-1 text-dark">
                                                                                        {compareData( `${moment().format('MMMM Do YYYY')}, ${data&&data.timeList&&data.timeList[0]&&data.timeList[0].startTime&&tConvsmaill24(data.timeList[0].startTime)}` , `${moment().format('MMMM Do YYYY')}, ${data&&data.timeList&&data.timeList[0]&&data.timeList[0].endTime&&tConvsmaill24(data.timeList[0].endTime)}` , myTime)}
                                                                                    </p>
                                                                                }
                                                                            </React.Fragment>
                                                                        :
                                                                            null
                                                                        }
                                                                    </React.Fragment>
                                                                :
                                                                    <React.Fragment>
                                                                        <p className="mb-1 text-dark">Closed Today</p>
                                                                    </React.Fragment>
                                                                }
                                                            </React.Fragment>
                                                        :
                                                            null
                                                        }
                                                    </React.Fragment>
                                                )
                                            })}
                                        </React.Fragment>
                                    :
                                        <p className="mb-1 text-dark">Closed/Data Unavailable</p>
                                    }                                    
                                    <div>
                                        {restaurant_time&&restaurant_time.time&&restaurant_time.time.length>0?
                                            <React.Fragment>
                                                {restaurant_time&&restaurant_time.time&&restaurant_time.time.map((data,index)=>{
                                                    return(
                                                        <React.Fragment key={index}>
                                                            {myDay===data.day?
                                                                <React.Fragment >
                                                                    <table>
                                                                        <thead>
                                                                            <tr className="vertical-align-top">
                                                                                <td>
                                                                                    <p className="txt-lightgray mb-0 brandon-Medium mr-2">{data.day}</p>
                                                                                    </td><td>
                                                                                    </td><td>
                                                                                    <React.Fragment>
                                                                                        {data&&data.isSelected&&data.isSelected?
                                                                                            <React.Fragment>
                                                                                                {data&&data.timeList&&data.timeList.length>0?
                                                                                                    <React.Fragment>
                                                                                                        {restaurant_time&&restaurant_time.isTime24Hours&&restaurant_time.isTime24Hours?
                                                                                                            <React.Fragment>
                                                                                                                <p className="txt-lightgray mb-0 brandon-Medium">
                                                                                                                    {data&&data.timeList&&data.timeList[0]&&data.timeList[0].startTime?data.timeList[0].startTime:'-'} - {data&&data.timeList&&data.timeList[0]&&data.timeList[0].endTime?data.timeList[0].endTime:'-'}
                                                                                                                </p>
                                                                                                                {restaurant_time&&restaurant_time.isMultiTime&&restaurant_time.isMultiTime?
                                                                                                                    <p className="txt-lightgray mb-0 brandon-Medium">
                                                                                                                        {data&&data.timeList&&data.timeList[1]&&data.timeList[1].startTime?data.timeList[1].startTime:'-'} - {data&&data.timeList&&data.timeList[1]&&data.timeList[1].endTime?data.timeList[1].endTime:'-'}
                                                                                                                    </p>
                                                                                                                :    
                                                                                                                    null
                                                                                                                }
                                                                                                            </React.Fragment>
                                                                                                        :
                                                                                                            <React.Fragment>
                                                                                                                <p className="txt-lightgray mb-0 brandon-Medium">{data&&data.timeList&&data.timeList[0]&&data.timeList[0].startTime?tConv24(data.timeList[0].startTime):'-'} - {data&&data.timeList&&data.timeList[0]&&data.timeList[0].endTime?tConv24(data.timeList[0].endTime):'-'}</p>
                                                                                                                {restaurant_time&&restaurant_time.isMultiTime&&restaurant_time.isMultiTime?
                                                                                                                    <p className="txt-lightgray mb-0 brandon-Medium">{data&&data.timeList&&data.timeList[1]&&data.timeList[1].startTime?tConv24(data.timeList[1].startTime):'-'} - {data&&data.timeList&&data.timeList[1]&&data.timeList[1].endTime?tConv24(data.timeList[1].endTime):'-'}</p>
                                                                                                                :    
                                                                                                                    null
                                                                                                                }
                                                                                                            </React.Fragment>
                                                                                                        }
                                                                                                    </React.Fragment>
                                                                                                    
                                                                                                    :
                                                                                                    null
                                                                                                }
                                                                                            </React.Fragment>
                                                                                            :
                                                                                            <React.Fragment>
                                                                                                <p className="txt-lightgray mb-0 brandon-Medium">
                                                                                                    Closed / Holiday
                                                                                                </p>
                                                                                            </React.Fragment>
                                                                                        }
                                                                                    </React.Fragment>
                                                                                </td>
                                                                            </tr>
                                                                        </thead>
                                                                    </table>
                                                                </React.Fragment>
                                                            :
                                                                null
                                                            }
                                                        </React.Fragment>
                                                    )
                                                })}
                                            </React.Fragment>
                                        :
                                            <p className="mb-1 text-dark">No Data Available</p>
                                        }

                                    </div>
                                </div>
                            </Button>
                            <Collapse in={open}>
                                <div id="example-collapse-text">
                                    <table>
                                        <tbody>
                                            {restaurant_time&&restaurant_time.time&&restaurant_time.time.length>0?
                                                <React.Fragment>
                                                    {restaurant_time&&restaurant_time.time&&restaurant_time.time.map((data,index)=>{
                                                        return(
                                                            <React.Fragment key={index}>
                                                                <tr className="vertical-align-top">
                                                                    <td>
                                                                        <p className={`txt-lightgray mb-2 ${myDay===data.day&&"pink-txt brandon-Medium"}`}>{data.day}</p>
                                                                        </td><td>
                                                                        </td><td>
                                                                        <React.Fragment>
                                                                            {data&&data.isSelected&&data.isSelected?
                                                                                <React.Fragment>
                                                                                    {data&&data.timeList&&data.timeList.length>0?
                                                                                        <React.Fragment>
                                                                                            {restaurant_time&&restaurant_time.isTime24Hours&&restaurant_time.isTime24Hours?
                                                                                                <React.Fragment>
                                                                                                    <p className={`txt-lightgray mb-2 ${myDay===data.day&&"pink-txt brandon-Medium"}`}>
                                                                                                        {data&&data.timeList&&data.timeList[0]&&data.timeList[0].startTime?data.timeList[0].startTime:'-'} - {data&&data.timeList&&data.timeList[0]&&data.timeList[0].endTime?data.timeList[0].endTime:'-'}
                                                                                                    </p>
                                                                                                    {restaurant_time&&restaurant_time.isMultiTime&&restaurant_time.isMultiTime?
                                                                                                        <p className={`txt-lightgray mb-2 ${myDay===data.day&&"pink-txt brandon-Medium"}`}>
                                                                                                            {data&&data.timeList&&data.timeList[1]&&data.timeList[1].startTime?data.timeList[1].startTime:'-'} - {data&&data.timeList&&data.timeList[1]&&data.timeList[1].endTime?data.timeList[1].endTime:'-'}
                                                                                                        </p>
                                                                                                    :    
                                                                                                        null
                                                                                                    }
                                                                                                </React.Fragment>
                                                                                            :
                                                                                                <React.Fragment>
                                                                                                    <p className={`txt-lightgray mb-2 ${myDay===data.day&&"pink-txt brandon-Medium"}`}>{data&&data.timeList&&data.timeList[0]&&data.timeList[0].startTime?tConv24(data.timeList[0].startTime):'-'} - {data&&data.timeList&&data.timeList[0]&&data.timeList[0].endTime?tConv24(data.timeList[0].endTime):'-'}</p>
                                                                                                    {restaurant_time&&restaurant_time.isMultiTime&&restaurant_time.isMultiTime?
                                                                                                        <p className={`txt-lightgray mb-2 ${myDay===data.day&&"pink-txt brandon-Medium"}`}>{data&&data.timeList&&data.timeList[1]&&data.timeList[1].startTime?tConv24(data.timeList[1].startTime):'-'} - {data&&data.timeList&&data.timeList[1]&&data.timeList[1].endTime?tConv24(data.timeList[1].endTime):'-'}</p>
                                                                                                    :    
                                                                                                        null
                                                                                                    }
                                                                                                </React.Fragment>
                                                                                            }
                                                                                        </React.Fragment>
                                                                                        
                                                                                        :
                                                                                        null
                                                                                    }
                                                                                </React.Fragment>
                                                                                :
                                                                                <React.Fragment>
                                                                                    <p className={`txt-lightgray mb-2 ${myDay===data.day&&"pink-txt brandon-Medium"}`}>
                                                                                        Closed / Holiday
                                                                                    </p>
                                                                                </React.Fragment>
                                                                            }
                                                                        </React.Fragment>
                                                                    </td>
                                                                </tr>
                                                            </React.Fragment>
                                                        )
                                                    })}
                                                </React.Fragment>
                                            :
                                                <p>No Data Available</p>
                                            }
                                         </tbody>
                                    </table>
                                </div>
                            </Collapse>
                        </div>
        </section>
        </>
    )
}

export default OpentimeMobileComp;