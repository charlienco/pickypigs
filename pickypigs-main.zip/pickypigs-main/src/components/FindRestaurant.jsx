import React from 'react'

const FindRestaurant= () =>{
    return (
        <div>

        </div>
    )
}

export default FindRestaurant
