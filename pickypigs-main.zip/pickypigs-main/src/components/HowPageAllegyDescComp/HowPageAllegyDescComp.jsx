import React, { useEffect } from "react";
import { SERVER_URL } from "../../shared/constant";

import Popper from "@material-ui/core/Popper";
import "./HowPageAllegyDescComp.scss";
import { useDispatch, useSelector } from "react-redux";
import {
  getAllAllergyData,
  getAllDietaryData,
  getAllLifestyleData,
  getAllRestaurantFeaturesData,
} from "../../redux/actions/allergyAction";
import Card from "../Card";

const HowPageAllegyDescComp = () => {
  const [open, setOpen] = React.useState(false);
  const [openDietary, setOpenDietary] = React.useState(false);
  const [openLifeStyle, setOpenLifeStyle] = React.useState(false);
  const [openRestaurant, setOpenRestaurant] = React.useState(false);
  const [anchorEl, setAnchorEl] = React.useState(null);
  const [modalData, setModalData] = React.useState(null);
  const [arrowRef, setArrowRef] = React.useState(null);

  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
    setOpenLifeStyle(false);
    setOpenRestaurant(false);
    setOpenDietary(false);
    setOpen(true);
  };

  const handleDietryClick = (e) => {
    setAnchorEl(e.currentTarget);
    setOpen(false);
    setOpenLifeStyle(false);
    setOpenRestaurant(false);
    setOpenDietary(true);
  };

  const handleLifeStyleClick = (e) => {
    setAnchorEl(e.currentTarget);
    setOpen(false);
    setOpenDietary(false);
    setOpenRestaurant(false);
    setOpenLifeStyle(true);
  };

  const handleRestaurantClick = (e) => {
    setAnchorEl(e.currentTarget);
    setOpen(false);
    setOpenDietary(false);
    setOpenLifeStyle(false);
    setOpenRestaurant(true);
  };

  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(getAllAllergyData());
    dispatch(getAllDietaryData());
    dispatch(getAllLifestyleData());
    dispatch(getAllRestaurantFeaturesData());
  }, [dispatch]);

  let allAllergy_data = useSelector((state) => {
    return state.allergy;
  });

  let { allergy_Data, dietary_Data, lifestyle_Data, restaurantFeatures_Data } =
    allAllergy_data;

  return (
    <>
      <br />
      <br />
      <br />
      <br />
      <section className="HowPageAllegyDescComp-container">
        <div className="container">
          <div className="howpagedesc-wrapper">
            {/* <h1>HowPageAllegyDescComp</h1> */}
            <p className="text-center mb-5">
              We have turned all the requirements into icons so you can easily
              find your needs. Here is an idea of what everything{" "}
              <br className="d-none d-xl-block" /> actually means.
            </p>
            <div className="row">
              <div className="col-sm-12">
                <p className="brandon-Medium text-uppercase f-14">
                  <b>Allergens</b>
                </p>

                <div className="allergen-btn-wrapper d-flex align-items-start flex-wrap">
                  {allergy_Data &&
                    allergy_Data.data &&
                    allergy_Data.data.map((data, index) => {
                      return (
                        <div
                          onClick={(e) => {
                            handleClick(e);
                            setModalData(data);
                          }}
                        >
                          <Card data={data} index={index} />
                        </div>
                      );
                    })}
                </div>
                <Popper
                  className="allergens-modal-wrapper"
                  placement="bottom-start"
                  disablePortal={true}
                  open={open}
                  anchorEl={anchorEl}
                  modifiers={{
                    flip: {
                      enabled: false,
                    },
                    preventOverflow: {
                      enabled: true,
                      boundariesElement: "window",
                    },
                    arrow: {
                      enabled: true,
                      element: arrowRef,
                    },
                  }}
                >
                  {true ? <span className="arrow" ref={setArrowRef} /> : null}

                  <React.Fragment>
                    <div className="bg-white allergens-modal">
                      <div className="allergens-heading d-flex align-items-center justiy-content-between position-relative">
                        <div className="allergens-inner-head d-flex align-items-center">
                          <div className="allergens-icon mr-4 d-flex align-items-center justify-content-center">
                            <img
                              src={`${SERVER_URL}/${
                                modalData && modalData.image
                              }`}
                              alt="modalData"
                              className="img-fluid"
                            />
                          </div>
                          <h6 className="allergens-title text-uppercase brandon-Medium fw-600 mb-0">
                            {modalData && modalData.name}
                          </h6>
                        </div>
                        <button
                          className="allergensclose-btn"
                          onClick={() => {
                            setOpen(false);
                          }}
                        >
                          x
                        </button>
                      </div>
                      <div className="col-sm-12">
                        <div className="row">
                          <div className="col-sm-12 pl-0 pr-0">
                            <div className="border mt-3 mb-3"></div>
                          </div>
                        </div>
                      </div>
                      {modalData && modalData.description ? (
                        <div className="allergens-info">
                          <p className="mb-0">
                            {modalData && modalData.description? modalData.description:""}.
                          </p>
                        </div>
                      ):""}
                    </div>
                  </React.Fragment>
                </Popper>
              </div>
            </div>
            <div className="col-sm-12">
              <div className="row">
                <div className="col-sm-12 mt-2 pl-0 pr-0 mb-2">
                  <div className="border mt-4 mb-4"></div>
                </div>
              </div>
            </div>
            <div className="row">
              <div className="col-sm-12 mt-2">
                <p className="brandon-Medium txt-darkgreen">
                  DIETARY PREFERENCES
                </p>
                <div className="allergen-btn-wrapper d-flex flex-wrap align-items-start">
                  {dietary_Data &&
                    dietary_Data.data &&
                    dietary_Data.data.map((data, index) => {
                      return (
                        <div
                          onClick={(e) => {
                            handleDietryClick(e);
                            setModalData(data);
                          }}
                        >
                          <Card data={data} index={index} />
                        </div>
                      );
                    })}
                </div>
                <Popper
                  className="allergens-modal-wrapper"
                  placement="bottom-start"
                  disablePortal={true}
                  open={openDietary}
                  anchorEl={anchorEl}
                  modifiers={{
                    flip: {
                      enabled: false,
                    },
                    preventOverflow: {
                      enabled: true,
                      boundariesElement: "window",
                    },
                    arrow: {
                      enabled: true,
                      element: arrowRef,
                    },
                  }}
                >
                  {true ? <span className="arrow" ref={setArrowRef} /> : null}

                  <React.Fragment>
                    <div className="bg-white allergens-modal">
                      <div className="allergens-heading d-flex align-items-center justiy-content-between position-relative">
                        <div className="allergens-inner-head d-flex align-items-center">
                          <div className="allergens-icon mr-4 d-flex align-items-center justify-content-center">
                            <img
                              src={`${SERVER_URL}/${
                                modalData && modalData.image
                              }`}
                              alt="modalData"
                              className="img-fluid"
                            />
                          </div>
                          <h6 className="allergens-title text-uppercase brandon-Medium fw-600 mb-0">
                            {modalData && modalData.name}
                          </h6>
                        </div>
                        <button
                          className="allergensclose-btn"
                          onClick={() => {
                            setOpenDietary(false);
                          }}
                        >
                          x
                        </button>
                      </div>
                      <div className="col-sm-12">
                        <div className="row">
                          <div className="col-sm-12 pl-0 pr-0">
                            <div className="border mt-3 mb-3"></div>
                          </div>
                        </div>
                      </div>
                      {modalData && modalData.description ? (
                        <div className="allergens-info">
                          <p className="mb-0">
                            {modalData && modalData.description? modalData.description:""}.
                          </p>
                        </div>
                      ):""}
                    </div>
                  </React.Fragment>
                </Popper>
              </div>
            </div>
            <div className="col-sm-12">
              <div className="row">
                <div className="col-sm-12 mt-2 pl-0 pr-0 mb-2">
                  <div className="border mt-4 mb-4"></div>
                </div>
              </div>
            </div>
            <div className="row">
              <div className="col-sm-12 mt-3">
                <p className="brandon-Medium txt-darkgreen">LIFESTYLE CHOICE</p>
                <div className="allergen-btn-wrapper d-flex flex-wrap align-items-start">
                  {lifestyle_Data &&
                    lifestyle_Data.data &&
                    lifestyle_Data.data.map((data, index) => {
                      return (
                        <div
                          onClick={(e) => {
                            handleLifeStyleClick(e);
                            setModalData(data);
                          }}
                        >
                          <Card data={data} index={index} />
                        </div>
                      );
                    })}
                </div>
                <Popper
                  className="allergens-modal-wrapper"
                  placement="bottom-start"
                  disablePortal={true}
                  open={openLifeStyle}
                  anchorEl={anchorEl}
                  modifiers={{
                    flip: {
                      enabled: false,
                    },
                    preventOverflow: {
                      enabled: true,
                      boundariesElement: "window",
                    },
                    arrow: {
                      enabled: true,
                      element: arrowRef,
                    },
                  }}
                >
                  {true ? <span className="arrow" ref={setArrowRef} /> : null}

                  <React.Fragment>
                    <div className="bg-white allergens-modal">
                      <div className="allergens-heading d-flex align-items-center justiy-content-between position-relative">
                        <div className="allergens-inner-head d-flex align-items-center">
                          <div className="allergens-icon mr-4 d-flex align-items-center justify-content-center">
                            <img
                              src={`${SERVER_URL}/${
                                modalData && modalData.image
                              }`}
                              alt="modalData"
                              className="img-fluid"
                            />
                          </div>
                          <h6 className="allergens-title text-uppercase brandon-Medium fw-600 mb-0">
                            {modalData && modalData.name}
                          </h6>
                        </div>
                        <button
                          className="allergensclose-btn"
                          onClick={() => {
                            setOpenLifeStyle(false);
                          }}
                        >
                          x
                        </button>
                      </div>
                      <div className="col-sm-12">
                        <div className="row">
                          <div className="col-sm-12 pl-0 pr-0">
                            <div className="border mt-3 mb-3"></div>
                          </div>
                        </div>
                      </div>
                      {modalData && modalData.description ? (
                        <div className="allergens-info">
                          <p className="mb-0">
                            {modalData && modalData.description? modalData.description:""}.
                          </p>
                        </div>
                      ):""}
                    </div>
                  </React.Fragment>
                </Popper>
              </div>
            </div>
            <div className="col-sm-12">
              <div className="row">
                <div className="col-sm-12 mt-2 pl-0 pr-0 mb-2">
                  <div className="border mt-4 mb-4"></div>
                </div>
              </div>
            </div>
            <div className="row">
              <div className="col-sm-12 mt-3">
                <p className="brandon-Medium txt-darkgreen">
                  RESTAURANT FEATURES
                </p>
                <div className="allergen-btn-wrapper d-flex flex-wrap align-items-start">
                  {restaurantFeatures_Data &&
                    restaurantFeatures_Data.data &&
                    restaurantFeatures_Data.data.map((data, index) => {
                      return (
                        <div
                          onClick={(e) => {
                            handleRestaurantClick(e);
                            setModalData(data);
                          }}
                        >
                          <Card data={data} index={index} />
                        </div>
                      );
                    })}
                </div>
                <Popper
                  className="allergens-modal-wrapper"
                  placement="bottom-start"
                  disablePortal={true}
                  open={openRestaurant}
                  anchorEl={anchorEl}
                  modifiers={{
                    flip: {
                      enabled: false,
                    },
                    preventOverflow: {
                      enabled: true,
                      boundariesElement: "window",
                    },
                    arrow: {
                      enabled: true,
                      element: arrowRef,
                    },
                  }}
                >
                  {true ? <span className="arrow" ref={setArrowRef} /> : null}

                  <React.Fragment>
                    <div className="bg-white allergens-modal">
                      <div className="allergens-heading d-flex align-items-center justiy-content-between position-relative">
                        <div className="allergens-inner-head d-flex align-items-center">
                          <div className="allergens-icon mr-4 d-flex align-items-center justify-content-center">
                            <img
                              src={`${SERVER_URL}/${
                                modalData && modalData.image
                              }`}
                              alt="modalData"
                              className="img-fluid"
                            />
                          </div>
                          <h6 className="allergens-title text-uppercase brandon-Medium fw-600 mb-0">
                            {modalData && modalData.name}
                          </h6>
                        </div>
                        <button
                          className="allergensclose-btn"
                          onClick={() => {
                            setOpenRestaurant(false);
                          }}
                        >
                          x
                        </button>
                      </div>
                      
                      <div className="col-sm-12">
                        <div className="row">
                          <div className="col-sm-12 pl-0 pr-0">
                            <div className="border mt-3 mb-3"></div>
                          </div>
                        </div>
                      </div>
                      {modalData && modalData.description ? (
                        <div className="allergens-info">
                          <p className="mb-0">
                            {modalData && modalData.description? modalData.description:""}.
                          </p>
                        </div>
                      ):""}
                    </div>
                  </React.Fragment>
                </Popper>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default HowPageAllegyDescComp;
