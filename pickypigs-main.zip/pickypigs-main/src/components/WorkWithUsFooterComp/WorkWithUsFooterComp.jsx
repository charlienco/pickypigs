import React from "react";
import pattern from "../../assets/images/Pattern.png";
import { Button } from "react-bootstrap";
import digitalise from "../../assets/images/Digitalise.svg";
import integrate from "../../assets/images/Integrate.svg";
import showcasemenu from "../../assets/images/Showcase-Menu.svg";

import "./WorkWithUsFooterComp.scss";
import { useDispatch } from "react-redux";
import { showAdminSignUpPopup } from "../../redux/actions/restaurantAdminAction";

const WorkWithUsFooterComp = () => {
  const dispatch = useDispatch();
  return (
    <>
      {/* Would you like to join us? start content */}
      <section className="section7 joinus-section position-relative">
        <div className="container">
          <div className="patternimg-block">
            <img src={pattern} className="img-fluid" alt="fluid" />
          </div>
          <div className="row">
            <div className="col-sm-12">
              <div className="joinus-wrapper pl-4 pr-4 pt-5 pb-5">
                <div className="d-flex align-items-start justify-content-between">
                  <div>
                    <h1 className="sectionhead-txt text-uppercase pink-txt">
                      Work With Us
                    </h1>
                    <p className="join-subtxt f-15 line-height-1_75">
                      The ultimate food-finding application, bridging the gap
                      between you and your perfect guest.
                      <br className="d-lg-block d-none" />
                      Your allergy, calorie, macro and digital menu solution.
                    </p>
                  </div>
                  <div className="contactus-btn">
                    <Button
                      variant="primary"
                      className="theme-pink-btn w-160 text-uppercase brandon-Medium"
                      onClick={() => {
                        dispatch(showAdminSignUpPopup(true, ""));
                      }}
                    >
                      Contact Us
                    </Button>{" "}
                  </div>
                </div>
                <div className="row mt-4 pt-2">
                  <div className="col-sm-12 col-md-4 col-lg-4 col-xl-4 joinus-main mb-2">
                    <div className="joinus-block p-3">
                      <div className="joinus-icon d-flex align-items-center justify-content-center mb-2">
                        <img
                          src={digitalise}
                          className="img-fluid"
                          alt="fluid"
                        />
                      </div>
                      <div className="joinus-info pt-1">
                        <h6 className="text-uppercase pb-1 brandon-Bold">
                          <b>Digitalise today</b>
                        </h6>
                        <p className="f-15 mb-1">
                          Save time, money, energy and become more efficient.
                        </p>
                      </div>
                    </div>
                  </div>
                  <div className="col-sm-12 col-md-4 col-lg-4 col-xl-4 joinus-main mb-2">
                    <div className="joinus-block p-3">
                      <div className="joinus-icon d-flex align-items-center justify-content-center mb-2">
                        <img
                          src={integrate}
                          className="img-fluid"
                          alt="fluid"
                        />
                      </div>
                      <div className="joinus-info pt-1">
                        <h6 className="text-uppercase pb-1 brandon-Bold">
                          <b>Fuss Free Food</b>
                        </h6>
                        <p className="f-15 mb-1">
                          Showcase your restaurant features, provide your guests
                          with unique tailored menus.
                        </p>
                      </div>
                    </div>
                  </div>
                  <div className="col-sm-12 col-md-4 col-lg-4 col-xl-4 joinus-main mb-2">
                    <div className="joinus-block p-3">
                      <div className="joinus-icon d-flex align-items-center justify-content-center mb-2">
                        <img
                          src={showcasemenu}
                          className="img-fluid"
                          alt="showcasemenu"
                        />
                      </div>
                      <div className="joinus-info pt-1">
                        <h6 className="text-uppercase pb-1 brandon-Bold">
                          <b>The Whole Package</b>
                        </h6>
                        <p className="f-15 mb-1">
                          Manage your ingredients, recipes and dishes within
                          your unique dashboard.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default WorkWithUsFooterComp;
