import React, { lazy, useEffect, useRef, useState } from "react";
import serachwhite from "../../assets/images/serach-white.svg";
import CustomDropdown from "../CustomDropdown/CustomDropdown";
import "./FilterList.scss";
import { useDispatch, useSelector } from "react-redux";

import {
  getAllAllergyData,
  getAllDietaryData,
  getAllLifestyleData,
  getAllRestaurantFeaturesData,
} from "../../redux/actions/allergyAction";
import SearchResultDisplayComp from "../SearchResultDisplayComp/SearchResultDisplayComp";
import { NavLink, Link, useLocation } from "react-router-dom";
import { updatePreferenceFilter } from "../../redux/actions/globalPreferenceFilterAction";
import {
  getFilterListBottomLocation,
  getUserLoginStatusData,
} from "../../redux/actions/generalActions";
const MyfilterListExampleCopy = lazy(() =>
  import("../MyfilterListExampleCopy/MyfilterListExampleCopy")
);

function useOutsideAlerter(ref, setUserTextFocus) {
  useEffect(() => {
    /**
     * Alert if clicked on outside of element
     */
    function handleClickOutside(event) {
      if (ref.current && !ref.current.contains(event.target)) {
        // alert("You clicked outside of me!");
        setUserTextFocus(false);
      }
    }

    // Bind the event listener
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      // Unbind the event listener on clean up
      document.removeEventListener("mousedown", handleClickOutside);
    };
    // eslint-disable-next-line
  }, [ref]);
}

function FilterList(props) {
  const dispatch = useDispatch();
  const location = useLocation();

  const [dietaryValue, setDietaryValue] = useState([]);
  const [lifeStyleValue, setLifeStyleValue] = useState([]);
  const [allergenValue, setAllergenValue] = useState([]);
  const [featuresValue, setFeaturesValue] = useState([]);
  const [userTextFocus, setUserTextFocus] = useState(false);
  const [userSearchText, setUserSearchText] = useState("");
  const searchInputRef = useRef(null);
  const [focusChange, setFocusChange] = useState("");

  // const token=localStorage.getItem("access_token")

  const wrapperRef = useRef(null);
  useOutsideAlerter(wrapperRef, setUserTextFocus);

  useEffect(() => {
    dispatch(getAllAllergyData());
    dispatch(getAllDietaryData());
    dispatch(getAllLifestyleData());
    dispatch(getAllRestaurantFeaturesData());
  }, [dispatch]);

  let allAllergy_data = useSelector((state) => {
    return state.allergy;
  });

  let { allergy_Data, dietary_Data, lifestyle_Data, restaurantFeatures_Data } =
    allAllergy_data;

  //if user loged in getting user Preference Start

  let User_Data = useSelector((state) => {
    return state.userProfile;
  });
  let { userProfile_Data = {} } = User_Data;

  let User_loginstatus_Data = useSelector((state) => {
    return state.general.userLoginStatus_Data;
  });

  useEffect(() => {
    if (User_loginstatus_Data) {
      if (
        userProfile_Data &&
        userProfile_Data.userDetail &&
        userProfile_Data.userDetail.myPreferences &&
        userProfile_Data.userDetail.myPreferences.allergenInformation
      ) {
        dispatch(
          updatePreferenceFilter(
            "allergendata",
            userProfile_Data &&
              userProfile_Data.userDetail &&
              userProfile_Data.userDetail.myPreferences &&
              userProfile_Data.userDetail.myPreferences.allergenInformation
          )
        );
      }
      if (
        userProfile_Data &&
        userProfile_Data.userDetail &&
        userProfile_Data.userDetail.myPreferences &&
        userProfile_Data.userDetail.myPreferences.dietaryPreferences
      ) {
        dispatch(
          updatePreferenceFilter(
            "dietarydata",
            userProfile_Data &&
              userProfile_Data.userDetail &&
              userProfile_Data.userDetail.myPreferences &&
              userProfile_Data.userDetail.myPreferences.dietaryPreferences
          )
        );
      }
      if (
        userProfile_Data &&
        userProfile_Data.userDetail &&
        userProfile_Data.userDetail.myPreferences &&
        userProfile_Data.userDetail.myPreferences.lifestyleChoice
      ) {
        dispatch(
          updatePreferenceFilter(
            "lifestyledata",
            userProfile_Data &&
              userProfile_Data.userDetail &&
              userProfile_Data.userDetail.myPreferences &&
              userProfile_Data.userDetail.myPreferences.lifestyleChoice
          )
        );
      }
      if (
        userProfile_Data &&
        userProfile_Data.userDetail &&
        userProfile_Data.userDetail.myPreferences &&
        userProfile_Data.userDetail.myPreferences.restaurantFeatures
      ) {
        dispatch(
          updatePreferenceFilter(
            "featuredata",
            userProfile_Data &&
              userProfile_Data.userDetail &&
              userProfile_Data.userDetail.myPreferences &&
              userProfile_Data.userDetail.myPreferences.restaurantFeatures
          )
        );
      }
      // setTimeout(() => {
      //     dispatch(getUserLoginStatusData(false));
      //   }, 3000);
    }
  }, [dispatch, userProfile_Data, User_loginstatus_Data]);

  //if user loged in getting user Preference Ends

  const handelClearAll = (key, value) => {
    dispatch(updatePreferenceFilter(key, value));
    dispatch(getUserLoginStatusData(false));
  };

  useEffect(() => {
    if (props.myallergydata) {
      setAllergenValue(props.myallergydata);
    }
  }, [props.myallergydata]);
  useEffect(() => {
    if (props.mydietarydata) {
      setDietaryValue(props.mydietarydata);
    }
  }, [props.mydietarydata]);
  useEffect(() => {
    if (props.mylifestyledata) {
      setLifeStyleValue(props.mylifestyledata);
    }
  }, [props.mylifestyledata]);
  useEffect(() => {
    if (props.myfeaturedata) {
      setFeaturesValue(props.myfeaturedata);
    }
  }, [props.myfeaturedata]);
  useEffect(() => {
    if (props.mysearchdata) {
      setUserSearchText(props.mysearchdata);
    }
  }, [props.mysearchdata]);

  // const getMyLocation = () => {
  //     const location = window.navigator && window.navigator.geolocation
  //     if (location) {
  //         location.getCurrentPosition((position) => {
  //             console.log('Lat => ', {
  //                 latitude: position.coords.latitude,
  //                 longitude: position.coords.longitude,
  //             });
  //             axios.get(
  //                 `${GOOGLE_MAP_API_URL}?latlng=${position.coords.latitude},${position.coords.longitude}&key=${API_KEY}`).then(res => {
  //                     console.log('res sejal => ', res)
  //                     setPlaces(res.data.results)
  //                     setAddress(res.data.results[0].formatted_address);
  //                 }).catch(err => console.log('err => ', err))
  //         }, (error) => {
  //             console.log('error => ', error);
  //         })
  //     }
  // }

  const myCordinates = useSelector((state) => {
    return state.googledata;
  });
  let { myData = "" } =myCordinates;

  const handleSearch = (e) => {
    setUserSearchText(e.target.value);
  };

  const current_page = location.pathname;

  const handelPreference = (key, value) => {
    dispatch(updatePreferenceFilter(key, value));
    dispatch(getUserLoginStatusData(false));
  };
  const preferenceData = useSelector((state) => {
    return state.myPreference.selectedPreference;
  });
  let {
    allergendata = [],
    dietarydata = [],
    lifestyledata = [],
    featuredata = [],
  } = preferenceData;

  useEffect(() => {
    setAllergenValue(allergendata ? allergendata : allergenValue);
    setDietaryValue(dietarydata ? dietarydata : dietaryValue);
    setLifeStyleValue(lifestyledata ? lifestyledata : lifeStyleValue);
    setFeaturesValue(featuredata ? featuredata : featuresValue);
    // eslint-disable-next-line
  }, [preferenceData]);

  //getting bottom position of filterlist Start
  useEffect(() => {
    window.addEventListener("scroll", () => {
      let ele = document.getElementById("filterlist-bottom-detection");
      let offsets = ele && ele.getBoundingClientRect();
      let top = offsets && offsets.top;
      // console.log("top",top)
      dispatch(getFilterListBottomLocation(top));
    });
    // eslint-disable-next-line
  }, [dispatch]);
  //getting bottom position of filterlist End
  useEffect(() => {
    setFocusChange(props.openSearchBar);
  }, [props.openSearchBar]);

  useEffect(() => {
    if (searchInputRef.current) searchInputRef.current.focus();
  }, [focusChange]);

  return (
    <div className="restaurant-find w-100 p-2 p-xl-3 mb-5">
      {/* <React.Fragment>
                {myLoading?
                    <CustomLoadingComp/>
                :
                    null
                }
            </React.Fragment> */}
      {/* {JSON.stringify(userProfile_Data&&userProfile_Data.userDetail&&userProfile_Data.userDetail.myPreferences)} */}
      {/* {JSON.stringify(userSearchDetails&&userSearchDetails)} */}

      <div className="fr-search d-flex align-items-center  pb-3">
        <MyfilterListExampleCopy />
        {/* <MyfilterListExample/> */}

        {/* <Dropdown className="fr-location mr-2">
                    <Dropdown.Toggle className="d-flex justify-content-between align-items-center w-100" variant="Secondary" id="dropdown-basic">
                        <span className="d-flex align-items-center">
                            <img src={location} className="img-fluid mr-2" alt="marker" /> 
                            {selectedPlace !== null ? (selectedPlace && selectedPlace.address_components[1].long_name) : (places && places[0].address_components[0].short_name)}
                        </span>
                    </Dropdown.Toggle>
                    <Dropdown.Menu>
                        {places && places.map((data, i) =>
                            <Dropdown.Item onSelect={() => setSelectedPlace(data)}>
                                {data.address_components[1] && data.address_components[1].long_name}
                            </Dropdown.Item>
                        )}
                    </Dropdown.Menu>
                </Dropdown> */}
        <div
          ref={wrapperRef}
          className="fr-input d-flex justify-content-between align-items-center position-relative"
        >
          <input
            ref={searchInputRef}
            type="text"
            value={userSearchText}
            onChange={handleSearch}
            onFocus={() => {
              setUserTextFocus(true);
            }}
            autofocus={true}
            // onBlur={()=>{setUserTextFocus(false)}}
            className="w-100 fr-search-box rl-fl-searchbox brandon-regular"
            placeholder="Search for restaurant or dish"
          />
          {current_page !== "/allrestaurant" ? (
            <React.Fragment>
              {allergenValue.length <= 0 &&
              dietaryValue.length <= 0 &&
              lifeStyleValue.length <= 0 &&
              featuresValue.length <= 0 &&
              userSearchText === "" &&
              !myData&&myData === ""
              ? (
                <NavLink
                  to="/restaurant_list"
                  className="fr-search-btn theme-pink-btn"
                >
                  <img
                    src={serachwhite}
                    className="img-fluid"
                    alt="serachwhite"
                  />
                </NavLink>
              ) : (
                <Link
                  to={{
                    pathname: "/allrestaurant",
                    search: `?search=${userSearchText}`,
                    state: {
                      allergendata: allergenValue,
                      dietarydata: dietaryValue,
                      lifestyledata: lifeStyleValue,
                      featuredata: featuresValue,
                    },
                  }}
                  className="fr-search-btn theme-pink-btn"
                >
                  <img
                    src={serachwhite}
                    className="img-fluid"
                    alt="serachwhite"
                  />
                </Link>
              )}
            </React.Fragment>
          ) : (
            <React.Fragment>
              <Link
                to={{
                  pathname: "/allrestaurant",
                  search: `?search=${userSearchText}`,
                  state: {
                    allergendata: allergenValue,
                    dietarydata: dietaryValue,
                    lifestyledata: lifeStyleValue,
                    featuredata: featuresValue,
                  },
                }}
                className="fr-search-btn theme-pink-btn"
              >
                <img
                  src={serachwhite}
                  className="img-fluid"
                  alt="serachwhite"
                />
              </Link>
            </React.Fragment>
          )}

          {/* {filterIcon && <Button className="filtershort-btn ml-2 p-0">
                        <img src={filtershorticon} className="img-fluid" alt="filterIcon" />
                    </Button>} */}
          {props.showautosuggestion && props.showautosuggestion ? (
            <React.Fragment>
              {userSearchText && userSearchText !== " " && userTextFocus && (
                <div className="position-absolute fr-rsdish-filterwrapper">
                  <SearchResultDisplayComp searchtext={userSearchText} />
                </div>
              )}
            </React.Fragment>
          ) : null}
        </div>
      </div>
      {/* {userSearchText} || {JSON.stringify()} */}

      <div className="fr-category-select d-flex justify-content-between align-items-center mt-3 flex-wrap pr-4">
        <CustomDropdown
          placeholder={"Allergen"}
          clearAll={() => {
            handelClearAll("allergendata", []);
          }}
          options={allergy_Data && allergy_Data.data}
          value={allergendata}
          onChangeData={(value) => {
            handelPreference("allergendata", value);
          }}
        />

        <CustomDropdown
          placeholder={"Dietary Preference"}
          clearAll={() => {
            handelClearAll("dietarydata", []);
          }}
          options={dietary_Data && dietary_Data.data}
          value={dietarydata}
          onChangeData={(value) => {
            handelPreference("dietarydata", value);
          }}
        />

        <CustomDropdown
          placeholder={"Lifestyle Choices"}
          clearAll={() => {
            handelClearAll("lifestyledata", []);
          }}
          options={lifestyle_Data && lifestyle_Data.data}
          value={lifestyledata}
          onChangeData={(value) => {
            handelPreference("lifestyledata", value);
          }}
        />

        <CustomDropdown
          placeholder={"Restaurant Features"}
          clearAll={() => {
            handelClearAll("featuredata", []);
          }}
          options={restaurantFeatures_Data && restaurantFeatures_Data.data}
          value={featuredata}
          onChangeData={(value) => {
            handelPreference("featuredata", value);
          }}
        />
      </div>
      <span id="filterlist-bottom-detection"></span>
    </div>
  );
}

export default FilterList;
