import React, { useEffect, useRef, useState } from "react";
import { Button, Nav, Form, Navbar, Modal } from "react-bootstrap";
import {
  Link,
  NavLink,
  useHistory,
  useLocation,
  withRouter,
} from "react-router-dom";
import "./Header.scss";
import logo from "../../../assets/images/logo.svg";
import profileimage from "../../../assets/images/profileimage.gif";
import search_icon from "../../../assets/images/search_icon.svg";
import Signup from "../../../view/Signup/Signup";
import SignInPage from "../../../view/SignInPage/SignInPage";
import { useDispatch, useSelector } from "react-redux";
import {
  showSignUpPopup,
  showSignInPopup,
  logoutUser,
  showVerificationPopup,
  showForgotPasswordPopup,
  registrationSuccess,
} from "../../../redux/actions/generalActions";
import ForgotPasswordPage from "../../../view/ForgotPasswordPage/ForgotPasswordPage";
import RegistrationSuccessScreen from "../../RegistrationSuccessScreen/RegistrationSuccessScreen";
import SignUpModalComp from "../../SignUpModalComp/SignUpModalComp";
import {
  showAdminSignUpPopup,
  showContactUsPopup,
} from "../../../redux/actions/restaurantAdminAction";
import { SERVER_URL } from "../../../shared/constant";
import EmailverificationSuccessScreen from "../../EmailverificationSuccessScreen/EmailverificationSuccessScreen";
import FilterList from "../../FilterList/FilterList";
import ContactUs from "../../ContactUs";

function useOutsideAlerter(ref, setOpenSearchBar) {
  useEffect(() => {
    /**
     * Alert if clicked on outside of element
     */
    function handleClickOutside(event) {
      if (ref.current && !ref.current.contains(event.target)) {
        // alert("You clicked outside of me!");
        setOpenSearchBar(false);
      }
    }

    // Bind the event listener
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      // Unbind the event listener on clean up
      document.removeEventListener("mousedown", handleClickOutside);
    };
    // eslint-disable-next-line
  }, [ref]);
}

const Header = (props) => {
  const dispatch = useDispatch();
  const history = useHistory();
  const location = useLocation();

  const queryString = require("query-string");
  const parsed = queryString.parse(props.location.search);

  const [openSearchBar, setOpenSearchBar] = useState(false);

  const wrapperRef = useRef(null);
  useOutsideAlerter(wrapperRef, setOpenSearchBar);
  useEffect(() => {
    window.addEventListener("scroll", () => {
      if (openSearchBar === true) {
        setOpenSearchBar(false);
      }
    });
  }, [openSearchBar]);

  const [showDropDown, setShowDropDown] = useState(false);

  const signUpModal = useSelector((state) => state.general.showSignUpPopup);
  const signInModal = useSelector((state) => state.general.showSignInPopup);
  const forgotPasswordModal = useSelector(
    (state) => state.general.showForgotPasswordPopup
  );
  const registerModal = useSelector(
    (state) => state.general.showSignUpSuccessPopup
  );
  const verificationModal = useSelector(
    (state) => state.general.showVerificationPopup
  );
  const adminSignUpModal = useSelector(
    (state) => state.restaurantAdmin.showAdminSignUpPopup
  );
  const contactUsModal = useSelector(
    (state) => state.restaurantAdmin.contactUsModal
  );

  const filterListBottomData = useSelector(
    (state) => state.general.filterListBottomData
  );

  let User_Data = useSelector((state) => {
    return state.userProfile;
  });
  let { userProfile_Data } = User_Data;

  const token = localStorage.getItem("access_token");

  useEffect(() => {
    window.addEventListener("scroll", () => {
      let ele = document.getElementById("navbar");
      if (window.scrollY !== 0) {
        ele && ele.classList.add("navsticky");
        // console.log(window.scrollY)
      } else {
        ele && ele.classList.remove("navsticky");
      }
    });
  }, []);
  const current_page = location.pathname;

  const partnerHandler = () => {
    setShowDropDown(!showDropDown);
    history.push("/restaurant_login");
  };

  return (
    <Navbar bg="transparent" id="navbar" expand="lg" className=" main-header">
      <div className="container">
        <Link to="/" className="navbar-brand pr-lg-5 mr-lg-5">
          <img src={logo} className="img-fluid mr-2" alt="logo" />
          <span className="logo-txt">Picky Pigs</span>
        </Link>
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav" className="menu-list">
          <Nav className="mr-auto">
            <NavLink
              className="menu-link mr-lg-5"
              activeStyle={{ color: "#cb007b" }}
              to="/who"
            >
              Who
            </NavLink>
            <NavLink
              className="menu-link mr-lg-5"
              activeStyle={{ color: "#cb007b" }}
              to="/how"
            >
              What
            </NavLink>
            {/* <NavLink className="menu-link" activeStyle={{color:'#cb007b'}} to="/how">How</NavLink> */}
          </Nav>

          <Form inline className=" navright-btn userlogin-after ">
            {current_page !== "/restaurant_login" &&
              current_page !== "/allrestaurant" && (
                <div
                  ref={wrapperRef}
                  className={` ${
                    filterListBottomData - 82 <= 0 ? null : "my_custom_css"
                  }`}
                >
                  <div
                    type="button"
                    className="search-topnav mr-5 position-relative d-flex"
                    onClick={() => setOpenSearchBar(!openSearchBar)}
                  >
                    <span className="w-100  brandon-Medium mt-1 border-bottom">
                      {parsed && parsed.search
                        ? parsed.search
                        : "Search for restaurant or dish"}
                    </span>
                    <span>&nbsp;</span>
                    <div className="search-navicon">
                      <img
                        src={search_icon}
                        className="img-fluid ml-2"
                        alt="search_icon"
                        loading="lazy"
                      />
                    </div>
                  </div>
                  {true ? (
                    <React.Fragment>
                      {openSearchBar && (
                        <div
                          className=""
                          style={{
                            position: "absolute",
                            top: "8rem",
                            left: 0,
                            width: "100%",
                          }}
                        >
                          <section
                            className="fr-section rl-section pt-0"
                            style={{ background: "none", paddingTop: 0 }}
                          >
                            <div className="row">
                              <div className="col-sm-12">
                                <div className="fr-wrapper fr-rl-wrapper pt-0">
                                  <div className="container">
                                    <FilterList showautosuggestion={true} />
                                  </div>
                                </div>
                              </div>
                            </div>
                          </section>
                        </div>
                      )}
                    </React.Fragment>
                  ) : null}
                </div>
              )}

            {token && userProfile_Data && userProfile_Data.role === "user" ? (
              <div className="btn-group userprofile-dropdown">
                <button
                  type="button"
                  className="btn btn-secondary dropdown-toggle userprofile-dropbtn"
                  data-toggle="dropdown"
                  aria-haspopup="true"
                  aria-expanded="false"
                >
                  <div className="user-name">
                    {userProfile_Data &&
                    userProfile_Data.userDetail &&
                    userProfile_Data.userDetail.profileImage ? (
                      <img
                        src={`${SERVER_URL}/${userProfile_Data.userDetail.profileImage}`}
                        className="userprofile-img img-fluid mr-2 border"
                        alt="logo"
                      />
                    ) : (
                      <img
                        src={profileimage}
                        className="userprofile-img img-fluid mr-2"
                        alt="logo"
                      />
                    )}
                    {userProfile_Data &&
                    userProfile_Data.userDetail &&
                    userProfile_Data.userDetail.name ? (
                      <span className="text-capitalize">
                        {userProfile_Data.userDetail.name}
                      </span>
                    ) : (
                      <span>Hello</span>
                    )}
                  </div>
                </button>
                <div className="dropdown-menu dropdown-menu-right">
                  <NavLink
                    to="/user_detail"
                    type="button"
                    className="dropdown-item"
                  >
                    My Profile
                  </NavLink>
                  <button className="dropdown-item" type="button">
                    My Favorites
                  </button>
                  <button
                    className="dropdown-item"
                    type="button"
                    onClick={() => {
                      dispatch(logoutUser(history));
                    }}
                  >
                    Logout
                  </button>
                </div>
              </div>
            ) : (
              <React.Fragment>
                <div className="partner-nav-dropdown">
                  <div id="nav">
                    <li>
                      <Button
                        onClick={() => {
                          partnerHandler();
                        }}
                        variant="outline-success"
                        className="theme-light-btn pt-2 pb-2 pl-4 pr-4 radius-50 position-relative"
                      >
                        Partner with us
                      </Button>
                      <ul>
                        <li>
                          <NavLink
                            className="menu-link mr-lg-5"
                            activeStyle={{ color: "#cb007b" }}
                            to="/restaurant_login"
                          >
                            Sign In
                          </NavLink>
                        </li>
                        <li>
                          <NavLink
                            onClick={() => {
                              dispatch(showAdminSignUpPopup(true));
                            }}
                            className="menu-link mr-lg-5"
                            to="/restaurant_login"
                          >
                            Sign Up
                          </NavLink>
                        </li>
                      </ul>
                    </li>
                  </div>
                </div>
                {current_page !== "/restaurant_login" && (
                  <Button
                    onClick={() => {
                      dispatch(showSignInPopup(true));
                    }}
                    variant="outline-success"
                    className="ml-3 outline-success theme-light-btn pt-2 pb-2 pl-4 pr-4 "
                  >
                    Login
                    <svg
                      className="user-icon ml-2"
                      fill="#333"
                      xmlns="http://www.w3.org/2000/svg"
                      width="10.672"
                      height="14"
                      viewBox="0 0 10.672 14"
                    >
                      <path
                        id="Path_372"
                        data-name="Path 372"
                        d="M5.336.264H4V-1.064a1.959,1.959,0,0,0-.268-1A1.986,1.986,0,0,0,3-2.8a1.959,1.959,0,0,0-1-.268H-2A1.959,1.959,0,0,0-3-2.8a1.986,1.986,0,0,0-.728.728,1.959,1.959,0,0,0-.268,1V.264H-5.336V-1.064A3.273,3.273,0,0,1-4.88-2.752a3.257,3.257,0,0,1,1.2-1.192A3.258,3.258,0,0,1-2-4.4H2a3.258,3.258,0,0,1,1.68.456,3.257,3.257,0,0,1,1.2,1.192,3.273,3.273,0,0,1,.456,1.688ZM0-5.736A3.916,3.916,0,0,1-2.016-6.28a3.985,3.985,0,0,1-1.44-1.432A3.952,3.952,0,0,1-4-9.732a3.952,3.952,0,0,1,.544-2.02,3.985,3.985,0,0,1,1.44-1.432A3.873,3.873,0,0,1,0-13.736a3.873,3.873,0,0,1,2.016.552,3.985,3.985,0,0,1,1.44,1.432A3.952,3.952,0,0,1,4-9.732a3.952,3.952,0,0,1-.544,2.02A3.985,3.985,0,0,1,2.016-6.28,3.916,3.916,0,0,1,0-5.736ZM0-7.064a2.573,2.573,0,0,0,1.344-.368,2.609,2.609,0,0,0,.96-.952,2.652,2.652,0,0,0,.36-1.348A2.652,2.652,0,0,0,2.3-11.08a2.609,2.609,0,0,0-.96-.952A2.573,2.573,0,0,0,0-12.4a2.573,2.573,0,0,0-1.344.368,2.609,2.609,0,0,0-.96.952,2.652,2.652,0,0,0-.36,1.348A2.652,2.652,0,0,0-2.3-8.384a2.609,2.609,0,0,0,.96.952A2.573,2.573,0,0,0,0-7.064Z"
                        transform="translate(5.336 13.736)"
                      />
                    </svg>
                  </Button>
                )}
                {/* <img src={cart} className="img-fluid" alt="cart" /> */}
              </React.Fragment>
            )}
          </Form>

          <Modal
            centered
            show={signUpModal}
            onHide={() => {
              dispatch(showSignUpPopup(false));
            }}
            backdrop="static"
            keyboard={false}
            className="signup-modal"
          >
            <Modal.Body className="p-0 position-relative">
              <Signup
                gotoLogin={() => {
                  dispatch(showSignUpPopup(false));
                  dispatch(showSignInPopup(true));
                }}
                onHide={() => {
                  dispatch(showSignUpPopup(false));
                }}
                show={signUpModal}
              />
            </Modal.Body>
          </Modal>

          <Modal
            centered
            show={signInModal}
            onHide={() => dispatch(showSignInPopup(false))}
            backdrop="static"
            keyboard={false}
            className="SignInPage-modal"
          >
            <Modal.Body className="p-0 position-relative">
              <SignInPage
                openForgotPass={() => {
                  dispatch(showSignInPopup(false));
                  dispatch(showForgotPasswordPopup(true));
                }}
                gotoSignup={() => {
                  dispatch(showSignUpPopup(true));
                  dispatch(showSignInPopup(false));
                }}
                onHide={() => dispatch(showSignInPopup(false))}
                show={signInModal}
              />
            </Modal.Body>
          </Modal>

          <Modal
            centered
            show={forgotPasswordModal}
            onHide={() => dispatch(showForgotPasswordPopup(false))}
            backdrop="static"
            keyboard={false}
            className="ForgotPasswordPage-modal"
          >
            <Modal.Body className="p-0 position-relative">
              <ForgotPasswordPage
                gotoLogin={() => {
                  dispatch(showForgotPasswordPopup(false));
                  dispatch(showSignInPopup(true));
                }}
                onHide={() => dispatch(showForgotPasswordPopup(false))}
                show={forgotPasswordModal}
              />
            </Modal.Body>
          </Modal>

          <Modal
            centered
            show={registerModal}
            onHide={() => dispatch(registrationSuccess(false))}
            backdrop="static"
            keyboard={false}
            className="RegistrationSuccessScreen-modal"
          >
            <Modal.Body className="p-0 position-relative">
              <RegistrationSuccessScreen
                onHide={() => dispatch(registrationSuccess(false))}
                show={registerModal}
              />
            </Modal.Body>
          </Modal>

          <Modal
            centered
            show={adminSignUpModal}
            onHide={() => dispatch(showAdminSignUpPopup(false))}
            className="SignUpModalComp-modal"
          >
            <Modal.Body className="p-0 position-relative">
              <SignUpModalComp
                onHide={() => dispatch(showAdminSignUpPopup(false))}
                show={adminSignUpModal}
              />
            </Modal.Body>
          </Modal>

          <Modal
            centered
            show={contactUsModal}
            onHide={() => dispatch(showContactUsPopup(false))}
            className="SignUpModalComp-modal"
          >
            <Modal.Body className="p-0 position-relative">
              <ContactUs
                onHide={() => dispatch(showContactUsPopup(false))}
                show={contactUsModal}
              />
            </Modal.Body>
          </Modal>

          <Modal
            centered
            show={verificationModal}
            onHide={() => {
              dispatch(showVerificationPopup(false));
            }}
            backdrop="static"
            keyboard={false}
            className="EmailverificationSuccessScreen-modal"
          >
            <Modal.Body className="p-0 position-relative">
              <EmailverificationSuccessScreen
                gotoLogin={() => {
                  dispatch(showVerificationPopup(false));
                  dispatch(showSignInPopup(true));
                }}
                onHide={() => {
                  dispatch(showVerificationPopup(false));
                }}
                show={verificationModal}
              />
            </Modal.Body>
          </Modal>
        </Navbar.Collapse>
      </div>
    </Navbar>
  );
};

export default withRouter(Header);
