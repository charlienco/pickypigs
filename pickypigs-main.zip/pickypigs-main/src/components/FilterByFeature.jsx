import React, { useEffect, useState } from "react";
import { useHistory } from "react-router-dom";
import Slider from "react-slick";
import { useDispatch, useSelector } from "react-redux";
import { getFastBarData } from "../redux/actions/allergyAction";
import { SERVER_URL } from "../shared/constant";
import { updatePreferenceFilter } from "../redux/actions/globalPreferenceFilterAction";

function FilterByFeature() {
  const dispatch = useDispatch();
  const history = useHistory();
  const [makingFalse, setMakingFalse] = React.useState(false);

  var settings = {
    arrows: false,
    infinite: false,
    swipeToSlide: true,
    centerPadding: "5px",
    slidesToShow: 11,
    slidesToScroll: 2.5,
    swipe: true,
    responsive: [
      {
        breakpoint: 768,
        settings: {
          arrows: false,
          infinite: true,
          swipeToSlide: true,
          // centerMode: true,
          centerPadding: "40px",
          slidesToShow: 3,
        },
      },
      {
        breakpoint: 480,
        settings: {
          arrows: false,
          infinite: true,
          swipeToSlide: true,
          // centerMode: true,
          centerPadding: "40px",
          slidesToShow: 1,
        },
      },
    ],
  };

  let [features, setFeatures] = useState([]);
  let [allergens, setAllergens] = useState([]);
  let [dietarys, setDietarys] = useState([]);
  let [lifestyles, setlifestyles] = useState([]);


  // const handleFeatures = (e) => {
  //   e.preventDefault();
  //   // console.log("ssss")
  //   if (features.indexOf(e.target.id) !== -1) {
  //     var Index = features.indexOf(e.target.id);
  //     if (Index > -1) {
  //       setFeatures(
  //         features.filter((myfeatures) => myfeatures !== e.target.id)
  //       );
  //     }
  //   } else {
  //     setFeatures([...features, e.target.id]);
  //   }
  // };

  useEffect(() => {
    dispatch(getFastBarData());
  }, [dispatch]);

  let allAllergy_data = useSelector((state) => {
    return state.allergy;
  });


  /** */
  const preferenceData = useSelector((state) => {
    return state.myPreference.selectedPreference;
  });
  // console.log("preferenceData : ", preferenceData);
  let {
    allergendata = [],
    dietarydata = [],
    lifestyledata = [],
    featuredata = [],
  } = preferenceData;
  useEffect(() => {
    setAllergens(allergendata ? allergendata : allergens);
    setDietarys(dietarydata ? dietarydata : dietarys);
    setlifestyles(lifestyledata ? lifestyledata : lifestyles);
    setFeatures(featuredata ? featuredata : features);
    // eslint-disable-next-line
  }, [preferenceData]);

  /** */



  let { fastbar_Data } = allAllergy_data;

  const handleFeatures = (e) => {
    e.preventDefault();
    const selectedFeature = fastbar_Data.data.find(element => element._id === e.target.id);
    if (selectedFeature.type === "allergen") {
      console.log("allergens called....", e.target.id);
      if (allergens.indexOf(e.target.id) !== -1) {
        let Index = allergens.indexOf(e.target.id);
        if (Index > -1) {
          setAllergens(
            allergens.filter((myallergens) => myallergens !== e.target.id)
          );
          dispatch(updatePreferenceFilter("allergendata", allergens.filter((myallergens) => myallergens !== e.target.id)));
        }
      } else {
        setAllergens([...allergens, e.target.id]);
        dispatch(updatePreferenceFilter("allergendata", [...allergens, e.target.id]));
      }
    }
    if (selectedFeature.type === "dietary") {
      console.log("dietarys called....", e.target.id);
      if (dietarys.indexOf(e.target.id) !== -1) {
        let Index = dietarys.indexOf(e.target.id);
        if (Index > -1) {
          setDietarys(
            dietarys.filter((mydietarys) => mydietarys !== e.target.id)
          );
          dispatch(updatePreferenceFilter("dietarydata", dietarys.filter((mydietarys) => mydietarys !== e.target.id)));
        }
      } else {
        setDietarys([...dietarys, e.target.id]);
        dispatch(updatePreferenceFilter("dietarydata", [...dietarys, e.target.id]));
      }
    }
    if (selectedFeature.type === "lifestyle") {
      console.log("lifestyles called....", e.target.id);
      if (lifestyles.indexOf(e.target.id) !== -1) {
        let Index = lifestyles.indexOf(e.target.id);
        if (Index > -1) {
          setlifestyles(
            lifestyles.filter((mylifestyles) => mylifestyles !== e.target.id)
          );
          dispatch(updatePreferenceFilter("lifestyledata", lifestyles.filter((mylifestyles) => mylifestyles !== e.target.id)));
        }
      } else {
        setlifestyles([...lifestyles, e.target.id]);
        dispatch(updatePreferenceFilter("lifestyledata", [...lifestyles, e.target.id]));
      }
    }
    if (selectedFeature.type === "features") {
      console.log("feature called....", e.target.id);
      if (features.indexOf(e.target.id) !== -1) {
        let Index = features.indexOf(e.target.id);
        if (Index > -1) {
          setFeatures(
            features.filter((myfeatures) => myfeatures !== e.target.id)
          );
          dispatch(updatePreferenceFilter("featuredata", features.filter((myfeatures) => myfeatures !== e.target.id)));
        }
      } else {
        setFeatures([...features, e.target.id]);
        dispatch(updatePreferenceFilter("featuredata", [...features, e.target.id]));
      }
    }
  };

  const handleFeatureRedirection = () => {
    // if (features && features.length > 0) {
    // if (features && features.length > 0) {
    //   dispatch(updatePreferenceFilter("featuredata", features));
    // }
    // if (allergens && allergens.length > 0) {
    //   dispatch(updatePreferenceFilter("allergendata", allergens));
    // }
    // if (dietarys && dietarys.length > 0) {
    //   dispatch(updatePreferenceFilter("dietarydata", dietarys));
    // }
    // if (lifestyles && lifestyles.length > 0) {
    //   dispatch(updatePreferenceFilter("lifestyledata", lifestyles));
    // }

    if ((allergens && allergens.length > 0) || (dietarys && dietarys.length > 0) || (lifestyles && lifestyles.length > 0) || (features && features.length > 0)) {
      setMakingFalse(true);
    }
  };
  useEffect(() => {
    if (makingFalse === true) {
      setMakingFalse(false);
      history.push("/allrestaurant");
    }
    // eslint-disable-next-line
  }, [makingFalse === true]);

  return (
    <React.Fragment>
      {/* {JSON.stringify(features)} */}
      <Slider {...settings} className="filterfeature-wrapper">
        {
          fastbar_Data &&
          fastbar_Data.data &&
          fastbar_Data.data.map((data, index) => {
            return (
              <React.Fragment key={index}>
                <button
                  id={data._id}
                  onClick={handleFeatures}
                  className={`btn filter-subwrapper ${
                    (data.type === "allergen") ? allergens.indexOf(data._id) !== -1 && "active" : (data.type === "dietary") ? dietarys.indexOf(data._id) !== -1 && "active" : (data.type === "lifestyle") ? lifestyles.indexOf(data._id) !== -1 && "active" : features.indexOf(data._id) !== -1 && "active"
                    }`}
                >
                  <span
                    id={data._id}
                    className="filter-icon mt-2"
                    onClick={handleFeatures}
                  >
                    <img
                      id={data._id}
                      className="filter-icon img-fluid"
                      src={`${SERVER_URL}/${data.image}`}
                      alt="img"
                      loading="lazy"
                    />
                  </span>
                  <p
                    id={data._id}
                    onClick={handleFeatures}
                    className="mt-2 mb-0 text-dark text-link f-14 brandon-Medium text-capitalize"
                  >
                    {data.name ? data.name : ""}
                  </p>
                </button>
              </React.Fragment>
            );
          })}
      </Slider>
      {
        ((allergens && allergens.length > 0) || (dietarys && dietarys.length > 0) || (lifestyles && lifestyles.length > 0) || (features && features.length > 0)) ? (
          <span className="d-flex justify-content-end">
            <button
              className="theme-pink-btn text-white"
              onClick={() => {
                handleFeatureRedirection();
              }}
            >
              Go
            </button>
          </span>
        ) : null}
    </React.Fragment>
  );
}

export default FilterByFeature;
