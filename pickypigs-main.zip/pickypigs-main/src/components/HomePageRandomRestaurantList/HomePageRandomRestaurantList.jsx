import React, { useEffect } from "react";
import { Link } from "react-router-dom";
import DishBlock from "../DishBlock/DishBlock";
import "./HomePageRandomRestaurantList.scss";
import { useDispatch, useSelector } from "react-redux";
import { getRandomRestaurantsList } from "../../redux/actions/homePageAction";
// import {SERVER_URL} from '../../shared/constant'
// import Cookies from 'js-cookie'
import { DEFAULT_LAT, DEFAULT_LNG } from "../../shared/constant";
import WebRestaurantDescSkeleton from "../WebSkeleton/WebRestaurantDescSkeleton/WebRestaurantDescSkeleton";

const HomePageRandomRestaurantList = () => {
  const dispatch = useDispatch();

  //Accessing location_data from redux store Start
  const myCordinates = useSelector((state) => {
    return state.googledata;
  });
  let { overalLocation = { lat: DEFAULT_LAT, lng: DEFAULT_LNG } } = myCordinates;

  let myPreferenceData = useSelector((state) => {
    return state.myPreference;
  });

  const { allergendata, dietarydata, lifestyledata, featuredata } = myPreferenceData.selectedPreference;
  //Accessing location_data from redux store Ends

  // //Handeling Change in Cookies latitude and Longitude Start
  // const [cookiesLocation, setCookiesLocation] = useState({
  //     lat:'',
  //     lng:'',
  // })
  // useEffect(()=>{
  //     setCookiesLocation({...cookiesLocation,lat:Cookies.get('lat')?Cookies.get('lat'):DEFAULT_LAT,lng:Cookies.get('lng')?Cookies.get('lng'):DEFAULT_LNG})
  // },[Cookies.get('lat'),Cookies.get('lng')]);
  // //Handeling Change in Cookies latitude and Longitude End

  // //Assigning the latest value to myLocation depending on change in cookiesLocation and location_data Start
  // const [myLocation, setMyLocation] = useState({
  //     lat:'',
  //     lng:''
  // })
  // useEffect(() => {
  //     if( (myLocation.lat !== location_data.lat && myLocation.lng !== location_data.lng) || (myLocation.lat !== cookiesLocation.lat&&myLocation.lng !== cookiesLocation.lng) || (cookiesLocation.lat !== location_data.lat && cookiesLocation.lng !== location_data.lng) ){
  //         setMyLocation({...myLocation,lat:location_data&&location_data.lat?location_data.lat:(cookiesLocation.lat?cookiesLocation.lat:DEFAULT_LAT),lng:location_data&&location_data.lng?location_data.lng:(cookiesLocation.lng?cookiesLocation.lng:DEFAULT_LNG)});
  //     }

  // }, [location_data,cookiesLocation]);

  // //Assigning the latest value to myLocation depending on change in cookiesLocation and location_data Ends

  // //Assigning the latest value to myLocation2 depending on change in myLocation Start
  // const [myLocation2, setMyLocation2] = useState({
  //     lat:'',
  //     lng:''
  // })

  // useEffect(() => {
  //     if( myLocation2.lat != myLocation.lat &&  myLocation2.lng != myLocation.lng){
  //         setMyLocation2({...myLocation2,lat:myLocation&&myLocation.lat,lng:myLocation&&myLocation.lng});
  //     }
  // }, [myLocation.lat,myLocation.lng]);
  // //Assigning the latest value to myLocation2 depending on change in myLocation Ends

  // useEffect(()=>{
  //     if( myLocation2.lat!==""&& myLocation2.lng!==""){
  //         if( myLocation2.lat ==  myLocation.lat &&  myLocation2.lng ==  myLocation.lng){
  //             dispatch(getRandomRestaurantsList({userCoordinates:[myLocation2.lat,myLocation2.lng],start: 0,length:8}))
  //         }
  //     }
  // },[myLocation2]);

  useEffect(() => {
    if (overalLocation && overalLocation.lat && overalLocation.lng) {
      dispatch(
        getRandomRestaurantsList({
          userCoordinates: [
            overalLocation && overalLocation.lat ? overalLocation.lat : "",
            overalLocation && overalLocation.lng ? overalLocation.lng : "",
          ],
          start: 0,
          length: 8,
        })
      );
    }
    // eslint-disable-next-line
  }, [overalLocation]);

  const randomRestaurantData = useSelector((state) => {
    return state.homePage;
  });
  let { isLoading, randomRestaurantsList_Data } = randomRestaurantData;

  return (
    <React.Fragment>
      <section className="section3 mb-5 pt-5 rs-love-section position-relative zindex-1">
        <div className="container">
          <div className="row mb-4 pb-3">
            <div className="col-sm-12">
              <div className="fn-restaurant-detail d-flex justify-content-between align-items-end">
                <h1 className="sectionhead-txt">
                  FIND A RESTAURANT <br className="d-lg-block d-none" /> YOU
                  WILL LOVE
                </h1>
                {/* <Link
                  to="/restaurant_list"
                  style={{
                    display: "flex",
                    justifyContent: "center",
                    alignItems: "center",
                  }}
                  variant=""
                  className="theme-light-btn w-140 h-48 f-14"
                >
                  VIEW ALL
                </Link> */}
                {
                  allergendata.length <= 0 &&
                    dietarydata.length <= 0 &&
                    lifestyledata.length <= 0 &&
                    featuredata.length <= 0 ? (
                    <Link
                      to="/restaurant_list"
                      style={{
                        display: "flex",
                        justifyContent: "center",
                        alignItems: "center",
                      }}
                      variant=""
                      className="theme-light-btn w-140 h-48 f-14"
                    >
                      VIEW ALL
                    </Link>
                  ) : (
                    <Link
                      to={{
                        pathname: "/allrestaurant",
                        search: `?search=`,
                        state: {
                          allergendata: allergendata,
                          dietarydata: dietarydata,
                          lifestyledata: lifestyledata,
                          featuredata: featuredata,
                        },
                      }}
                      style={{
                        display: "flex",
                        justifyContent: "center",
                        alignItems: "center",
                      }}
                      variant=""
                      className="theme-light-btn w-140 h-48 f-14"
                    >
                      VIEW ALL
                    </Link>
                  )
                }{" "}
              </div>
            </div>
          </div>
          <div className="row">
            {isLoading && isLoading ? (
              <React.Fragment>
                {[1, 2, 3, 4].map((data, index) => {
                  return (
                    <React.Fragment key={index}>
                      <div className="col-sm-6 col-md-6 col-lg-3 col-xl-3">
                        <WebRestaurantDescSkeleton />
                      </div>
                    </React.Fragment>
                  );
                })}
              </React.Fragment>
            ) : (
              <React.Fragment>
                {randomRestaurantsList_Data &&
                  randomRestaurantsList_Data.data &&
                  randomRestaurantsList_Data.data.length > 0 ? (
                  <React.Fragment>
                    {randomRestaurantsList_Data.data &&
                      randomRestaurantsList_Data.data.map((data, index) => {
                        return (
                          <React.Fragment key={index}>
                            <div className="col-sm-6 col-md-6 col-lg-3 col-xl-3">
                              <Link
                                to={"/restaurant/" + data._id}
                                style={{
                                  textDecoration: "none",
                                  color: "initial",
                                }}
                              >
                                <DishBlock
                                  restaurant_name={data.name ? data.name : ""}
                                  restaurant_pic={
                                    data.restaurantProfilePhoto
                                      ? data.restaurantProfilePhoto
                                      : ""
                                  }
                                  kmvalue={
                                    data.distance && data.distance.text
                                      ? data.distance.text
                                      : ""
                                  }
                                  rating={4.5}
                                  restaurantfeature={
                                    data.restaurantFeaturesOptionsList
                                      ? data.restaurantFeaturesOptionsList
                                      : []
                                  }
                                />
                              </Link>
                            </div>
                          </React.Fragment>
                        );
                      })}
                  </React.Fragment>
                ) : (
                  <React.Fragment>
                    <p>Something Went Wrong...</p>
                  </React.Fragment>
                )}
              </React.Fragment>
            )}
          </div>
        </div>
      </section>
    </React.Fragment>
  );
};

export default HomePageRandomRestaurantList;
