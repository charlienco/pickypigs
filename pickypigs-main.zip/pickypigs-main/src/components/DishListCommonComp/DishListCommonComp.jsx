import React from "react";
import "./DishListCommonComp.scss";
import { Link as MyLink } from "react-router-dom";
import DiscDescriptionComp from "../DiscDescriptionComp/DiscDescriptionComp";
import WebDiscDescriptionCompSkeleton from "../WebSkeleton/WebDiscDescriptionCompSkeleton/WebDiscDescriptionCompSkeleton";

const DishListCommonComp = ({
  selected_data,
  datatoshow,
  handleDataToShow,
  fourmoreloading,
  fourmoredata,
}) => {
  return (
    <React.Fragment>
      <section className="dishListcommoncomp">
        <div className="row">
          <React.Fragment>
            {selected_data &&
            selected_data.data &&
            selected_data.data.length > 0 ? (
              <React.Fragment>
                <React.Fragment>
                  {selected_data &&
                    selected_data.data &&
                    selected_data.data.map((data, index) => {
                      return (
                        <div
                          key={index}
                          className="col-sm-12 col-md-12 col-lg-4 col-xl-4 mb-4"
                        >
                          <MyLink
                            to={"/restaurant_dish_info/" + data._id}
                            style={{ textDecoration: "none", color: "initial" }}
                          >
                            <DiscDescriptionComp
                              dish_name={data.name ? data.name : ""}
                              dish_image={data.dishPhoto ? data.dishPhoto : ""}
                              dish_priceunit={
                                data.dishPriceUnit ? data.dishPriceUnit : ""
                              }
                              dish_price={data.dishPrice ? data.dishPrice : "-"}
                              dish_description={
                                data.description ? data.description : ""
                              }
                              dish_menu={data.menuList ? data.menuList : []}
                              dish_allergy={
                                data.allergensList ? data.allergensList : []
                              }
                              dish_new_tag={data.new ? data.new : false}
                              dish_available_tag={
                                data.available ? data.available : false
                              }
                            />
                          </MyLink>
                        </div>
                      );
                    })}
                </React.Fragment>

                <React.Fragment>
                  {fourmoredata && fourmoredata.length > 0 ? (
                    <React.Fragment>
                      {fourmoredata &&
                        fourmoredata.map((data, index) => {
                          return (
                            <div
                              key={index}
                              className="col-sm-12 col-md-12 col-lg-4 col-xl-4 mb-4"
                            >
                              <MyLink
                                to={"/restaurant_dish_info/" + data._id}
                                style={{
                                  textDecoration: "none",
                                  color: "initial",
                                }}
                              >
                                <DiscDescriptionComp
                                  dish_name={data.name ? data.name : ""}
                                  dish_image={
                                    data.dishPhoto ? data.dishPhoto : ""
                                  }
                                  dish_priceunit={
                                    data.dishPriceUnit ? data.dishPriceUnit : ""
                                  }
                                  dish_price={
                                    data.dishPrice ? data.dishPrice : "-"
                                  }
                                  dish_description={
                                    data.description ? data.description : ""
                                  }
                                  dish_menu={data.menuList ? data.menuList : []}
                                  dish_allergy={
                                    data.allergensList ? data.allergensList : []
                                  }
                                  dish_new_tag={data.new ? data.new : false}
                                  dish_available_tag={
                                    data.available ? data.available : false
                                  }
                                />
                              </MyLink>
                            </div>
                          );
                        })}
                    </React.Fragment>
                  ) : null}
                  {fourmoreloading && fourmoreloading ? (
                    <React.Fragment>
                      {[1, 2, 3].map((index) => {
                        return (
                          <React.Fragment key={index}>
                            <div className="col-sm-12 col-md-12 col-lg-4 col-xl-4 mb-4">
                              <WebDiscDescriptionCompSkeleton />
                            </div>
                          </React.Fragment>
                        );
                      })}
                    </React.Fragment>
                  ) : null}
                </React.Fragment>

                {selected_data &&
                selected_data.totalRecords <= datatoshow ? null : (
                  <div className="col-sm-12 col-md-12 col-lg-4 col-xl-4">
                    <button
                      onClick={() => handleDataToShow(datatoshow + 3)}
                      className="btn filter-morebtn w-100"
                      style={{ maxHeight: 384 }}
                    >
                      <h4 className="brandon-Bold">
                        <b>
                          +
                          {selected_data &&
                            selected_data.totalRecords &&
                            selected_data.totalRecords - datatoshow}{" "}
                          MORE
                        </b>
                      </h4>
                    </button>
                  </div>
                )}
              </React.Fragment>
            ) : (
              <p>No Data Available</p>
            )}
          </React.Fragment>
        </div>
      </section>
    </React.Fragment>
  );
};

export default DishListCommonComp;
