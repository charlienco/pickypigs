import React from "react";
import "./RestaurantDiscSquareCardComp.scss"
import Dummy_Image from "../../assets/images/restaurant_default.jpg"
import {SERVER_URL} from '../../shared/constant'

const RestaurantDiscSquareCardComp=({name,price,priceUnit,image,dish_new_tag,dish_available_tag})=>{
    return(
        <>
        <section className="restdisc-squarecard">
                <div className="whatmenu-wrap mb-4">
                    <div className="whatmenu-img position-relative empty-restaurant-pic">
                    {image?
                        <img src={`${SERVER_URL}/${image}`} alt={name?name:'unknown'}className={`img-fluid w-100 pb-5 ${dish_available_tag?null:"gray_shadow"}`} />
                    :
                        <img src={Dummy_Image} className={`img-fluid w-100 ${dish_available_tag?null:"gray_shadow"}`}  alt={name?name:'unknown'} />
                    }
                    {dish_new_tag&&dish_new_tag?
                        <label className={`newdish-label ${dish_available_tag?null:"gray_shadow"}`}>New</label>
                    :
                        null
                    }
                    {dish_available_tag&&dish_available_tag?
                        null
                    :
                        <label className="available-label">Pigged Out</label>
                    }
                    </div>
                    <div  className={`whatmenu-details p-3 ${dish_available_tag?null:"gray_shadow"}`}>
                        <p className="whatmenu-label f-15 mb-2 brandon-Medium">{name?name:'Unknown'}</p>
                        <div className="whatmenu-price f-14 d-flex justify-content-between pt-1 pb-1">
                            <span className="txt-lightgray">{priceUnit?priceUnit:'£'} {price?parseFloat(price).toFixed(2):'Na'}</span>
                        </div>
                    </div>
                </div>
        </section>
        </>
    )
}

export default RestaurantDiscSquareCardComp;