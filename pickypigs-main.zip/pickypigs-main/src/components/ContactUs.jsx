import React from "react";
import closeicon from "../assets/images/close.svg";
import { useDispatch } from "react-redux";
import { Field, Form, Formik } from "formik";
import * as Yup from "yup";
import { addUpdateRestaurant } from "../redux/actions/generalActions";

// eslint-disable-next-line  no-useless-escape
const phoneRegex = RegExp(/^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}$/im);
// const phoneRegex = RegExp(/^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/);

const ContactUs = (props) => {
  const dispatch = useDispatch();
  const initialValues = {
    name: "",
    email: "",
    phoneNumber: "",
    company: "",
    message: "",
  };
  const validationSchema = Yup.object().shape({
    name: Yup.string().required("Name is required"),
    email: Yup.string()
      .email("Email must be a valid email")
      .required("Email is required"),
    phoneNumber: Yup.string()
      .required("Phone Number is required")
      .matches(phoneRegex, "Invalid Phone Number")
      .min(11, "to short")
      .max(11, "Not More Than 11 "),
    company: Yup.string().required("Company is required"),
    message: Yup.string().required("Message is required"),
  });

  const onSubmit = (fields, { setStatus, resetForm }) => {
    setStatus();
    dispatch(addUpdateRestaurant(fields));
    // dispatch(sendJoinUsMessage(fields));
    resetForm();
    props.onHide();
  };

  return (
    <>
      <section>
        <div>
          <div className="row">
            <div className="col-sm-12 col-md-6 col-lg-6 col-xl-6 signup-left">
              <div className="hello-msg">
                <h1 className="text-uppercase text-white brandon-Bold">
                  Hello
                  <br />
                  Newbie
                </h1>
              </div>
            </div>
            <div className="col-sm-12 col-md-12 col-lg-12 col-xl-12 signup-right partner-right-wrapper">
              <div className="row">
                <div className="col-sm-12 mb-3">
                  <button
                    className="btn modalclose-icon"
                    onClick={() => {
                      props.onHide();
                    }}
                  >
                    <img
                      src={closeicon}
                      alt="signup modal close icon"
                      className="img-fluid"
                    />
                  </button>
                  <h4 className="brandon-Bold">Partner With Us</h4>
                </div>
              </div>

              <Formik
                initialValues={initialValues}
                validationSchema={validationSchema}
                onSubmit={onSubmit}
              >
                {({
                  values,
                  errors,
                  touched,
                  handleChange,
                  handleBlur,

                  /* and other goodies */
                }) => (
                  <Form>
                    <div className="row">
                      <div className="col-sm-12">
                        <div className="form-group">
                          <Field
                            className="form-control input-custom"
                            name="name"
                            placeholder="Your Name"
                          />
                          <div className="error pink-txt f-11 mt-1">
                            {touched.name && errors.name && errors.name}
                          </div>
                        </div>
                        <div className="form-group">
                          <Field
                            className="form-control input-custom"
                            name="email"
                            placeholder="Email"
                            type="email"
                          />
                          <div className="error pink-txt f-11 mt-1">
                            {touched.email && errors.email && errors.email}
                          </div>
                        </div>
                        <div className="form-group">
                          <Field
                            className="form-control input-custom"
                            name="phoneNumber"
                            placeholder="Phone number"
                          />
                          <div className="error pink-txt f-11 mt-1">
                            {touched.phoneNumber &&
                              errors.phoneNumber &&
                              errors.phoneNumber}
                          </div>
                        </div>
                        <div className="form-group">
                          <Field
                            className="form-control input-custom"
                            name="company"
                            placeholder="Company"
                          />
                          <div className="error pink-txt f-11 mt-1">
                            {touched.company &&
                              errors.company &&
                              errors.company}
                          </div>
                        </div>
                        <div className="form-group">
                          <Field
                            component="textarea"
                            className="form-control input-custom"
                            name="message"
                            placeholder="Your message"
                          />
                          <div className="error pink-txt f-11 mt-1">
                            {touched.message &&
                              errors.message &&
                              errors.message}
                          </div>
                        </div>

                        <div className="form-group">
                          <button
                            className="pinkline-btn signup-btn rounded-pill btn mt-4 w-100 text-uppercase border-radius-25"
                            type="submit"
                          >
                            Send Message
                          </button>
                          <React.Fragment>
                            {/* {loading && loading ? <CustomLoadingComp /> : null} */}
                          </React.Fragment>
                        </div>
                      </div>
                    </div>
                  </Form>
                )}
              </Formik>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default ContactUs;
