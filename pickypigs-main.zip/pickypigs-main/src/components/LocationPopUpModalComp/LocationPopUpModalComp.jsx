import React, { useEffect, useState } from 'react';
import "./LocationPopUpModalComp.scss"

const LocationPopUpModalComp=(props)=>{
    const [show,setShow]=useState(false)
    useEffect(()=>{
        if(props.message!==0){
            setShow(true)

        }else{
            setShow(false)
        }
    },[props.message]);
    useEffect(()=>{
        props.onClickOk()
    },[props.message]);
    return(
        <React.Fragment>
            <div className={`Location_popup ${show?"d-block":"d-none"}`}>
                {props.message&&props.message==1?
                    <p><b>Welcome to Navsari.</b><br></br>
                    Showing you recommendations for Navsari. Please set a more precise location to see more relevant options</p>
                :
                    props.message&&props.message==2?
                        <p>The network is down or the positioning service can't be reached.</p>
                    :
                        props.message&&props.message==3?  
                            <p>The attempt timed out before it could get the location data.</p>
                        :
                            null
                }
                {/* <p>{props.message}</p> */}
                <div className="text-right">
                    <button className="rounded bg-primary text-white border-0 mr-2" onClick={()=>{setShow(false)}}>Later</button>
                    <button className="rounded bg-primary text-white border-0" onClick={()=>{setShow(false)}}>Okay</button>
                </div>
            </div>
        </React.Fragment>
    )
}

export default LocationPopUpModalComp;
