import React from "react";
import "./PlanSectionComp.scss";
import tickimg from "../../assets/images/tick_1.svg";
import { showAdminSignUpPopup } from "../../redux/actions/restaurantAdminAction";
import { useDispatch } from "react-redux";

const PlanSectionComp = () => {
  const dispatch = useDispatch();
  return (
    <React.Fragment>
      <section className="PlanSectionComp ">
        <section className="plan-section">
          <div className="container pl-0 pr-0">
            <div className="plan-wrapper">
              <div className="row">
                <div className="col-sm-12 col-md-12 col-lg-6 col-xl-3 plan-details-wrapper pr-0">
                  <div className="plan-details">
                    <div className="plan-head"></div>
                    <div className="plan-listing">
                      <ul className="mb-0">
                        <li className="d-flex align-items-center">
                          <p className="mb-0 f-15">
                            Appear on search and restaurant
                          </p>
                        </li>
                        <li className="d-flex align-items-center">
                          <p className="mb-0 f-15">Digital Menu </p>
                        </li>
                        <li className="d-flex align-items-center">
                          <p className="mb-0 f-15">Easy add dish </p>
                        </li>
                        <li className="d-flex align-items-center">
                          <p className="mb-0 f-15">Allergy Filters</p>
                        </li>
                        <li className="d-flex align-items-center">
                          <p className="mb-0 f-15">Lifestyle Choices</p>
                        </li>
                        <li className="d-flex align-items-center">
                          <p className="mb-0 f-15">Dietary Requirments </p>
                        </li>
                        <li className="d-flex align-items-center">
                          <p className="mb-0 f-15">Add images of dishes </p>
                        </li>
                        <li className="d-flex align-items-center">
                          <p className="mb-0 f-15">Ingredients breakdown </p>
                        </li>
                        <li className="d-flex align-items-center">
                          <p className="mb-0 f-15">
                            Calorie and Macros calculations
                          </p>
                        </li>
                        <li className="d-flex align-items-center">
                          <p className="mb-0 f-15">
                            Multiple site log in
                            <br />
                            <span className="f-13">
                              (Additional charges for each site after 2)
                            </span>
                          </p>
                        </li>
                        <li className="d-flex align-items-center">
                          <p className="mb-0 f-15">Set up support </p>
                        </li>
                        <li className="d-flex align-items-center">
                          <p className="mb-0 f-15">Allergy Declaration </p>
                        </li>
                        <li className="d-flex align-items-center">
                          <p className="mb-0 f-15">Customisable Feature</p>
                        </li>
                        <li className="d-flex align-items-center">
                          <p className="mb-0 f-15">Add own logo </p>
                        </li>
                        <li className="d-flex align-items-center">
                          <p className="mb-0 f-15">Detailed menu filter </p>
                        </li>
                        <li className="d-flex align-items-center">
                          <p className="mb-0 f-15">SEO rating </p>
                        </li>
                        <li className="d-flex align-items-center">
                          <p className="mb-0 f-15">POS integration </p>
                        </li>
                        <li className="d-flex align-items-center">
                          <p className="mb-0 f-15">Reports </p>
                        </li>
                        <li className="d-flex align-items-center">
                          <p className="mb-0 f-15">QR Ordering </p>
                        </li>
                      </ul>
                      <div className="plan-footer"></div>
                    </div>
                  </div>
                </div>
                <div className="col-sm-12 col-md-12 col-lg-6 col-xl-3 plan-details-wrapper plan-month-wrapper pl-0 pr-0">
                  <div className="plan-details bg-white">
                    <div className="plan-head d-flex align-items-center justify-content-center flex-column">
                      <h5 className="brandon-Medium text-center mb-1 text-uppercase">
                        BASIC
                      </h5>
                      <p className="text-center mb-0 f-15 gray-txt">
                        (Free 3 month trial)
                      </p>
                    </div>
                    <div className="plan-listing">
                      <ul className="mb-0">
                        <li className="d-flex align-items-center justify-content-center">
                          <img
                            src={tickimg}
                            className="img-fluid"
                            alt="img"
                            loading="lazy"
                          />
                        </li>
                        <li className="d-flex align-items-center justify-content-center">
                          <img
                            src={tickimg}
                            className="img-fluid"
                            alt="img"
                            loading="lazy"
                          />
                        </li>
                        <li className="d-flex align-items-center justify-content-center">
                          <img
                            src={tickimg}
                            className="img-fluid"
                            alt="img"
                            loading="lazy"
                          />
                        </li>
                        <li className="d-flex align-items-center justify-content-center">
                          <img
                            src={tickimg}
                            className="img-fluid"
                            alt="img"
                            loading="lazy"
                          />
                        </li>
                        <li className="d-flex align-items-center justify-content-center">
                          <img
                            src={tickimg}
                            className="img-fluid"
                            alt="img"
                            loading="lazy"
                          />
                        </li>
                        <li className="d-flex align-items-center justify-content-center">
                          <img
                            src={tickimg}
                            className="img-fluid"
                            alt="img"
                            loading="lazy"
                          />
                        </li>
                        <li className="d-flex align-items-center justify-content-center">
                          <img
                            src={tickimg}
                            className="img-fluid"
                            alt="img"
                            loading="lazy"
                          />
                        </li>
                        <li className="d-flex align-items-center justify-content-center">
                          <p className="mb-0 f-15"></p>
                        </li>
                        <li className="d-flex align-items-center justify-content-center">
                          <p className="mb-0 f-15"></p>
                        </li>
                        <li className="d-flex align-items-center justify-content-center">
                          <p className="mb-0 f-15"></p>
                        </li>
                        <li className="d-flex align-items-center justify-content-center">
                          <p className="mb-0 f-15">ONLINE</p>
                        </li>
                        <li className="d-flex align-items-center justify-content-center">
                          <p className="mb-0 f-15"></p>
                        </li>
                        <li className="d-flex align-items-center justify-content-center">
                          <p className="mb-0 f-15"></p>
                        </li>
                        <li className="d-flex align-items-center justify-content-center">
                          <p className="mb-0 f-15"></p>
                        </li>
                        <li className="d-flex align-items-center justify-content-center">
                          <p className="mb-0 f-15"></p>
                        </li>
                        <li className="d-flex align-items-center justify-content-center">
                          <p className="mb-0 f-15"></p>
                        </li>
                        <li className="d-flex align-items-center justify-content-center">
                          <p className="mb-0 f-15"></p>
                        </li>
                        <li className="d-flex align-items-center justify-content-center">
                          <p className="mb-0 f-15"></p>
                        </li>
                        <li className="d-flex align-items-center justify-content-center">
                          <p className="mb-0 f-15"></p>
                        </li>
                        {/* <li className="d-flex align-items-center justify-content-center">
                          <p className="mb-0 f-15">Yes</p>
                        </li>
                        <li className="d-flex align-items-center justify-content-center">
                          <p className="mb-0 f-15">-</p>
                        </li>
                        <li className="d-flex align-items-center justify-content-center">
                          <img
                            src={tickimg}
                            className="img-fluid"
                            alt="img"
                            loading="lazy"
                          />
                        </li>
                        <li className="d-flex align-items-center justify-content-center">
                          <p className="mb-0 f-15">-</p>
                        </li>
                        <li className="d-flex align-items-center justify-content-center">
                          <img
                            src={tickimg}
                            className="img-fluid"
                            alt="img"
                            loading="lazy"
                          />
                        </li>
                        <li className="d-flex align-items-center justify-content-center">
                          <img
                            src={tickimg}
                            className="img-fluid"
                            alt="img"
                            loading="lazy"
                          />
                        </li>
                        <li className="d-flex align-items-center justify-content-center">
                          <img src={tickimg} className="img-fluid" />
                        </li>
                        <li className="d-flex align-items-center justify-content-center">
                          <img
                            src={tickimg}
                            className="img-fluid"
                            alt="img"
                            loading="lazy"
                          />
                        </li> */}
                      </ul>
                      <div className="plan-footer flex-column d-flex align-items-center justify-content-center">
                        <p className="gray-txt mb-0 price-label">
                          $120 / £60<span className="month-label">/ month</span>
                        </p>
                        <p className="f-15 gray-txt mb-3 pb-1 pl-3 pr-3 text-center">
                          We'll contact you directly to discuss pricing options.
                        </p>
                        <button
                          onClick={() => {
                            dispatch(showAdminSignUpPopup(true, "Basic"));
                          }}
                          className="f-15 text-uppercase btn pinkline-btn min-height-50 min-width-170 border-radius-25"
                        >
                          Sign up
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="col-sm-12 col-md-12 col-lg-6 col-xl-3 plan-details-wrapper plan-month-wrapper active-view pl-0 pr-0">
                  <div className="plan-details bg-white">
                    <div className="plan-head d-flex align-items-center justify-content-center flex-column">
                      <h5 className="brandon-Medium text-center mb-1 text-uppercase">
                        STANDARD
                      </h5>
                      <p className="text-center mb-0 f-15 gray-txt">
                        Reccomended
                      </p>
                    </div>
                    <div className="plan-listing">
                      <ul className="mb-0">
                        <li className="d-flex align-items-center justify-content-center">
                          <img
                            src={tickimg}
                            className="img-fluid"
                            alt="img"
                            loading="lazy"
                          />
                        </li>
                        <li className="d-flex align-items-center justify-content-center">
                          <img
                            src={tickimg}
                            className="img-fluid"
                            alt="img"
                            loading="lazy"
                          />
                        </li>
                        <li className="d-flex align-items-center justify-content-center">
                          <img
                            src={tickimg}
                            className="img-fluid"
                            alt="img"
                            loading="lazy"
                          />
                        </li>
                        <li className="d-flex align-items-center justify-content-center">
                          <img
                            src={tickimg}
                            className="img-fluid"
                            alt="img"
                            loading="lazy"
                          />
                        </li>
                        <li className="d-flex align-items-center justify-content-center">
                          <img
                            src={tickimg}
                            className="img-fluid"
                            alt="img"
                            loading="lazy"
                          />
                        </li>
                        <li className="d-flex align-items-center justify-content-center">
                          <img
                            src={tickimg}
                            className="img-fluid"
                            alt="img"
                            loading="lazy"
                          />
                        </li>
                        <li className="d-flex align-items-center justify-content-center">
                          <img
                            src={tickimg}
                            className="img-fluid"
                            alt="img"
                            loading="lazy"
                          />
                        </li>
                        <li className="d-flex align-items-center justify-content-center">
                          <img
                            src={tickimg}
                            className="img-fluid"
                            alt="img"
                            loading="lazy"
                          />
                        </li>
                        <li className="d-flex align-items-center justify-content-center">
                          <p className="mb-0 f-15"></p>
                        </li>
                        <li className="d-flex align-items-center justify-content-center">
                          <p className="mb-0 f-15"></p>
                        </li>
                        <li className="d-flex align-items-center justify-content-center">
                          <p className="mb-0 f-15">ONLINE</p>
                        </li>
                        <li className="d-flex align-items-center justify-content-center">
                          <img
                            src={tickimg}
                            className="img-fluid"
                            alt="img"
                            loading="lazy"
                          />
                        </li>
                        <li className="d-flex align-items-center justify-content-center">
                          <img
                            src={tickimg}
                            className="img-fluid"
                            alt="img"
                            loading="lazy"
                          />
                        </li>
                        <li className="d-flex align-items-center justify-content-center">
                          <p className="mb-0 f-15">-</p>
                        </li>
                        <li className="d-flex align-items-center justify-content-center">
                          <p className="mb-0 f-15">-</p>
                        </li>
                        <li className="d-flex align-items-center justify-content-center">
                          <p className="mb-0 f-15">-</p>
                        </li>
                        <li className="d-flex align-items-center justify-content-center">
                          <img
                            src={tickimg}
                            className="img-fluid"
                            alt="img"
                            loading="lazy"
                          />
                        </li>
                        <li className="d-flex align-items-center justify-content-center">
                          <p className="mb-0 f-15">-</p>
                        </li>
                        <li className="d-flex align-items-center justify-content-center">
                          <p className="mb-0 f-15">YES % OF SALE VALUE</p>
                        </li>
                        {/* <li className="d-flex align-items-center justify-content-center">
                          <p className="mb-0 f-15">Yes</p>
                        </li>
                        <li className="d-flex align-items-center justify-content-center">
                          <p className="mb-0 f-15">-</p>
                        </li>
                        <li className="d-flex align-items-center justify-content-center">
                          <img
                            src={tickimg}
                            className="img-fluid"
                            alt="img"
                            loading="lazy"
                          />
                        </li>
                        <li className="d-flex align-items-center justify-content-center">
                          <p className="mb-0 f-15">-</p>
                        </li>
                        <li className="d-flex align-items-center justify-content-center">
                          <img
                            src={tickimg}
                            className="img-fluid"
                            alt="img"
                            loading="lazy"
                          />
                        </li>
                        <li className="d-flex align-items-center justify-content-center">
                          <img
                            src={tickimg}
                            className="img-fluid"
                            alt="img"
                            loading="lazy"
                          />
                        </li>
                        <li className="d-flex align-items-center justify-content-center">
                          <img
                            src={tickimg}
                            className="img-fluid"
                            alt="img"
                            loading="lazy"
                          />
                        </li>
                        <li className="d-flex align-items-center justify-content-center">
                          <img
                            src={tickimg}
                            className="img-fluid"
                            alt="img"
                            loading="lazy"
                          />
                        </li> */}
                      </ul>
                      <div className="plan-footer flex-column d-flex align-items-center justify-content-center">
                        <p className="mb-0 price-label">
                          $220 / £110
                          <span className="month-label">/ month</span>
                        </p>
                        <p className="f-15 mb-3 pb-1 pl-3 pr-3 text-center">We'll contact you directly to discuss pricing options.</p>
                        <button
                          onClick={() => {
                            dispatch(showAdminSignUpPopup(true, "Standard"));
                          }}
                          className="f-15 text-uppercase btn pinkline-btn min-height-50 min-width-170 border-radius-25"
                        >
                          Sign up
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="col-sm-12 col-md-12 col-lg-6 col-xl-3 plan-details-wrapper plan-month-wrapper pl-0 pr-0">
                  <div className="plan-details bg-white">
                    <div className="plan-head d-flex align-items-center justify-content-center flex-column">
                      <h5 className="brandon-Medium text-center mb-1 text-uppercase">
                        PREMIUM
                      </h5>
                      <p className="text-center mb-0 f-15 gray-txt">
                        Based on number of venues.
                      </p>
                    </div>
                    <div className="plan-listing">
                      <ul className="mb-0">
                        <li className="d-flex align-items-center justify-content-center">
                          <img
                            src={tickimg}
                            className="img-fluid"
                            alt="img"
                            loading="lazy"
                          />
                        </li>
                        <li className="d-flex align-items-center justify-content-center">
                          <img
                            src={tickimg}
                            className="img-fluid"
                            alt="img"
                            loading="lazy"
                          />
                        </li>
                        <li className="d-flex align-items-center justify-content-center">
                          <img
                            src={tickimg}
                            className="img-fluid"
                            alt="img"
                            loading="lazy"
                          />
                        </li>
                        <li className="d-flex align-items-center justify-content-center">
                          <img
                            src={tickimg}
                            className="img-fluid"
                            alt="img"
                            loading="lazy"
                          />
                        </li>
                        <li className="d-flex align-items-center justify-content-center">
                          <img
                            src={tickimg}
                            className="img-fluid"
                            alt="img"
                            loading="lazy"
                          />
                        </li>
                        <li className="d-flex align-items-center justify-content-center">
                          <img
                            src={tickimg}
                            className="img-fluid"
                            alt="img"
                            loading="lazy"
                          />
                        </li>
                        <li className="d-flex align-items-center justify-content-center">
                          <img
                            src={tickimg}
                            className="img-fluid"
                            alt="img"
                            loading="lazy"
                          />
                        </li>
                        <li className="d-flex align-items-center justify-content-center">
                          <img
                            src={tickimg}
                            className="img-fluid"
                            alt="img"
                            loading="lazy"
                          />
                        </li>
                        <li className="d-flex align-items-center justify-content-center">
                          <img
                            src={tickimg}
                            className="img-fluid"
                            alt="img"
                            loading="lazy"
                          />
                        </li>
                        <li className="d-flex align-items-center justify-content-center">
                          <img
                            src={tickimg}
                            className="img-fluid"
                            alt="img"
                            loading="lazy"
                          />
                        </li>
                        <li className="d-flex align-items-center justify-content-center">
                          <p className="mb-0 f-15">PHONE / ONLINE</p>
                        </li>
                        <li className="d-flex align-items-center justify-content-center">
                          <img
                            src={tickimg}
                            className="img-fluid"
                            alt="img"
                            loading="lazy"
                          />
                        </li>
                        <li className="d-flex align-items-center justify-content-center">
                          <img
                            src={tickimg}
                            className="img-fluid"
                            alt="img"
                            loading="lazy"
                          />
                        </li>
                        <li className="d-flex align-items-center justify-content-center">
                          <img
                            src={tickimg}
                            className="img-fluid"
                            alt="img"
                            loading="lazy"
                          />
                        </li>
                        <li className="d-flex align-items-center justify-content-center">
                          <img
                            src={tickimg}
                            className="img-fluid"
                            alt="img"
                            loading="lazy"
                          />
                        </li>
                        <li className="d-flex align-items-center justify-content-center">
                          <img
                            src={tickimg}
                            className="img-fluid"
                            alt="img"
                            loading="lazy"
                          />
                        </li>
                        <li className="d-flex align-items-center justify-content-center">
                          <img
                            src={tickimg}
                            className="img-fluid"
                            alt="img"
                            loading="lazy"
                          />
                        </li>
                        <li className="d-flex align-items-center justify-content-center">
                          <img
                            src={tickimg}
                            className="img-fluid"
                            alt="img"
                            loading="lazy"
                          />
                        </li>
                        <li className="d-flex align-items-center justify-content-center">
                          <p className="mb-0 f-15">YES % OF SALE VALUE</p>
                        </li>
                        {/* <li className="d-flex align-items-center justify-content-center">
                          <p className="mb-0 f-15">Yes</p>
                        </li>
                        <li className="d-flex align-items-center justify-content-center">
                          <p className="mb-0 f-15">-</p>
                        </li>
                        <li className="d-flex align-items-center justify-content-center">
                          <img
                            src={tickimg}
                            className="img-fluid"
                            alt="img"
                            loading="lazy"
                          />
                        </li>
                        <li className="d-flex align-items-center justify-content-center">
                          <p className="mb-0 f-15">-</p>
                        </li>
                        <li className="d-flex align-items-center justify-content-center">
                          <img
                            src={tickimg}
                            className="img-fluid"
                            alt="img"
                            loading="lazy"
                          />
                        </li>
                        <li className="d-flex align-items-center justify-content-center">
                          <img
                            src={tickimg}
                            className="img-fluid"
                            alt="img"
                            loading="lazy"
                          />
                        </li>
                        <li className="d-flex align-items-center justify-content-center">
                          <img
                            src={tickimg}
                            className="img-fluid"
                            alt="img"
                            loading="lazy"
                          />
                        </li>
                        <li className="d-flex align-items-center justify-content-center">
                          <img src={tickimg} className="img-fluid" />
                        </li> */}
                      </ul>
                      <div className="plan-footer flex-column d-flex align-items-center justify-content-center">
                        <p className="gray-txt mb-0 price-label">
                          Contact us
                          {/* <span className="month-label">/ month</span> */}
                        </p>
                        <p className="f-15 gray-txt mb-3 pb-1 pl-3 pr-3 text-center">
                          We'll contact you directly to discuss pricing options.
                        </p>
                        <button
                          onClick={() => {
                            dispatch(showAdminSignUpPopup(true, "Premium"));
                          }}
                          className="f-15 text-uppercase btn pinkline-btn min-height-50 min-width-170 border-radius-25"
                        >
                          Sign up
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </section>
    </React.Fragment>
  );
};

export default PlanSectionComp;
