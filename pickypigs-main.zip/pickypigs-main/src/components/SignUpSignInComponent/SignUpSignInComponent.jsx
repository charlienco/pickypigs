import React, { useState } from "react";
import { Field, Form, Formik } from "formik";
import * as Yup from "yup";
import { useDispatch, useSelector } from "react-redux";
import showpassword from "../../assets/images/eye_icon.svg";
import "./SignUpSignInComponent.scss";
import CustomLoadingComp from "../CustomLoadingComp/CustomLoadingComp";
import {
  getAdminLogin,
  showAdminSignUpPopup,
  forgotAdminPassword,
  showContactUsPopup,
} from "../../redux/actions/restaurantAdminAction";

// eslint-disable-next-line no-useless-escape
const passwordRegExp = RegExp(/^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,24})/);

const validationSchemaForLogin = Yup.object().shape({
  email: Yup.string()
    .email("Email must be a valid email")
    .required("Email Required"),
  password: Yup.string()
    .label("Password")
    .required("Password Required")
    .min(8, "Seems a bit short(Min 8 characters)...")
    .max(24, "Please try a shorter password(Max 24 characters)...).")
    .matches(
      passwordRegExp,
      "Password should Have 1 Uppercase,1 Lowercase,1 digit,1 special characte"
    ),
});
const validationSchemaForForgotPassword = Yup.object().shape({
  email: Yup.string()
    .email("Email must be a valid email")
    .required("Email Required"),
});
const SignUpSignInComponent = () => {
  const dispatch = useDispatch();
  const [type, setType] = useState("password");
  const [isLoginPage, setLoginPage] = useState(true);

  const handleLoginForm = (input) => {
    let obj = {
      email: input.email,
      password: input.password,
    };
    dispatch(getAdminLogin(obj));
  };

  const handlelForgotPassword = (input) => {
    let obj = {
      email: input.email,
    };
    dispatch(forgotAdminPassword(obj));
  };
  const handlePassword = () => {
    let ele = document.getElementById("password");
    if (type === "password") {
      ele.classList.add("show");
      setType("text");
    } else {
      ele.classList.remove("show");
      setType("password");
    }
  };

  let loading = useSelector((state) => {
    return state.restaurantAdmin.isLoginLoading;
  });

  const isLoading = useSelector((state) => state.general.isLoginLoading);

  let forgotLoading = useSelector((state) => {
    return state.restaurantAdmin.isForgotPasswordLoading;
  });
  // const messageTimer=()=>{
  //     setError(true)
  //     setInterval(function(){ setError(false)}, 5000);
  // }
  // useEffect(()=>{
  //     if(forgotPasswordData.message){
  //         messageTimer();
  //     }
  // },[forgotPasswordData.message]);

  return (
    <>
      {isLoading ? <CustomLoadingComp /> : null}

      <br />
      <br />
      <br />
      <br />
      <br />
      <br />
      <br />
      <section className="SignUpSignInComponent">
        <div className="row justify-content-between align-items-center">
          <div className="col-sm-12 col-md-6 col-lg-6 col-xl-6">
            <div className="signin-left pt-4 mt-2">
              <h1 className="brandon-Bold">PARTNER WITH US</h1>

              <p className="f-15">
                The ultimate food-finding application, bridging the gap between
                you and your perfect guest. Your allergy, calorie, macro and
                digital menu solution.
              </p>
              <p className="f-15 mb-4">
                Digital menus personalised by allergy requirements, dietary
                preferences and lifestyle choices. Let your customer easily
                discover your venue and dishes in a safe, transparent and
                accessible way. Support your teams and guests in making the best
                choices in what and where they do or don't want to eat.
              </p>
              <div className="form-group">
                <button
                  onClick={() => {
                    dispatch(showAdminSignUpPopup(true));
                  }}
                  className="pinkline-btn signup-btn btn min-width-270 text-uppercase rounded-pill"
                >
                  Sign Up
                </button>
              </div>
            </div>
          </div>

          <div className="col-md-6">
            <div className="signin-form ">
              {isLoginPage ? (
                <div>
                  <h5 className="text-center signindash-heading brandon-Bold mb-4">
                    SIGN IN TO YOUR DASHBOARD
                  </h5>
                  <Formik
                    initialValues={{ email: "", password: "" }}
                    validationSchema={validationSchemaForLogin}
                    onSubmit={(values) => {
                      // console.log("values => ", values);
                      handleLoginForm(values);
                    }}
                  >
                    {({
                      values,
                      errors,
                      touched,
                      handleChange,
                      handleBlur,
                      isSubmitting,
                      /* and other goodies */
                    }) => (
                      <Form>
                        <div className="row">
                          <div className="col-sm-12">
                            <div className="form-group">
                              <Field
                                name="email"
                                placeholder="Email"
                                className="form-control signup-input"
                              />
                              {touched.email && errors.email && (
                                <div className="error pink-txt f-11">
                                  {errors.email}
                                </div>
                              )}
                            </div>
                            <div className="form-group position-relative">
                              <Field
                                type={type}
                                name="password"
                                placeholder="Password"
                                className="form-control signup-input"
                              />
                              <div
                                className="showpassword-block"
                                id="password"
                                onClick={() => handlePassword()}
                              >
                                <img
                                  src={showpassword}
                                  className="img-fluid"
                                  alt="showpassword"
                                />
                              </div>
                              <div className="error pink-txt f-11">
                                {touched.password &&
                                  errors.password &&
                                  errors.password}
                              </div>
                            </div>
                            <div className="forgot-block text-center mt-3 mb-2">
                              <button
                                onClick={() => {
                                  setLoginPage(false);
                                }}
                                className="forgot-link trans_button"
                                type="button"
                              >
                                <span>Forgot Password ?</span>
                              </button>
                            </div>
                            <div className="form-group text-center">
                              <button
                                className="min-width-270 pinkline-btn signup-btn btn mt-4 text-uppercase rounded-pill"
                                type="submit"
                              >
                                Log in
                              </button>
                            </div>
                            <div className="form-group text-center add-update-restaurant-container">
                              {/*  eslint-disable-next-line */}
                              <a href="javascript:void(0)" className="add-update-restaurant" onClick={() => dispatch(showContactUsPopup(true)) }
                              >
                                Have you seen your restaurant on Picky Pigs and
                                want to update it?
                              </a>

                              {/* <button
                                onClick={() =>
                                  dispatch(showContactUsPopup(true))
                                }
                                className="min-width-270 pinkline-btn signup-btn btn mt-4 text-uppercase rounded-pill"
                              >
                                Add/Update Restaurant
                              </button> */}
                            </div>
                          </div>
                          <React.Fragment>
                            {loading && loading ? <CustomLoadingComp /> : null}
                          </React.Fragment>
                        </div>
                      </Form>
                    )}
                  </Formik>
                </div>
              ) : (
                <React.Fragment>
                  <h5 className="text-center signindash-heading brandon-Bold mb-4">
                    RESET PASSWORD
                  </h5>
                  <p className="f-15">
                    <span className="pr-2">
                      Enter your email address in the for below and we will send
                      you further instructions on how toreset your password.
                    </span>
                  </p>
                  <Formik
                    initialValues={{ email: "" }}
                    validationSchema={validationSchemaForForgotPassword}
                    onSubmit={(values, { setSubmitting }) => {
                      // console.log("values => ", values);

                      handlelForgotPassword(values);
                      setSubmitting(false);
                    }}
                  >
                    {({
                      values,
                      errors,
                      touched,
                      handleChange,
                      handleBlur,
                      isSubmitting,
                      /* and other goodies */
                    }) => (
                      <Form>
                        <div className="row">
                          <div className="col-sm-12">
                            <div className="form-group">
                              <Field
                                name="email"
                                placeholder="Email"
                                className="form-control signup-input"
                              />
                              {touched.email && errors.email && (
                                <div className="error pink-txt f-11">
                                  {errors.email}
                                </div>
                              )}
                            </div>
                            <div className="forgot-block text-center mt-3 mb-2">
                              <button
                                type="button"
                                onClick={() => {
                                  setLoginPage(true);
                                }}
                                className="forgot-link trans_button"
                              >
                                <span>Sign In ?</span>
                              </button>
                            </div>
                            {/* {error?
                                             <p> {forgotPasswordData&& forgotPasswordData.message}</p>
                                             :
                                             null
                                            } */}

                            <div className="form-group">
                              <button
                                className="pinkline-btn signup-btn btn mt-4 w-100 text-uppercase border-radius-25 "
                                type="submit"
                              >
                                RESET PASSWORD
                              </button>
                            </div>
                            <React.Fragment>
                              {forgotLoading && forgotLoading ? (
                                <CustomLoadingComp />
                              ) : null}
                            </React.Fragment>
                          </div>
                        </div>
                      </Form>
                    )}
                  </Formik>
                </React.Fragment>
              )}
            </div>
          </div>
        </div>
      </section>
      <br />
      <br />
      <br />
      <br />
      <br />
    </>
  );
};

export default SignUpSignInComponent;
