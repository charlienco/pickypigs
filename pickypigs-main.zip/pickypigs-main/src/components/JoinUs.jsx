import React from 'react'

const JoinUs =()=> {
    return (
        <div>

        </div>
    )
}

export default JoinUs
