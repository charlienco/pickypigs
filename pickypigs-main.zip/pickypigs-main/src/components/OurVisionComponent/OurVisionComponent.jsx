import React from "react";
import ourmisssion_icon1 from "../../assets/images/ourmission-icon1.svg";
import ourmisssion_icon2 from "../../assets/images/ourmission-icon2.svg";
import ourmisssion_icon3 from "../../assets/images/ourmission-icon3.svg";
import ourmisssion_icon4 from "../../assets/images/ourmission-icon4.svg";
import { Formik, Field, Form } from "formik";
import * as Yup from "yup";

import "./OurVisionComponent.scss";
import { useDispatch } from "react-redux";
import { sendJoinUsMessage } from "../../redux/actions/generalActions";

const phoneRegex = RegExp(/^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/);

const OurVisionComponent = () => {
  const dispatch = useDispatch();
  const initialValue = {
    name: "",
    email: "",
    phoneNumber: "",
    company: "",
    message: "",
  };
  const validationSchema = Yup.object().shape({
    name: Yup.string().required("Name is required"),
    email: Yup.string()
      .email("Email must be a valid email")
      .required("Email is required"),
    phoneNumber: Yup.string()
      .required("Phone Number is required")
      .matches(phoneRegex, "Invalid Phone Number")
      .min(10, "to short")
      .max(10, "Not More Than 10 "),
    company: Yup.string().required("Company is required"),
    message: Yup.string().required("Message is required"),
  });

  const onSubmit = (fields, { setStatus, resetForm }) => {
    setStatus();
    dispatch(sendJoinUsMessage(fields));
    resetForm();
  };

  return (
    <>
      {/* Would you like to join us? start content */}
      <section className="ourmission-section position-relative zindex-1">
        <div className="container">
          <div className="row">
            <div className="col-sm-12 pl-0 pr-0">
              <div className="ourmission-wrapper">
                <h1 className="sectionhead-txt text-uppercase text-white brandon-Medium fw-600">
                  Our Mission{" "}
                </h1>
                <p className="ourmission-subtxt f-15 line-height-1_75 text-white">
                  At Picky Pigs, we believe that the detail matters. We want to
                  raise the bar in both the customer journey and the industry
                  standard.
                  {/* <br className="d-lg-block d-none" /> With fuss free food from
                  every angle, nothing needs to be an issue with Picky Pigs. */}
                </p>
                <div className="row mt-4 pt-2 jusitify-content-betwen">
                  <div className="col-sm-12 col-md-6 col-lg-6 col-xl-3 ourmission-main mb-2">
                    <div className="ourmission-block">
                      <div className="ourmission-icon d-flex align-items-center justify-content-center mb-4">
                        <img
                          src={ourmisssion_icon1}
                          className="img-fluid"
                          alt="our-mission"
                        />
                      </div>
                      <div className="ourmission-info pt-1">
                        <p className="f-15 mb-1">
                          To make fuss free food more easily accessible,
                          regardless of dietary needs and preferences.
                        </p>
                      </div>
                    </div>
                  </div>
                  <div className="col-sm-12 col-md-6 col-lg-6 col-xl-3 ourmission-main mb-2">
                    <div className="ourmission-block">
                      <div className="ourmission-icon d-flex align-items-center justify-content-center mb-4">
                        <img
                          src={ourmisssion_icon2}
                          className="img-fluid"
                          alt="ourmission2"
                        />
                      </div>
                      <div className="ourmission-info pt-1">
                        <p className="f-15 mb-1">
                          To encourage and support transparency and build trust.
                        </p>
                      </div>
                    </div>
                  </div>
                  <div className="col-sm-12 col-md-6 col-lg-6 col-xl-3 ourmission-main mb-2">
                    <div className="ourmission-block">
                      <div className="ourmission-icon d-flex align-items-center justify-content-center mb-4">
                        <img
                          src={ourmisssion_icon3}
                          className="img-fluid"
                          alt="ourmission3"
                        />
                      </div>
                      <div className="ourmission-info pt-1">
                        <p className="f-15 mb-1">
                          To eliminate as much human error as possible.
                        </p>
                      </div>
                    </div>
                  </div>
                  <div className="col-sm-12 col-md-6 col-lg-6 col-xl-3 ourmission-main mb-2">
                    <div className="ourmission-block">
                      <div className="ourmission-icon d-flex align-items-center justify-content-center mb-4">
                        <img
                          src={ourmisssion_icon4}
                          className="img-fluid"
                          alt="ourmission4"
                        />
                      </div>
                      <div className="ourmission-info pt-1">
                        <p className="f-15 mb-1">
                          To enhance the entire dining out experience from
                          beginning to end.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <br />
          <br />
          <br />
          <div className="row">
            <div className="col-sm-12 pl-0 pr-0">
              <h1 className="sectionhead-txt text-uppercase text-white brandon-Medium fw-600">
                WOULD YOU LIKE TO JOIN US?{" "}
              </h1>
              <p className="join-subtxt f-15 line-height-1_75 text-white mb-4 pb-2">
                The ultimate food-finding application, bridging the gap between
                you and your perfect guest. Your allergy, calorie,
                <br className="d-lg-block d-none" /> macro and digital menu
                solution. Enquire today and finding the best solution to
                digitalise you menu and business.
              </p>
            </div>
          </div>
          <div className="row">
            <Formik
              enableReinitialize={true}
              initialValues={initialValue}
              validationSchema={validationSchema}
              onSubmit={onSubmit}
            >
              {({
                errors,
                touched,
                values,
                isSubmitting,
                setFieldValue,
                handleChange,
              }) => {
                return (
                  <Form className="w-100">
                    <div className="row join-form-wrapper">
                      <div className="col-md-4 join-input-left">
                        <div className="row">
                          <div className="col-sm-12">
                            <div className="form-group">
                              <Field
                                className="form-control join-input"
                                name="name"
                                placeholder="Your Name"
                              />
                              <div className="error text-white f-14 mt-1">
                                {touched.name && errors.name && errors.name}
                              </div>
                            </div>
                          </div>
                          <div className="col-sm-12">
                            <div className="form-group">
                              <Field
                                className="form-control join-input"
                                name="email"
                                placeholder="Email"
                                type="email"
                              />
                              <div className="error text-white f-14 mt-1">
                                {touched.email && errors.email && errors.email}
                              </div>
                            </div>
                          </div>
                          <div className="col-sm-12">
                            <div className="form-group">
                              <Field
                                className="form-control join-input"
                                name="phoneNumber"
                                placeholder="Phone number"
                              />
                              <div className="error text-white f-14 mt-1">
                                {touched.phoneNumber &&
                                  errors.phoneNumber &&
                                  errors.phoneNumber}
                              </div>
                            </div>
                          </div>
                          <div className="col-sm-12">
                            <div className="form-group">
                              <Field
                                className="form-control join-input"
                                name="company"
                                placeholder="Company"
                              />
                              <div className="error text-white f-14 mt-1">
                                {touched.company &&
                                  errors.company &&
                                  errors.company}
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="col-md-8 join-input-right">
                        <div className="form-group">
                          <Field
                            component="textarea"
                            className="form-control join-textarea"
                            name="message"
                            placeholder="Your message"
                          />
                          <div className="error text-white f-14 mt-1">
                            {touched.message &&
                              errors.message &&
                              errors.message}
                          </div>
                        </div>
                        <div className="d-flex justify-content-end">
                          <button
                            className="btn white-btn text-uppercase h_50 min-w-180 b-r-25 brandon-Medium"
                            type="submit"
                          >
                            Send message
                          </button>
                        </div>
                      </div>
                    </div>
                  </Form>
                );
              }}
            </Formik>
          </div>
          <div className="row mt-4 pt-2">
            <div className="col-sm-12 pl-0 pr-0">
              <hr className="light-white-hr" />
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default OurVisionComponent;
