import React, { useState } from "react";
import { Modal, Button, } from "react-bootstrap";
import './RestaurantCookingMethodModal.scss';
import cookingicon from "../../assets/images/dishinfo_img/cooking.svg";
import rightarrow from "../../assets/images/dishinfo_img/right-arrow.svg";
import {SERVER_URL} from '../../shared/constant'
import OverlayTrigger from "react-bootstrap/OverlayTrigger";
import Tooltip from "react-bootstrap/Tooltip";
const RestaurantCookingMethodModal = (props) => {
    const [show, setShow] = useState(false);

    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);

    return (
        <>
            <div className="rs-cookingbtn">
                <Button variant="primary" onClick={handleShow}>
                    <div className="d-flex align-items-center mb-0 icontext-content">
                        <div className="d-flex align-items-center w-100">
                            <img src={cookingicon} alt="" className="img-fluid mr-2 position-absolute" />
                            <div className="d-flex align-items-center w-100 justify-content-between rs-infomodal-sub">
                                <span className="pl-4 ml-2 text-left rs-infomodal-name">Cooking Method</span>
                                <div><img src={rightarrow} alt="" className="img-fluid" /></div>
                            </div>
                        </div>
                    </div>
                    <p className="rs-infomodalbtn-detail mb-0 text-left">See how we cook</p>
                </Button>
            </div>
            <Modal className="rs-discCookinginfomadel" show={show} onHide={handleClose} animation={false} style={{ width: 400, marginLeft: 'auto', right: 0, top: 0 }}>
                <Modal.Header closeButton className="border-bottom-0 align-items-center">
                    <Modal.Title className="w-100">
                        <div className="d-flex align-items-center mb-0 rsd-icontext-content">
                            <div className="d-flex align-items-center w-100">
                                <img src={cookingicon} alt="" className="img-fluid mr-2 position-absolute" />
                                <div className="d-flex align-items-center w-100 justify-content-between rsd-allergiesinfomodal-sub">
                                    <span className="pl-4 ml-2 text-left rsd-allergiesinfomodal-name">Cooking Method<br></br><b>See How we cook</b></span>
                                    <div className="mt-3"><span><b>
                                        {props.caloriesandmacrosdetail&&props.caloriesandmacrosdetail.total?props.caloriesandmacrosdetail.total:'-'}
                                    </b></span></div>
                                </div>
                            </div>
                        </div>
                    </Modal.Title>
                </Modal.Header>

                <Modal.Body>
                    <div>
                        <hr className="mt-0 mb-0"></hr>
                    </div>
                    
                    <div className="table-responsive rscategory-detail">
                        <table className="table">
                            <tbody>
                                {props.cookingdata&&props.cookingdata.length>0?
                                    <React.Fragment>
                                        {props.cookingdata&&props.cookingdata.map((data,index)=>{
                                            return(
                                                <React.Fragment key={index}>
                                                    <tr>
                                                        <td  className="fw-400 text-right pl-0 pr-0 pt-1 pb-1 border-top-0 whatmeu-types d-flex justify-content-between align-items-center">
                                                        <b>{data.name?data.name:"Unknown"}</b>
                                                            {data&&data.image?
                                                                <OverlayTrigger placement="bottom" overlay={<Tooltip  id={`tooltip-${index}`} >{data.name?data.name:"Unknown"}</Tooltip>} >
                                                                    <div className="whatmenu-list d-flex justify-content-center align-items-center">
                                                                        <img src={`${SERVER_URL}/${data.image}`} className="img-fluid allergy_icon_image" alt="img" loading="lazy"/>
                                                                    </div>
                                                                </OverlayTrigger>
                                                            :
                                                                <OverlayTrigger placement="bottom" overlay={<Tooltip  id={`tooltipOne-${index}`} >{data.name?data.name:"Unknown"}</Tooltip>} >
                                                                    <div className="whatmenu-list d-flex justify-content-center align-items-center">
                                                                        <img src={cookingicon} className="img-fluid allergy_icon_image" alt="img" loading="lazy" />
                                                                    </div>
                                                                </OverlayTrigger>
                                                            }
                                                        </td>
                                                    </tr>
                                                    <div>
                                                        <hr className="mt-3 mb-1"></hr>
                                                    </div>
                                                </React.Fragment>
                                            )
                                        })}
                                    </React.Fragment>
                                :
                                    <React.Fragment>
                                        <tr>
                                            <td  className="fw-400 pl-0 pr-0 border-top-0 pt-1 pb-1 text-left">No Data Available</td>
                                        </tr>
                                        <div>
                                            <hr className="mt-3 mb-1"></hr>
                                        </div>
                                    </React.Fragment>
                                    
                                }

                            </tbody>
                        </table>
                    </div>
                    {/* <div>
                        <hr className="mt-0 mb-0"></hr>
                    </div> */}
                    <p className="contributes-detailtxt txt-lightgray">
                        * The % Daily Value (DV) tells you how much a nutrient in a serving of food contributes to a daily diet. 2,000 calories a day is used for general nutrition advice.
                    </p>
                </Modal.Body>
                {/* <Modal.Footer>
                    <p>Voluptua sed diam lorem sanctus ipsum sed sanctus nonumy. Accusam sea tempor labore accusam diam labore no sea amet, at sed et et takimata et et voluptua duo. Aliquyam et.</p>
                </Modal.Footer> */}
            </Modal>
        </>
    )
}

export default RestaurantCookingMethodModal;