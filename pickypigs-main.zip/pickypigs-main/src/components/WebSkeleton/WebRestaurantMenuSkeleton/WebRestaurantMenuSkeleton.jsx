import React from "react";
import Skeleton from "react-loading-skeleton";

const WebRestaurantMenuSkeleton=()=>{
    return(
        <React.Fragment>
            <div className="container">
                    <div>
                        <div className="row mt-4">
                            <div className="col-md-3 p-3 pr-5" style={{boxShadow:'0px 3px 16px 0px #00000010',borderRadius:10}}>
                                <div><Skeleton  count={2}   className="w-100 mb-2"/></div>
                                <br></br>
                                <div><Skeleton  count={2}   className="w-100 mb-2"/></div>
                                <br></br>
                                <div><Skeleton  count={2}   className="w-100 mb-2"/></div>
                            </div>
                            <div className="col-md-9">
                                <div className="d-flex">
                                    <div className="w-100">
                                        <div>
                                            <Skeleton count={1}  height={200}  className="w-100" style={{borderRadius:10}}/>
                                        </div>
                                        <div className="pl-4 pr-4 pt-2 pb-2 bg-white">
                                            <div>
                                                <Skeleton count={2}  className="w-100"/>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="w-100 ml-3 mr-3">
                                        <div>
                                            <Skeleton count={1}  height={200}  className="w-100" style={{borderRadius:10}}/>
                                        </div>
                                        <div className="pl-4 pr-4 pt-2 pb-2 bg-white">
                                            <div>
                                                <Skeleton count={2}  className="w-100"/>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="w-100">
                                        <div>
                                            <Skeleton count={1}  height={200}  className="w-100" style={{borderRadius:10}}/>
                                        </div>
                                        <div className="pl-4 pr-4 pt-2 pb-2 bg-white">
                                            <div>
                                                <Skeleton count={2}  className="w-100"/>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-md-3"></div>
                        <div className="col-md-9">
                            <div className="p-3 mt-5" style={{boxShadow:'0px 3px 16px 0px #00000010',borderRadius:10}}>
                                <span className="d-flex align-items-center w-100 mb-2">
                                    <Skeleton circle={true} height={38} width={38} className="mr-3"/>
                                    <div  className="w-100">
                                        <Skeleton count={1}  className="w-100"/>
                                    </div>
                                </span>
                                <Skeleton count={3}  className="w-100"/>
                            </div>
                        </div>
                    </div>
                
               
                    

            </div>
            
        </React.Fragment>
    )
};

export default WebRestaurantMenuSkeleton;