import React from "react";
import Skeleton from "react-loading-skeleton";

const WebRestaurantMenuSkeleton=()=>{
    return(
        <React.Fragment>
            <div >
                    <div>
                        <div className="d-flex">
                            <div className="w-100 p-3 pr-5" >
                                <div><Skeleton  count={2}   className="w-100 mb-2"/></div>
                                <br></br>
                                <div><Skeleton  count={2}   className="w-100 mb-2"/></div>
                                <br></br>
                                <div><Skeleton  count={2}   className="w-100 mb-2"/></div>
                                <br></br>
                                <div><Skeleton  count={2}   className="w-100 mb-2"/></div>
                                <br></br>
                                <div><Skeleton  count={2}   className="w-100 mb-2"/></div>
                                <br></br>
                                <div><Skeleton  count={2}   className="w-100 mb-2"/></div>
                            </div>
                            
                        </div>
                    </div>
                
                
               
                    

            </div>
            
        </React.Fragment>
    )
};

export default WebRestaurantMenuSkeleton;