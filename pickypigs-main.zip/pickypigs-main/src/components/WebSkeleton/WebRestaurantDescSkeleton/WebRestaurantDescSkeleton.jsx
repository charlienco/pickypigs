import React from "react";
import Skeleton from "react-loading-skeleton";

const WebRestaurantDescSkeleton=()=>{
    return(
        <React.Fragment>
            <div>
                <div>
                    <Skeleton count={1}  height={200}  className="w-100" style={{borderRadius:10}}/>
                </div>
                <div className="pl-4 pr-4 pt-2 pb-2 bg-white" style={{borderRadius:10}}>
                    <div>
                        <Skeleton count={2}  className="w-100"/>
                    </div>
                    <div className="d-flex">
                        <Skeleton circle={true} height={38} width={38} className="mr-3"/>
                        <Skeleton circle={true} height={38} width={38} className="mr-3"/>
                        <Skeleton circle={true} height={38} width={38} className="mr-3"/>
                    </div>
                </div>
            </div>
            
        </React.Fragment>
    )
};

export default WebRestaurantDescSkeleton;