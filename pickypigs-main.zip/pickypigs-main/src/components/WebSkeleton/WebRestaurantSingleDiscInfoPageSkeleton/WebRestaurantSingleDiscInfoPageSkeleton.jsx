import React from "react";
import Skeleton from "react-loading-skeleton";

const WebRestaurantSingleDiscInfoPageSkeleton=()=>{
    return(
        <React.Fragment>
            <div className="row ">
                <div className="col-sm-12 col-md-5 mt-4 pt-2 mb-4">
                    <div>
                        <Skeleton count={1}  height={300}  className="w-100" style={{borderRadius:10}}/>
                    </div>
                    <div className="pl-4 pr-4 pt-4 pb-4 bg-white" style={{boxShadow:"0 2px 18px 0 rgb(0 0 0 / 7%)"}}>
                        <div className="d-flex justify-content-between w-100 mb-3">
                            <Skeleton count={1} width={100} />
                            <Skeleton count={1} width={100} />
                        </div>
                        <div>
                            <Skeleton count={2}  className="w-100"/>
                        </div>
                        <div className="d-flex mt-2">
                            <Skeleton circle={true} height={38} width={38} className="mr-3"/>
                            <Skeleton circle={true} height={38} width={38} className="mr-3"/>
                            <Skeleton circle={true} height={38} width={38} className="mr-3"/>
                        </div>
                    </div>
                </div>
                <div className="col-sm-12 col-md-7 mt-4 pt-2 mb-4 " style={{boxShadow:"0 2px 18px 0 rgb(0 0 0 / 7%)"}}>
                    <div>
                        <div className="d-flex align-items-center mt-1 mb-1 p-2">
                            <Skeleton circle={true} count={1} width={60}  height={60}/>
                            <div className="w-100  p-2">
                                <Skeleton count={1}  className="w-100 ml-3" />
                            </div>
                        </div>
                        <div className="mt-1 mb-1 p-2">
                            <div className="d-flex justify-content-between w-100 mb-3">
                                <Skeleton count={1} width={100} />
                                <Skeleton count={1} width={100} />
                                <Skeleton count={1} width={100} />
                                <Skeleton count={1} width={100} />
                            </div>
                            <div style={{borderBottom:'2px solid #f7f7f7'}}></div>
                            <div>
                                <Skeleton count={1} className="w-100 mt-4 mb-4" />
                                <div style={{borderBottom:'2px solid #f7f7f7'}}></div>
                            </div>
                            <div>
                                <Skeleton count={1} className="w-100 mt-4 mb-4" />
                                <div style={{borderBottom:'2px solid #f7f7f7'}}></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div className="row justify-content-between">
                <div className="col-sm-12 col-md-12 col-lg-4 col-xl-4 p-3 mb-3" style={{boxShadow:'0px 3px 16px 0px #00000010',borderRadius:10}}>
                    <span className="d-flex align-items-center w-100 mb-2">
                        <Skeleton circle={true} height={38} width={38} className="mr-3"/>
                        <div  className="w-100">
                            <Skeleton count={1}  className="w-100"/>
                        </div>
                    </span>
                    <Skeleton count={1}  className="w-100"/>
                </div>
                <div className="col-sm-12 col-md-12 col-lg-4 col-xl-4 p-3 mb-3" style={{boxShadow:'0px 3px 16px 0px #00000010',borderRadius:10}}>
                    <span className="d-flex align-items-center w-100 mb-2">
                        <Skeleton circle={true} height={38} width={38} className="mr-3"/>
                        <div  className="w-100">
                            <Skeleton count={1}  className="w-100"/>
                        </div>
                    </span>
                    <Skeleton count={1}  className="w-100"/>
                </div>
                <div className="col-sm-12 col-md-12 col-lg-4 col-xl-4 p-3 mb-3"  style={{boxShadow:'0px 3px 16px 0px #00000010',borderRadius:10}}>
                    <span className="d-flex align-items-center w-100 mb-2">
                        <Skeleton circle={true} height={38} width={38} className="mr-3"/>
                        <div  className="w-100">
                            <Skeleton count={1}  className="w-100"/>
                        </div>
                    </span>
                    <Skeleton count={1}  className="w-100"/>
                </div>
            </div>
            
        </React.Fragment>
    )
};

export default WebRestaurantSingleDiscInfoPageSkeleton;