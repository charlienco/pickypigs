import React, { useState } from "react";
import fussfood from "../../assets/images/fussfood.svg";
import personalise from "../../assets/images/personalise.svg";
import allergen from "../../assets/images/Allergen-icon.svg";
import ingredients from "../../assets/images/Ingredients-icon.svg";
import nutritionFacts from "../../assets/images/NutritionFacts-icon.svg";
import knowwhatimg from "../../assets/images/knowwhat-imgs.png";
import { Modal } from "react-bootstrap";

import "./KnowWhatYouEatComponent.scss";

const KnowWhatYouEatComponent = () => {
  const [show, setShow] = useState(false);
  const [active, setActive] = useState(0);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
  // const handleActive=(value)=>{
  //     setactive(value)
  // }
  return (
    <>
      {/* Know what you section start */}
      <section className="whatYouEat-container position-relative zindex-1">
        <div className="container position-relative knowwhat-section">
          <div className="knowwhatbg-img">
            <img alt="knowwhatimg" src={knowwhatimg} className="img-fluid" />
          </div>
          <div className="row mb-5 pb-4">
            <div className="col-sm-12">
              <h1 className="sectionhead-txt text-uppercase">
                FUSS FREE
                <br className="d-md-none d-lg-block" />
                FOOD
              </h1>
              <p className="txt-lightgray f-15 mb-4 pb-2 brandon-regular">
              You don't need to feel like a "fussy feeder", take control back and have full <br className="d-md-none d-lg-block" /> transparency and clarity of what you do or don't want to eat.
              </p>
              <div className="know-borderstyle"></div>
            </div>
          </div>
          <div className="row">
            <div
              className="col-sm-6 col-md-4 col-lg-4 col-xl-4 knowwhat-main mb-4"
              type="button"
              onClick={() => {
                setActive(1);
                handleShow();
              }}
            >
              <div className="knowwhat-wrapper p-4">
                <div className="knowwhat-icon d-flex align-items-center justify-content-center mb-2">
                  <img alt="fussfood" src={fussfood} className="img-fluid" />
                </div>
                <div className="knowwhat-info pt-1">
                  <h6 className="text-uppercase brandon-Bold">
                    <b>Fuss free food</b>
                  </h6>
                  <p className="f-15 mb-1">
                    Whether you have food allergies, are watching what you eat
                    or want to be a conscious eater, Picky Pigs will find the
                    best restaurant for you and create a personalised digital
                    menu for your needs. All of this at the click of a button.
                  </p>
                </div>
              </div>
            </div>
            <div
              className="col-sm-6 col-md-4 col-lg-4 col-xl-4 knowwhat-main mb-4"
              type="button"
              onClick={() => {
                setActive(2);
                handleShow();
              }}
            >
              <div className="knowwhat-wrapper p-4">
                <div className="knowwhat-icon d-flex align-items-center justify-content-center mb-2">
                  <img
                    alt="personalise"
                    src={personalise}
                    className="img-fluid"
                  />
                </div>
                <div className="knowwhat-info pt-1">
                  <h6 className="text-uppercase brandon-Bold">
                    <b>PERSONALISE</b>
                  </h6>
                  <p className="f-15 mb-1">
                    Create a personalised digital menu by adding as many filters
                    as you need to search for dishes you can eat and enjoy. No
                    more sifting through menus to find something you can eat by
                    process of elimination. Picky Pigs will take care of that
                    for you.
                  </p>
                </div>
              </div>
            </div>
            <div className="col-sm-6 col-md-4 col-lg-4 col-xl-4 knowwhat-main mb-4"></div>
            <div
              className="col-sm-6 col-md-4 col-lg-4 col-xl-4 knowwhat-main mb-4"
              type="button"
              onClick={() => {
                setActive(3);
                handleShow();
              }}
            >
              <div className="knowwhat-wrapper p-4">
                <div className="knowwhat-icon d-flex align-items-center justify-content-center mb-2">
                  <img alt="allergen" src={allergen} className="img-fluid" />
                </div>
                <div className="knowwhat-info pt-1">
                  <h6 className="text-uppercase brandon-Bold">
                    <b>Choice and Control</b>
                  </h6>
                  <p className="f-15 mb-1">
                    Take back control of what you do or don’t eat. Picky Pigs
                    will give you a full breakdown of each dish – its
                    ingredients, allergens, calories and macros – giving you
                    more control and greater choice.
                  </p>
                </div>
              </div>
            </div>
            <div
              className="col-sm-6 col-md-4 col-lg-4 col-xl-4 knowwhat-main mb-4"
              type="button"
              onClick={() => {
                setActive(4);
                handleShow();
              }}
            >
              <div className="knowwhat-wrapper p-4">
                <div className="knowwhat-icon d-flex align-items-center justify-content-center mb-2">
                  <img
                    alt="ingredients"
                    src={ingredients}
                    className="img-fluid"
                  />
                </div>
                <div className="knowwhat-info pt-1">
                  <h6 className="text-uppercase brandon-Bold">
                    <b>Connect</b>
                  </h6>
                  <p className="f-15 mb-1">
                    Connect with friends to find a restaurant you’ll all enjoy.
                    Simply add each person’s requirements into the search and
                    let Picky Pigs find the perfect spot with dishes to suit you
                    all. No one needs to feel like a ‘fussy feeder’ with Picky
                    Pigs. 
                  </p>
                </div>
              </div>
            </div>
            <div
              className="col-sm-6 col-md-4 col-lg-4 col-xl-4 knowwhat-main mb-4"
              type="button"
              onClick={() => {
                setActive(5);
                handleShow();
              }}
            >
              <div className="knowwhat-wrapper p-4">
                <div className="knowwhat-icon d-flex align-items-center justify-content-center mb-2">
                  <img
                    alt="nutritionFacts"
                    src={nutritionFacts}
                    className="img-fluid"
                  />
                </div>
                <div className="knowwhat-info pt-1">
                  <h6 className="text-uppercase brandon-Bold">
                    <b>The Whole Experience</b>
                  </h6>
                  <p className="f-15 mb-1">
                    Find your perfect restaurant, choose your personalised dish
                    and order from home. With Picky Pigs, there’s no need to
                    feel like a ‘fussy feeder’ when you arrive at the
                    restaurant. You can relax, enjoy the experience and
                    rediscover your love for dining out. Fuss free food at your
                    fingertips.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <div>
        <Modal
          size="lg"
          centered
          show={show}
          onHide={handleClose}
          className="knowyoueat-modal"
        >
          <Modal.Body className=" position-relative">
            <button className="close-btn" onClick={handleClose}>
              x
            </button>
            <div
              id="carouselExampleFade"
              className="position-relative knowyoueat-carousel carousel slide carousel-fade"
              data-ride="carousel"
              data-interval="false"
            >
              <div className="carousel-inner">
                <div className={`carousel-item ${active === 1 && "active"}`}>
                  <div className="knowwhat-wrapper">
                    <div className="knowwhat-icon d-flex align-items-center justify-content-center mb-2">
                      <img
                        alt="fussfood"
                        src={fussfood}
                        className="img-fluid"
                      />
                    </div>
                    <div className="knowwhat-info pt-1">
                      <h6 className="text-uppercase brandon-Bold">
                        <b>Fuss free food</b>
                      </h6>
                      <p className="f-15 mb-1">
                        Whether you have food allergies, are watching what you
                        eat or want to be a conscious eater, Picky Pigs will
                        find the best restaurant for you and create a
                        personalised digital menu for your needs. All of this at
                        the click of a button.
                      </p>
                    </div>
                  </div>
                </div>
                <div className={`carousel-item ${active === 2 && "active"}`}>
                  <div className="knowwhat-wrapper">
                    <div className="knowwhat-icon d-flex align-items-center justify-content-center mb-2">
                      <img
                        alt="personalise"
                        src={personalise}
                        className="img-fluid"
                      />
                    </div>
                    <div className="knowwhat-info pt-1">
                      <h6 className="text-uppercase brandon-Bold">
                        <b>PERSONALISE</b>
                      </h6>
                      <p className="f-15 mb-1">
                        Create a personalised digital menu by adding as many
                        filters as you need to search for dishes you can eat and
                        enjoy. No more sifting through menus to find something
                        you can eat by process of elimination. Picky Pigs will
                        take care of that for you.
                      </p>
                    </div>
                  </div>
                </div>
                <div className={`carousel-item ${active === 3 && "active"}`}>
                  <div className="knowwhat-wrapper">
                    <div className="knowwhat-icon d-flex align-items-center justify-content-center mb-2">
                      <img
                        alt="allergen"
                        src={allergen}
                        className="img-fluid"
                      />
                    </div>
                    <div className="knowwhat-info pt-1">
                      <h6 className="text-uppercase brandon-Bold">
                        <b>Choice and Control</b>
                      </h6>
                      <p className="f-15 mb-1">
                        Take back control of what you do or don’t eat. Picky
                        Pigs will give you a full breakdown of each dish – its
                        ingredients, allergens, calories and macros – giving you
                        more control and greater choice.
                      </p>
                    </div>
                  </div>
                </div>
                <div className={`carousel-item ${active === 4 && "active"}`}>
                  <div className="knowwhat-wrapper">
                    <div className="knowwhat-icon d-flex align-items-center justify-content-center mb-2">
                      <img
                        alt="ingredients"
                        src={ingredients}
                        className="img-fluid"
                      />
                    </div>
                    <div className="knowwhat-info pt-1">
                      <h6 className="text-uppercase brandon-Bold">
                        <b>Connect</b>
                      </h6>
                      <p className="f-15 mb-1">
                        Connect with friends to find a restaurant you’ll all
                        enjoy. Simply add each person’s requirements into the
                        search and let Picky Pigs find the perfect spot with
                        dishes to suit you all. No one needs to feel like a
                        ‘fussy feeder’ with Picky Pigs. 
                      </p>
                    </div>
                  </div>
                </div>
                <div className={`carousel-item ${active === 5 && "active"}`}>
                  <div className="knowwhat-wrapper">
                    <div className="knowwhat-icon d-flex align-items-center justify-content-center mb-2">
                      <img
                        alt="nutritionFacts"
                        src={nutritionFacts}
                        className="img-fluid"
                      />
                    </div>
                    <div className="knowwhat-info pt-1">
                      <h6 className="text-uppercase brandon-Bold">
                        <b>The Whole Experience</b>
                      </h6>
                      <p className="f-15 mb-1">
                        Find your perfect restaurant, choose your personalised
                        dish and order from home. With Picky Pigs, there’s no
                        need to feel like a ‘fussy feeder’ when you arrive at
                        the restaurant. You can relax, enjoy the experience and
                        rediscover your love for dining out. Fuss free food at
                        your fingertips.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
              <button
                style={{ position: "absolute", left: -140 }}
                className="carousel-control-prev"
                href="#carouselExampleFade"
                data-slide="prev"
              >
                <span
                  className="carousel-control-prev-icon"
                  aria-hidden="true"
                ></span>
                <span className="sr-only">Previous</span>
              </button>

              <button
                style={{ position: "absolute", right: -140 }}
                className="carousel-control-next"
                href="#carouselExampleFade"
                data-slide="next"
              >
                <span
                  className="carousel-control-next-icon"
                  aria-hidden="true"
                ></span>
                <span className="sr-only">Next</span>
              </button>
            </div>
          </Modal.Body>
        </Modal>
      </div>
    </>
  );
};

export default KnowWhatYouEatComponent;
