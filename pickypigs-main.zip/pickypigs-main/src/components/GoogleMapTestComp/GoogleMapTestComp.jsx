import React, { useEffect } from "react";

const GoogleMapTestComp = ({ rest_address }) => {
  useEffect(() => {
    const myLatLng = {
      lat:
        rest_address && rest_address.map && rest_address.map.coordinates
          ? rest_address.map.coordinates[0]
          : 0,
      lng:
        rest_address && rest_address.map && rest_address.map.coordinates
          ? rest_address.map.coordinates[1]
          : 0,
    };
    // const myLatLng = rest_address&&rest_address.map&&rest_address.map.coordinates?rest_address.map.coordinates:{};
    const map = new window.google.maps.Map(document.getElementById("map"), {
      zoom: 12,
      center: myLatLng,
    });
    new window.google.maps.Marker({
      position: myLatLng,
      map,
      title:
        rest_address && rest_address.googleAddress
          ? rest_address.googleAddress
          : "Restuarant Location",
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <React.Fragment>
      <div style={{ height: `100%` }} id="map" />
    </React.Fragment>
  );
};
export default GoogleMapTestComp;
