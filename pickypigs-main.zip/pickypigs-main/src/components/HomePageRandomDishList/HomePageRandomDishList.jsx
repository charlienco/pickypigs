import React, { useEffect } from "react";
import { Link } from "react-router-dom";
import DiscDescriptionComp from "../DiscDescriptionComp/DiscDescriptionComp";
import "./HomePageRandomDishList.scss";
// import restaurant_P1 from "../../assets/images/restaurant_default.jpg"
import { useDispatch, useSelector } from "react-redux";
import { getRandomDishList } from "../../redux/actions/homePageAction";
import { DEFAULT_LAT, DEFAULT_LNG } from "../../shared/constant";
import WebRestaurantDescSkeleton from "../WebSkeleton/WebRestaurantDescSkeleton/WebRestaurantDescSkeleton";
// import {SERVER_URL} from '../../shared/constant'

const HomePageRandomDishList = () => {
  const dispatch = useDispatch();

  const myCordinates = useSelector((state) => {
    return state.googledata;
  });

  let myPreferenceData = useSelector((state) => {
    return state.myPreference;
  });

  const { allergendata, dietarydata, lifestyledata, featuredata } = myPreferenceData.selectedPreference;

  let { overalLocation = { lat: DEFAULT_LAT, lng: DEFAULT_LNG } } =
    myCordinates;

  useEffect(() => {
    if (overalLocation && overalLocation.lat && overalLocation.lng) {
      dispatch(
        getRandomDishList({
          userCoordinates: [
            overalLocation && overalLocation.lat ? overalLocation.lat : "",
            overalLocation && overalLocation.lng ? overalLocation.lng : "",
          ],
        })
      );
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [overalLocation]);

  const randomDishData = useSelector((state) => {
    return state.homePage;
  });
  let { isLoading, randomDishsList_Data } = randomDishData;

  return (
    <React.Fragment>
      <section className="HomePageRandomDishList mb-5 pt-5 zindex-1 position-relative">
        <div className="container">
          <div className="row mb-4 pb-3">
            <div className="col-sm-12">
              <div className="whatmenu-wrapper d-flex justify-content-between align-items-end">
                <h1 className="sectionhead-txt text-center">
                  FIND A DISH YOU WILL LOVE
                </h1>
                {/* <Link
                  to="/dish_list"
                  style={{
                    display: "flex",
                    justifyContent: "center",
                    alignItems: "center",
                  }}
                  className="theme-light-btn w-140 h-48 f-14 btn "
                >
                  VIEW ALL
                </Link> */}
                {
                  allergendata.length <= 0 &&
                    dietarydata.length <= 0 &&
                    lifestyledata.length <= 0 &&
                    featuredata.length <= 0 ? (
                    <Link
                      to="/dish_list"
                      style={{
                        display: "flex",
                        justifyContent: "center",
                        alignItems: "center",
                      }}
                      className="theme-light-btn w-140 h-48 f-14 btn "
                    >
                      VIEW ALL
                    </Link>
                  ) : (
                    <Link
                      to={{
                        pathname: "/allrestaurant",
                        search: `?search=`,
                        state: {
                          allergendata: allergendata,
                          dietarydata: dietarydata,
                          lifestyledata: lifestyledata,
                          featuredata: featuredata,
                        },
                      }}
                      className="theme-light-btn w-140 h-48 f-14 btn "
                    >
                      VIEW ALL
                    </Link>
                  )
                }
              </div>
            </div>
          </div>
          <div className="row">
            {isLoading && isLoading ? (
              <React.Fragment>
                {[1, 2, 3, 4].map((data, index) => {
                  return (
                    <React.Fragment key={index}>
                      <div className="ol-sm-6 col-md-6 col-lg-3 col-xl-3 mb-4">
                        <WebRestaurantDescSkeleton />
                      </div>
                    </React.Fragment>
                  );
                })}
              </React.Fragment>
            ) : (
              <React.Fragment>
                {randomDishsList_Data &&
                  randomDishsList_Data.dishesList &&
                  randomDishsList_Data.dishesList.length > 0 ? (
                  <React.Fragment>
                    {randomDishsList_Data.dishesList &&
                      randomDishsList_Data.dishesList.map((data, index) => {
                        return (
                          <React.Fragment key={index}>
                            <div className="col-sm-6 col-md-6 col-lg-3 col-xl-3 mb-4">
                              <Link
                                to={"/restaurant_dish_info/" + data._id}
                                style={{
                                  textDecoration: "none",
                                  color: "initial",
                                }}
                              >
                                <DiscDescriptionComp
                                  dish_name={data.name ? data.name : ""}
                                  dish_image={data.image ? data.image : ""}
                                  dish_priceunit={
                                    data.priceUnit ? data.priceUnit : ""
                                  }
                                  dish_price={data.price ? data.price : "-"}
                                  dish_description={
                                    data.description ? data.description : ""
                                  }
                                  dish_menu={
                                    data.menusDetail ? data.menusDetail : []
                                  }
                                  dish_allergy={
                                    data.allergensList ? data.allergensList : []
                                  }
                                  dish_new_tag={data.new ? data.new : false}
                                  dish_available_tag={
                                    data.available ? data.available : false
                                  }
                                />
                              </Link>
                            </div>
                          </React.Fragment>
                        );
                      })}
                  </React.Fragment>
                ) : (
                  <React.Fragment>
                    <p>Something Went Wrong...</p>
                  </React.Fragment>
                )}
              </React.Fragment>
            )}
          </div>
        </div>
      </section>
    </React.Fragment>
  );
};

export default HomePageRandomDishList;
