import React, { useEffect, useRef, useState } from "react";
import {
  DEFAULT_LOCATION,
  DEFAULT_LAT,
  DEFAULT_LNG,
} from "../../shared/constant";
import "./MyfilterListExampleCopy.scss";
import location from "../../assets/images/mobile_imgs/location_icon_black.svg";
import crosshair from "../../assets/images/crosshair.svg";
// import nearlocation from "../../assets/images/nearlocaion-icon.svg"
import {
  getLocationGeometryData,
  locationLoader,
} from "../../redux/actions/googleAction";
import { useDispatch, useSelector } from "react-redux";
// import LocationPopUpModalComp from '../LocationPopUpModalComp/LocationPopUpModalComp';
// import { getMyLocationData, getMyLocationName } from '../../redux/actions/myLocationDataAction';
import Cookies from "js-cookie";

function useOutsideAlerter(ref, setUserTextFocus, setCurrentLocationButton) {
  useEffect(() => {
    /**
     * Alert if clicked on outside of element
     */
    function handleClickOutside(event) {
      if (ref.current && !ref.current.contains(event.target)) {
        // alert("You clicked outside of me!");
        setUserTextFocus(false);
        setCurrentLocationButton(false);
      }
    }

    // Bind the event listener
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      // Unbind the event listener on clean up
      document.removeEventListener("mousedown", handleClickOutside);
    };
    // eslint-disable-next-line
  }, [ref]);
}

export default function MyfilterListExampleCopy() {
  const dispatch = useDispatch();
  const [inputValue, setInputValue] = useState("");
  const [myPlaceName, setMyPlaceName] = useState("");
  const [userTextFocus, setUserTextFocus] = useState(false);
  const [currentLocationButton, setCurrentLocationButton] = useState(false);

  const [myLat, setMyLat] = React.useState("");
  const [myLng, setMyLng] = React.useState("");
  const [myAddress, setMyAddress] = React.useState("");
  const myCookLat = Cookies.get("lat");
  const myCookLng = Cookies.get("lng");
  const myCookAddress = Cookies.get("address");

  const [initiate, setInitiate] = React.useState(false);

  const wrapperRef = useRef(null);
  useOutsideAlerter(wrapperRef, setUserTextFocus, setCurrentLocationButton);

  const getMyLocation = () => {
    const location = window.navigator && window.navigator.geolocation;
    if (location) {
      location.getCurrentPosition(
        (position) => {
          // setErrorMessage(0)
          const latlng = {
            lat: parseFloat(position.coords.latitude),
            lng: parseFloat(position.coords.longitude),
          };
          // console.log("latlng",latlng)
          if (position.coords.latitude && position.coords.longitude) {
            Cookies.remove("address");
            dispatch(getLocationGeometryData(latlng));
          }
          const geocoder = new window.google.maps.Geocoder();
          geocoder.geocode({ location: latlng }, (results, status) => {
            if (status === "OK") {
              if (results[0]) {
                // console.log("sssss")

                setInputValue(results[0] && results[0].formatted_address);
                setMyPlaceName(results[0] && results[0].formatted_address);
                Cookies.set(
                  "address",
                  results[0] && results[0].formatted_address
                );
              } else {
                // window.alert("No results found");
              }
            } else {
              // window.alert("Geocoder failed due to: " + status);
            }
          });
        },
        (error) => {
          // console.log('error => ', error.code);
          if (!myLat || myLng || !myCookLat || !myCookLng || !myCookAddress) {
            setInputValue(DEFAULT_LOCATION.description);
            setMyPlaceName(DEFAULT_LOCATION.description);
            Cookies.remove("lat");
            Cookies.remove("lng");
            Cookies.remove("address");
            const latlng = { lat: DEFAULT_LAT, lng: DEFAULT_LNG };
            dispatch(getLocationGeometryData(latlng));
            Cookies.set("address", DEFAULT_LOCATION.description);
          }
        }
      );
    }
  };

  React.useEffect(() => {
    setMyLat(Cookies.get("lat"));
    // eslint-disable-next-line
  }, [myLat, myLng, myAddress, Cookies.get("lat")]);

  React.useEffect(() => {
    setMyLng(Cookies.get("lng"));
    // eslint-disable-next-line
  }, [myLat, myLng, myAddress, Cookies.get("lng")]);

  React.useEffect(() => {
    setMyAddress(Cookies.get("address"));
    // eslint-disable-next-line
  }, [myLat, myLng, myAddress, Cookies.get("address")]);

  React.useEffect(() => {
    if (myLat || myLng || myAddress || inputValue == null) {
      setInputValue(myAddress);
      setMyPlaceName(myAddress);
    }
    // eslint-disable-next-line
  }, [myLat, myLng, myAddress]);

  // React.useEffect(() => {
  //   if (!Cookies.get("lat") && !Cookies.get("lng")) {
  //     getMyLocation();
  //   }
  //   // eslint-disable-next-line
  // }, [myLat, myLng, myAddress]);

  useEffect(() => {
    if (
      inputValue &&
      inputValue.length > 0 &&
      inputValue &&
      inputValue.length < 2
    ) {
      if (!initiate) {
        handleChange();
        // console.log("initAutocomplete")
        setInitiate(true);
      }
    }
    // eslint-disable-next-line
  }, [inputValue]);

  function debounce(func, wait, immediate) {
    let timeout;
    return function () {
      let context = this,
        args = arguments;
      let later = function () {
        timeout = null;
        if (!immediate) func.apply(context, args);
      };
      let callNow = immediate && !timeout;
      clearTimeout(timeout);
      timeout = setTimeout(later, wait);
      if (callNow) func.apply(context, args);
    };
  }

  const handleChange = () => {
    // Create the search box and link it to the UI element.
    // let inputContainer = document.querySelector('autocomplete-input-container');
    let autocomplete_results = document.querySelector(".autocomplete-results");
    let sessionToken = new window.google.maps.places.AutocompleteSessionToken();
    let service = new window.google.maps.places.AutocompleteService();

    let displayPlacesSuggestions = function (predictions, status) {
      // console.log("displayPlacesSuggestions")
      if (status !== window.google.maps.places.PlacesServiceStatus.OK) {
        alert(status);
        return;
      }
      // autocomplete_results.classList.add("google");
      let results_html = [];
      predictions.forEach(function (prediction) {
        // console.log(prediction)

        results_html.push(`<li class="autocomplete-item" data-type="place" data-place-id=${
          prediction.place_id
        }>
                                <div class="autocomplete-icon "></div>
                                <div class="utocomplete-item-text-cont">
                                  <div class="autocomplete-text-desc">${
                                    prediction.description
                                  }</div>
                                  <div class="autocomplete-main-text">${
                                    prediction.structured_formatting &&
                                    prediction.structured_formatting
                                      .main_text &&
                                    prediction.structured_formatting.main_text
                                  }</div>
                                  <div class="autocomplete-second-text">${
                                    prediction.structured_formatting &&
                                    prediction.structured_formatting
                                      .secondary_text &&
                                    prediction.structured_formatting
                                      .secondary_text
                                  }</div>
                                </div>
                            </li>`);
      });
      autocomplete_results.innerHTML = results_html.join("");
      autocomplete_results.style.display = "block";
      let autocomplete_items =
        autocomplete_results.querySelectorAll(".autocomplete-item");
      for (let autocomplete_item of autocomplete_items) {
        // eslint-disable-next-line no-loop-func
        autocomplete_item.addEventListener("click", function () {
          const selected_text = this.querySelector(
            ".autocomplete-text-desc"
          ).textContent;

          const place_id = this.getAttribute("data-place-id");
          let request = {
            placeId: place_id,
            fields: ["geometry"],
          };
          let serviceDetails = new window.google.maps.places.PlacesService(
            autocomplete_results
          );

          // console.log(place_id)
          serviceDetails.getDetails(request, function (results, status) {
            if (status === "OK") {
              //  console.log(results)
              if (results) {
                const coordinates = results.geometry;

                if (coordinates) {
                  const latlng = {
                    lat: coordinates.location.lat(),
                    lng: coordinates.location.lng(),
                  };
                  dispatch(getLocationGeometryData(latlng));
                } else {
                  Cookies.set("lat", DEFAULT_LAT);
                  Cookies.set("lng", DEFAULT_LNG);
                }
              }
            } else {
              alert(
                "Geocode was not successful for the following reason: " + status
              );
            }
            autocomplete_input.value = null;
            Cookies.set("address", selected_text && selected_text);
            setInputValue(selected_text);
            setMyPlaceName(selected_text);
            setCurrentLocationButton(false);
            autocomplete_results.style.display = "none";
          });
        });
      }
    };

    var autocomplete_input = document.getElementById("google-map-demo");
    autocomplete_input.addEventListener(
      "keyup",
      debounce(function () {
        let value = this.value;
        value.replace('"', '\\"').replace(/^\s+|\s+$/g, "");
        if (value !== "" && value.length > 2) {
          service.getPlacePredictions(
            {
              input: value,
              sessionToken: sessionToken,
            },
            displayPlacesSuggestions
          );
        } else {
          autocomplete_results.innerHTML = "";
          autocomplete_results.style.display = "none";
        }
      }, 1500)
    );
  };

  useEffect(() => {
    dispatch(locationLoader(myPlaceName));
    // eslint-disable-next-line
  }, [dispatch, myPlaceName]);

  const randomLoading = useSelector((state) => {
    return state.googledata;
  });
  let { myLoading } = randomLoading;

  return (
    <React.Fragment>
      <section ref={wrapperRef} className="myfilterlistexamplecopy-comp">
        <div className="filterlis-location-input-wrapper d-flex align-items-center position-relative autocomplete-input-container">
          <div className="location-button">
            <img
              src={location}
              className="img-fluid"
              alt="Near_Me"
              title="Detect My Location"
            />
          </div>
          <input
            id="google-map-demo"
            className="autocomplete-input"
            onChange={(e) => setInputValue(e.target.value)}
            onFocus={() => {
              setUserTextFocus(true);
              setCurrentLocationButton(true);
            }}
            label="Location"
            placeholder={
              myLoading
              ? " Fetching Location..."
              : myPlaceName
              ? myPlaceName
              : "Where are you?"
            }
            // value={inputValue}
            autoComplete="off"
            // eslint-disable-next-line jsx-a11y/role-has-required-aria-props 
            role="combobox"
          />

          <ul
            className={`autocomplete-results ${
              inputValue && inputValue !== "" && userTextFocus
                ? "d-block"
                : "d-none"
            }`}
          ></ul>
          {document.getElementById("google-map-demo") &&
          document.getElementById("google-map-demo").value.length >= 0 &&
          currentLocationButton ? (
            <button
              onClick={() => {
                setCurrentLocationButton(false);
                getMyLocation();
                document.getElementById("google-map-demo").value = "";
              }}
              className="get_current_location_wrapper"
            >
              <div className="detect_location_main_img">
                <img
                  src={crosshair}
                  className="img-fluid"
                  alt="icon"
                  loading="lazy"
                />
              </div>
              <div className="ml-1">
                <p className="mb-1 detect_location_main_text">
                  Detect Current Location
                </p>
                <p className="mb-1 detect_location_sub_text">Using GPS</p>
              </div>
            </button>
          ) : null}
        </div>
      </section>
    </React.Fragment>
  );
}
