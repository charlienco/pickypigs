import React, { useState } from "react";
import './SettingRestaurantDetailComp.scss';

const SettingRestaurantDetailComp=()=>{
    return(
        <React.Fragment>
            <p>SettingRestaurantDetailComp</p>
        </React.Fragment>
    )
}

export default SettingRestaurantDetailComp;
