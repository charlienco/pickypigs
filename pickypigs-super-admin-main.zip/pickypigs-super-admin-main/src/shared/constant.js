export const HOST_URL = "https://localhost:8000"

export const INVALID_CRED = "Invalid credential !"

export const SECRET_KEY=  "shukrana_mushkurana"

export const API_KEY = "AIzaSyBWIIb5rlIPoxCKRCQlueENTkj2KcniU1I"

export const GOOGLE_MAP_API_URL = "https://maps.googleapis.com/maps/api/geocode/json";

export const GOOGLE_PLACE_API_URL = "https://maps.googleapis.com/maps/api/place/textsearch/json";

export const GOOGLE_CLIENT_ID = "521543791680-26jrl70j0duivecoh80f4jpun63cjbpn.apps.googleusercontent.com";

export const FACEBOOK_APP_ID = "2809614726027672";

export const EDAMAM_APP_ID = "2bbcafaf";

export const EDAMAM_APP_KEY = "f779cbf3ef41e8fc15a42df1cff35d0d";

export const RESTAURANT_ADMIN_URL = `${window.location.host === "localhost:3001"?"https://pickypigs.charlieandco.co.nz/restaurant_login":"https://pickypigs.charlieandco.co.nz/restaurant_login"}`;

// export const SERVER_URL = "https://apps.narola.online:5003";
export const SERVER_URL = "https://api.pickypigs.com:5003";

export const SUPERADMIN_URL="https://super-admin.pickypigs.com";

