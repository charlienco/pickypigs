import React from "react";
import {
  CButton,
  CModal,
  CModalHeader,
  CModalTitle,
  CModalBody,
  CInputGroup,
} from "@coreui/react";
// import {deleteSelectedMenuData} from "../../redux/actions/menuAction"
import { useDispatch } from "react-redux";
import { Field, Form, Formik } from "formik";
import * as Yup from "yup";
import { updateSelectedRestaurantEmail } from "../../../redux/actions/manageRestaurantAction";
import {
  CFormGroup,
  CLabel,
  CInvalidFeedback,
  CCardFooter,
} from "@coreui/react";


const UpdateEmailModalComp = (props) => {
  const dispatch = useDispatch();

  const initialValues = {
    email: "",
    confirmEmail: "",
  };
  const validationSchemaForm = Yup.object().shape({
    email: Yup.string()
      .email("Email must be a valid email")
      .required("Email is required"),

      confirmEmail: Yup.string()
      .required()
      .label("Confirm Email")
      .test("Email-match", "Email must match", function (value) {
        return this.parent.email === value;
      }),
  });

  const onSubmit = (input, { setStatus, resetForm }) => {
    setStatus();
    let obj = {
      email: input.email,
    };
    dispatch(
      updateSelectedRestaurantEmail(
        props.selectedid,
        obj,
        props.perpage,
        props.mypage,
        props.inputvalue,
        resetForm
      )
    );
    // props.onClose();
    // resetForm();
  };


  return (
    <>
      <CModal
        {...props}
        size=""
        aria-labelledby="contained-modal-title-vcenter"
        centered
        className="mainmodal-wrapper"
      >
        <CModalHeader className="align-items-center">
          <CModalTitle
            className="brandon-Medium"
            id="contained-modal-title-vcenter"
          >
            Update Restaurant Email
          </CModalTitle>
        </CModalHeader>
        <CModalBody>
          <Formik
            enableReinitialize={true}
            initialValues={initialValues}
            validationSchema={validationSchemaForm}
            onSubmit={onSubmit}
          >
            {({
              errors,
              touched,
              values,
              isSubmitting,
              setFieldValue,
              handleChange,
            }) => {
              return (
                <Form>
                  <div>
                    <CFormGroup>
                      <CLabel>New Email</CLabel>
                      <CInputGroup>
                        <Field
                          name="email"
                          placeholder="Enter here"
                          className={`form-control ${
                            touched.email && errors.email
                              ? "is-invalid"
                              : touched.email && !errors.email
                              ? "is-valid"
                              : null
                          }`}
                        />
                        
                        <CInvalidFeedback className="help-block">
                          {errors.email}
                        </CInvalidFeedback>
                      </CInputGroup>
                    </CFormGroup>
                    <CFormGroup>
                      <CLabel>Confirm New Email</CLabel>
                      <CInputGroup>
                        <Field
                          name="confirmEmail"
                          placeholder="Enter here"
                          className={`form-control ${
                            touched.confirmEmail && errors.confirmEmail
                              ? "is-invalid"
                              : touched.confirmEmail &&
                                !errors.confirmEmail
                              ? "is-valid"
                              : null
                          }`}
                        />
                        
                        <CInvalidFeedback className="help-block">
                          {errors.confirmEmail}
                        </CInvalidFeedback>
                      </CInputGroup>
                    </CFormGroup>
                  </div>
                  <CCardFooter className="d-flex justify-content-end">
                    <CButton
                      color="secondary"
                      className="mr-4"
                      type="reset"
                      onClick={props.onClose}
                    >
                      CANCEL
                    </CButton>
                    <CButton disabled={props.selectedEmail&&props.selectedEmail === values.email} color="success" type="submit">
                      Update
                    </CButton>
                  </CCardFooter>
                </Form>
              );
            }}
          </Formik>
        </CModalBody>
      </CModal>
    </>
  );
};

export default UpdateEmailModalComp;
